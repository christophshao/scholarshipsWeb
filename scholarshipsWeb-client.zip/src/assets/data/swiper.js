// 前端写死的轮播图数据
const swiperList = [
    {picImg: require('@/assets/img/swiper/1.png')},
    {picImg: require('@/assets/img/swiper/2.png')},
    {picImg: require('@/assets/img/swiper/3.png')},
    {picImg: require('@/assets/img/swiper/4.png')},
    {picImg: require('@/assets/img/swiper/5.png')},
    {picImg: require('@/assets/img/swiper/6.png')},
]

export {
    swiperList
}
