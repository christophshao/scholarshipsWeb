// 导航栏menu
const navMsg=[
    {name:'首页',path:'/'},
    // {name:'奖学金',path:'/jiangxuejin'},
    // {name:'助学金',path:'/zhuxuejin'},
    // {name:'困难生',path:'/poor-student'},
    {name:'公告栏',path:'/bulletin'},
]

export{
    navMsg
}