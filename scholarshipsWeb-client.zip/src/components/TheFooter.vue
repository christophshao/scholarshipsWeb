<template>
    <div class="footer">
        <span>&copy;sjf </span>
        <a href="http://localhost:8082/#/" class="lj-footer">后台管理</a>
    </div>
</template>

<style scoped>
    .footer{
        border: 0px solid #000;
        height: 200px;
        text-align: center;
        background: #f7f7f7;
        line-height: 200px;
    }
    a.lj-footer{
        color: red;
    }
</style>