<template>
    <div>zxj</div>
</template>
<script>
    export default{
        name: 'zhuxuejin'
    }
</script>