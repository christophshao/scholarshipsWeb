<template>
    <div>jxj</div>
</template>

<script>
    export default{
        name: 'jiangxuejin'
    }
</script>
