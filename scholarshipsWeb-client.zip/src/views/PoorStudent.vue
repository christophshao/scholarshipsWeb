<template>
    <div>poor</div>
</template>
<script>
    export default{
        name: 'poor-student'
    }
</script>