package com.sjf.scholarships.domain;

import java.io.Serializable;
import java.util.Date;

public class JiangXueJinApply implements Serializable {
    private Integer id;
    private String number;
    private String name;
    private String jxjLevel;
    private String address;
    private String className;
    private Date applyTime;
    private String teacherCheck;//辅导员审核
    private String officeCheck;//教务处审核
    private String teacherOpinion;
    private String officeOpinion;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getJxjLevel() {
        return jxjLevel;
    }

    public void setJxjLevel(String jxjLevel) {
        this.jxjLevel = jxjLevel;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public Date getApplyTime() {
        return applyTime;
    }

    public void setApplyTime(Date applyTime) {
        this.applyTime = applyTime;
    }

    public String getTeacherCheck() {
        return teacherCheck;
    }

    public void setTeacherCheck(String teacherCheck) {
        this.teacherCheck = teacherCheck;
    }

    public String getOfficeCheck() {
        return officeCheck;
    }

    public void setOfficeCheck(String officeCheck) {
        this.officeCheck = officeCheck;
    }

    public String getTeacherOpinion() {
        return teacherOpinion;
    }

    public void setTeacherOpinion(String teacherOpinion) {
        this.teacherOpinion = teacherOpinion;
    }

    public String getOfficeOpinion() {
        return officeOpinion;
    }

    public void setOfficeOpinion(String officeOpinion) {
        this.officeOpinion = officeOpinion;
    }
}
