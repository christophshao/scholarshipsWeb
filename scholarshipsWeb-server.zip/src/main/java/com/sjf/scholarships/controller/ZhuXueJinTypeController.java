package com.sjf.scholarships.controller;

import com.alibaba.fastjson.JSONObject;
import com.sjf.scholarships.domain.ZhuXueJinType;
import com.sjf.scholarships.service.ZhuXueJinTypeService;
import com.sjf.scholarships.utils.Consts;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/zhuxuejintype")
public class ZhuXueJinTypeController {

    @Autowired
    private ZhuXueJinTypeService zhuXueJinTypeService;
    /*
     * 添加
     * */
    @RequestMapping(value = "/add",method = RequestMethod.POST)
    public Object addZhuXueJinType(HttpServletRequest request) {
        JSONObject jsonObject = new JSONObject();
        String type = request.getParameter("type").trim();

        if(type == null || "".equals(type)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"奖学金类型不能为空！");
            return jsonObject;
        }

        // 保存到对象中
        ZhuXueJinType zhuXueJinType = new ZhuXueJinType();
        zhuXueJinType.setType(type);

        boolean flag = zhuXueJinTypeService.insert(zhuXueJinType);
        if(flag){
            jsonObject.put(Consts.CODE,1);
            jsonObject.put(Consts.MSG,"添加成功！");
            return jsonObject;
        }
        jsonObject.put(Consts.CODE,0);
        jsonObject.put(Consts.MSG,"添加失败！");
        return jsonObject;

    }

    /*
     * 删除
     * */
    @RequestMapping(value = "/delete",method = RequestMethod.GET)
    public Object deleteZhuXueJinType(HttpServletRequest request){
        String id = request.getParameter("id").trim();
        boolean flag = zhuXueJinTypeService.delete(Integer.parseInt(id));
        return flag;
    }

    /*
     * 修改
     * */
    @RequestMapping(value = "/update",method = RequestMethod.POST)
    public Object updateZhuXueJinType(HttpServletRequest request){
        JSONObject jsonObject = new JSONObject();
        String id = request.getParameter("id").trim();
        String type = request.getParameter("type").trim();


        if(type == null || "".equals(type)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"用户名不能为空！");
            return jsonObject;
        }


        // 保存到辅导员的对象中
        // 保存到对象中
        ZhuXueJinType zhuXueJinType = new ZhuXueJinType();
        zhuXueJinType.setId(Integer.parseInt(id));
        zhuXueJinType.setType(type);

        boolean flag = zhuXueJinTypeService.update(zhuXueJinType);

        if(flag){
            jsonObject.put(Consts.CODE,1);
            jsonObject.put(Consts.MSG,"修改成功！");
            return jsonObject;
        }
        jsonObject.put(Consts.CODE,0);
        jsonObject.put(Consts.MSG,"修改失败！");
        return jsonObject;

    }

    /*
     * 查询所有
     * */
    @RequestMapping(value = "/selectAllZhuXueJinType",method = RequestMethod.GET)
    public Object selectAllZhuXueJinType(HttpServletRequest request){
        return zhuXueJinTypeService.selectAllZhuXueJinType();
    }

    /*
     * 根据id(主键)查询整个对象
     * */
    @RequestMapping(value = "/selectZhuXueJinTypeByKey",method = RequestMethod.GET)
    public Object selectZhuXueJinTypeByKey(HttpServletRequest request){
        String id = request.getParameter("id").trim();
        return zhuXueJinTypeService.selectZhuXueJinTypeByKey(Integer.parseInt(id));
    }

    //根据工号精确查询
    @RequestMapping(value = "/selectZhuXueJinTypeByType",method = RequestMethod.GET)
    public Object selectZhuXueJinTypeByType(HttpServletRequest request){
        String type = request.getParameter("type").trim();
        return zhuXueJinTypeService.selectZhuXueJinTypeByType(type);
    }

}
