package com.sjf.scholarships.controller;

import com.alibaba.fastjson.JSONObject;
import com.sjf.scholarships.domain.JiangXueJinType;
import com.sjf.scholarships.domain.Office;
import com.sjf.scholarships.service.JiangXueJinTypeService;
import com.sjf.scholarships.service.OfficeService;
import com.sjf.scholarships.utils.Consts;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/jiangxuejintype")
public class JiangXueJinTypeController {

    @Autowired
    private JiangXueJinTypeService jiangXueJinTypeService;
    /*
     * 添加
     * */
    @RequestMapping(value = "/add",method = RequestMethod.POST)
    public Object addJingXueJinType(HttpServletRequest request) {
        JSONObject jsonObject = new JSONObject();
        String type = request.getParameter("type").trim();

        if(type == null || "".equals(type)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"奖学金类型不能为空！");
            return jsonObject;
        }

        // 保存到对象中
        JiangXueJinType jiangXueJinType = new JiangXueJinType();
        jiangXueJinType.setType(type);

        boolean flag = jiangXueJinTypeService.insert(jiangXueJinType);
        if(flag){
            jsonObject.put(Consts.CODE,1);
            jsonObject.put(Consts.MSG,"添加成功！");
            return jsonObject;
        }
        jsonObject.put(Consts.CODE,0);
        jsonObject.put(Consts.MSG,"添加失败！");
        return jsonObject;

    }

    /*
     * 删除
     * */
    @RequestMapping(value = "/delete",method = RequestMethod.GET)
    public Object deleteJingXueJinType(HttpServletRequest request){
        String id = request.getParameter("id").trim();
        boolean flag = jiangXueJinTypeService.delete(Integer.parseInt(id));
        return flag;
    }

    /*
     * 修改
     * */
    @RequestMapping(value = "/update",method = RequestMethod.POST)
    public Object updateJingXueJinType(HttpServletRequest request){
        JSONObject jsonObject = new JSONObject();
        String id = request.getParameter("id").trim();
        String type = request.getParameter("type").trim();


        if(type == null || "".equals(type)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"用户名不能为空！");
            return jsonObject;
        }


        // 保存到辅导员的对象中
        // 保存到对象中
        JiangXueJinType jiangXueJinType = new JiangXueJinType();
        jiangXueJinType.setId(Integer.parseInt(id));
        jiangXueJinType.setType(type);

        boolean flag = jiangXueJinTypeService.update(jiangXueJinType);

        if(flag){
            jsonObject.put(Consts.CODE,1);
            jsonObject.put(Consts.MSG,"修改成功！");
            return jsonObject;
        }
        jsonObject.put(Consts.CODE,0);
        jsonObject.put(Consts.MSG,"修改失败！");
        return jsonObject;

    }

    /*
     * 查询所有
     * */
    @RequestMapping(value = "/selectAllJingXueJinType",method = RequestMethod.GET)
    public Object selectAllJingXueJinType(HttpServletRequest request){
        return jiangXueJinTypeService.selectAllJiangXueJinType();
    }

    /*
     * 根据id(主键)查询整个对象
     * */
    @RequestMapping(value = "/selectJingXueJinTypeByKey",method = RequestMethod.GET)
    public Object selectJingXueJinTypeByKey(HttpServletRequest request){
        String id = request.getParameter("id").trim();
        return jiangXueJinTypeService.selectJiangXueJinTypeByKey(Integer.parseInt(id));
    }

    //根据工号精确查询
    @RequestMapping(value = "/selectJingXueJinTypeByType",method = RequestMethod.GET)
    public Object selectJingXueJinTypeByType(HttpServletRequest request){
        String type = request.getParameter("type").trim();
        return jiangXueJinTypeService.selectJiangXueJinTypeByType(type);
    }

}
