package com.sjf.scholarships.controller;

import com.alibaba.fastjson.JSONObject;
import com.sjf.scholarships.domain.Admin;
import com.sjf.scholarships.domain.Student;
import com.sjf.scholarships.service.AdminService;
import com.sjf.scholarships.utils.Consts;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@RestController
@RequestMapping("/admin")
public class AdminController {
    @Autowired
    private AdminService adminService;

    /*
    * 判断管理员是否登录成功(status 状态)
    * */
    @RequestMapping(value = "/login/status",method = RequestMethod.POST)
    //需要从前端获取数据（一些get或post方法传来的请求，所以需要HttpServletRequest），
    public Object loginStatus(HttpServletRequest request, HttpSession session){
        JSONObject jsonObject = new JSONObject();
        //getParameter就是获取前端表单中对应的name的值
        String username = request.getParameter("username").trim();
        String password = request.getParameter("password").trim();
        String role = request.getParameter("role");
        boolean flag = adminService.verifyPassword(username,password,role);
        if(flag){
            //用json传递数据到前端
            jsonObject.put(Consts.CODE,1);
            jsonObject.put(Consts.MSG,"管理员，登录成功！");
            session.setAttribute(Consts.USERNAME,username);
            return jsonObject;
        }
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"用户名或密码错误！");
            return jsonObject;
    }

    /*
    *根据登录的用户名查询个人信息
    * */
    @RequestMapping(value = "/selectAdminByUsername", method = RequestMethod.POST)
    public Object selectAdminByUsername(HttpServletRequest request){
        String username = request.getParameter("username").trim();
        return adminService.selectAdminByUsername(username);
    }

    /*
     * 查询所有
     * */
    @RequestMapping(value = "/selectAllAdmin",method = RequestMethod.GET)
    public Object selectAllAdmin(HttpServletRequest request){
        return adminService.selectAllAdmin();
    }
    /*
    * 修改密码
    * */
    @RequestMapping(value = "/updateMine",method = RequestMethod.POST)
    public Object updateMine(HttpServletRequest request){
        JSONObject jsonObject = new JSONObject();
        String id = request.getParameter("id").trim();
        String passwordAgain = request.getParameter("passwordAgain").trim();
        String password = request.getParameter("password").trim();



        if(password == null || "".equals(password)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"用户名不能为空！");
            return jsonObject;
        }
        if(passwordAgain == null || "".equals(passwordAgain)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"密码不能为空！");
            return jsonObject;
        }
        if(!password.equals(passwordAgain)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"两次密码不一致！");
            return jsonObject;
        }


//       保存到用户的对象中
        Admin admin = new Admin();
        admin.setId(Integer.parseInt(id));
        admin.setPassword(password);
        boolean flag = adminService.update(admin);

        if(flag){
            jsonObject.put(Consts.CODE,1);
            jsonObject.put(Consts.MSG,"修改成功！");
            return jsonObject;
        }
        jsonObject.put(Consts.CODE,0);
        jsonObject.put(Consts.MSG,"修改失败！");
        return jsonObject;

    }

    /*
     * 更新头像
     * */
    @RequestMapping(value = "/updateAdminPic",method = RequestMethod.POST)
    public Object updateAdminPic(@RequestParam("file") MultipartFile avatorFile, @RequestParam("id")int id){
        JSONObject jsonObject = new JSONObject();

        if (avatorFile.isEmpty()){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"文件上传失败！");
            return jsonObject;
        }
//       文件名 = 当前时间到毫秒 + 原来的文件名
        String fileName = System.currentTimeMillis() + avatorFile.getOriginalFilename();
//        文件路径
        String filePath = System.getProperty("user.dir") + System.getProperty("file.separator") + "img"
                + System.getProperty("file.separator") + "adminPic";
//        如果文件路径不存在，新增路径
        File file1 = new File(filePath);
        if(!file1.exists()){
            file1.mkdir();
        }
//      实际的文件地址
        File dest = new File(filePath + System.getProperty("file.separator") + fileName);
//       存储到数据库里的相对文件地址
        String storeAvatorPath = "img/adminPic/" + fileName;
        try {
            avatorFile.transferTo(dest);
            Admin admin = new Admin();
            admin.setId(id);
            admin.setPhoto(storeAvatorPath);
            boolean flag = adminService.update(admin);

            if(flag){
                jsonObject.put(Consts.CODE,1);
                jsonObject.put(Consts.MSG,"上传成功!");
                jsonObject.put("pic",storeAvatorPath);
                return jsonObject;
            }
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"上传失败!");
            return jsonObject;
        } catch (IOException e) {
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"上传失败!"+e.getMessage());
        }finally {
            return jsonObject;
        }

    }


}
