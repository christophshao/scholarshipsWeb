package com.sjf.scholarships.controller;

import com.alibaba.fastjson.JSONObject;
import com.sjf.scholarships.domain.Office;
import com.sjf.scholarships.domain.Student;
import com.sjf.scholarships.domain.Teacher;
import com.sjf.scholarships.service.OfficeService;
import com.sjf.scholarships.service.TeacherService;
import com.sjf.scholarships.utils.Consts;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@RestController
@RequestMapping("/office")
public class OfficeController {

    @Autowired
    private OfficeService officeService;

    /*
     * 判断辅导员是否登录成功(status 状态)
     * */
    @RequestMapping(value = "/login/status",method = RequestMethod.POST)
    //需要从前端获取数据（一些get或post方法传来的请求，所以需要HttpServletRequest），
    public Object OfficeLoginStatus(HttpServletRequest request, HttpSession session){
        JSONObject jsonObject = new JSONObject();
        //getParameter就是获取前端表单中对应的值
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String role = request.getParameter("role");
        boolean flag = officeService.verifyPassword(username,password,role);
        if(flag){
            //用json传递数据到前端
            jsonObject.put(Consts.CODE,1);
            jsonObject.put(Consts.MSG,"教务处，登录成功！");
            // 将前端表单拿到的值 存入session
            session.setAttribute(Consts.USERNAME,username);
            return jsonObject;
        }
        jsonObject.put(Consts.CODE,0);
        jsonObject.put(Consts.MSG,"用户名或密码错误！");
        return jsonObject;
    }



    /*
     * 添加
     * */
    @RequestMapping(value = "/add",method = RequestMethod.POST)
    public Object addOffice(HttpServletRequest request) {
        JSONObject jsonObject = new JSONObject();
        String username = request.getParameter("username").trim();
        String password = request.getParameter("password").trim();
        String number = request.getParameter("number").trim();//工号
        String name = request.getParameter("name").trim();
        String phone = request.getParameter("phone").trim();  //本人电话号
        String email = request.getParameter("email").trim();

        if(username == null || "".equals(username)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"用户名不能为空！");
            return jsonObject;
        }
        if(password == null || "".equals(password)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"密码不能为空！");
            return jsonObject;
        }

        // 保存到对象中
        Office office = new Office();
        office.setUsername(username);
        office.setPassword(password);
        office.setNumber(number);
        office.setName(name);
        office.setPhone(phone);
        office.setEmail(email);

        boolean flag = officeService.insert(office);
        if(flag){
            jsonObject.put(Consts.CODE,1);
            jsonObject.put(Consts.MSG,"添加成功！");
            return jsonObject;
        }
        jsonObject.put(Consts.CODE,0);
        jsonObject.put(Consts.MSG,"添加失败！");
        return jsonObject;

    }

    /*
     * 删除
     * */
    @RequestMapping(value = "/delete",method = RequestMethod.GET)
    public Object deleteOffice(HttpServletRequest request){
        String id = request.getParameter("id").trim();
        boolean flag = officeService.delete(Integer.parseInt(id));
        return flag;
    }

    /*
     * 修改
     * */
    @RequestMapping(value = "/update",method = RequestMethod.POST)
    public Object updateOffice(HttpServletRequest request){
        JSONObject jsonObject = new JSONObject();
        String id = request.getParameter("id").trim();
        String username = request.getParameter("username").trim();
        String password = request.getParameter("password").trim();
        String number = request.getParameter("number").trim();//工号
        String name = request.getParameter("name").trim();
        String phone = request.getParameter("phone").trim();  //本人电话号
        String email = request.getParameter("email").trim();

        if(username == null || "".equals(username)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"用户名不能为空！");
            return jsonObject;
        }
        if(password == null || "".equals(password)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"密码不能为空！");
            return jsonObject;
        }

        // 保存到辅导员的对象中
        // 保存到对象中
        Office office = new Office();
        office.setId(Integer.parseInt(id));
        office.setUsername(username);
        office.setPassword(password);
        office.setNumber(number);
        office.setName(name);
        office.setPhone(phone);
        office.setEmail(email);
        boolean flag = officeService.update(office);

        if(flag){
            jsonObject.put(Consts.CODE,1);
            jsonObject.put(Consts.MSG,"修改成功！");
            return jsonObject;
        }
        jsonObject.put(Consts.CODE,0);
        jsonObject.put(Consts.MSG,"修改失败！");
        return jsonObject;

    }

    /*
     * 修改密码
     * */
    @RequestMapping(value = "/updateOfficePassword",method = RequestMethod.POST)
    public Object updateMine(HttpServletRequest request){
        JSONObject jsonObject = new JSONObject();
        String id = request.getParameter("id").trim();
        String passwordAgain = request.getParameter("passwordAgain").trim();
        String password = request.getParameter("password").trim();



        if(password == null || "".equals(password)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"用户名不能为空！");
            return jsonObject;
        }
        if(passwordAgain == null || "".equals(passwordAgain)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"密码不能为空！");
            return jsonObject;
        }
        if(!password.equals(passwordAgain)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"两次密码不一致！");
            return jsonObject;
        }


//       保存到用户的对象中
        Office office = new Office();
        office.setId(Integer.parseInt(id));
        office.setPassword(password);
        boolean flag = officeService.update(office);

        if(flag){
            jsonObject.put(Consts.CODE,1);
            jsonObject.put(Consts.MSG,"修改成功！");
            return jsonObject;
        }
        jsonObject.put(Consts.CODE,0);
        jsonObject.put(Consts.MSG,"修改失败！");
        return jsonObject;

    }


    /*
     * 查询所有
     * */
    @RequestMapping(value = "/selectAllOffice",method = RequestMethod.GET)
    public Object selectAllOffice(HttpServletRequest request){
        return officeService.selectAllOffice();
    }

    /*
     *根据登录的用户名查询个人信息
     * */
    @RequestMapping(value = "/selectByUsername", method = RequestMethod.POST)
    public Object selectByUsername(HttpServletRequest request){
        String username = request.getParameter("username").trim();
        return officeService.selectByUsername(username);
    }


    /*
     * 根据id(主键)查询整个对象
     * */
    @RequestMapping(value = "/selectOfficeByKey",method = RequestMethod.GET)
    public Object selectOfficerByKey(HttpServletRequest request){
        String id = request.getParameter("id").trim();
        return officeService.selectOfficeByKey(Integer.parseInt(id));
    }

    //根据工号精确查询
    @RequestMapping(value = "/selectOfficeByNumber",method = RequestMethod.GET)
    public Object selectOfficeByNumber(HttpServletRequest request){
        String number = request.getParameter("number").trim();
        return officeService.selectOfficeByNumber(number);
    }

    //根据名字模糊查询
    @RequestMapping(value = "/selectOfficeByName",method = RequestMethod.GET)
    public Object selectOfficeByName(HttpServletRequest request){
        String name = request.getParameter("name").trim();
        return officeService.selectOfficeByName("%"+name+"%");
    }

}
