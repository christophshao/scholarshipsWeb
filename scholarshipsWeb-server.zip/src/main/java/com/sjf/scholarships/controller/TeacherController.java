package com.sjf.scholarships.controller;

import com.alibaba.fastjson.JSONObject;
import com.sjf.scholarships.domain.Student;
import com.sjf.scholarships.domain.Teacher;
import com.sjf.scholarships.service.TeacherService;
import com.sjf.scholarships.utils.Consts;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@RestController
@RequestMapping("/teacher")
public class TeacherController {

    @Autowired
    private TeacherService teacherService;

    /*
     * 判断辅导员是否登录成功(status 状态)
     * */
    @RequestMapping(value = "/login/status",method = RequestMethod.POST)
    //需要从前端获取数据（一些get或post方法传来的请求，所以需要HttpServletRequest），
    public Object TeacherLoginStatus(HttpServletRequest request, HttpSession session){
        JSONObject jsonObject = new JSONObject();
        //getParameter就是获取前端表单中对应的值
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String role = request.getParameter("role");
        boolean flag = teacherService.verifyPassword(username,password,role);
        if(flag){
            //用json传递数据到前端
            jsonObject.put(Consts.CODE,1);
            jsonObject.put(Consts.MSG,"辅导员，登录成功！");
            // 将前端表单拿到的值 存入session
            session.setAttribute(Consts.USERNAME,username);
            return jsonObject;
        }
        jsonObject.put(Consts.CODE,0);
        jsonObject.put(Consts.MSG,"用户名或密码错误！");
        return jsonObject;
    }

    /*
     * 添加辅导员
     * */
    @RequestMapping(value = "/add",method = RequestMethod.POST)
    public Object addTeacher(HttpServletRequest request) {
        JSONObject jsonObject = new JSONObject();
        String username = request.getParameter("username").trim();
        String password = request.getParameter("password").trim();
        String number = request.getParameter("number").trim();//学号
        String photo = request.getParameter("photo").trim(); //学生照片
        String name = request.getParameter("name").trim();
        String sex = request.getParameter("sex").trim();
        String birth = request.getParameter("birth").trim();
        String mobilePhone = request.getParameter("mobilePhone").trim();  //本人电话号

        if(username == null || "".equals(username)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"用户名不能为空！");
            return jsonObject;
        }
        if(password == null || "".equals(password)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"密码不能为空！");
            return jsonObject;
        }

        //  把生日转换成Date格式
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date birthDate = new Date();
        try {
            birthDate = dateFormat.parse(birth);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        // 保存到辅导员的对象中
        Teacher teacher = new Teacher();
        teacher.setUsername(username);
        teacher.setPassword(password);
        teacher.setNumber(number);
        teacher.setName(name);
        teacher.setSex(sex);
        teacher.setPhoto(photo);
        teacher.setBirth(birthDate);
        teacher.setMobilePhone(mobilePhone);

        boolean flag = teacherService.insert(teacher);
        if(flag){
            jsonObject.put(Consts.CODE,1);
            jsonObject.put(Consts.MSG,"添加成功！");
            return jsonObject;
        }
        jsonObject.put(Consts.CODE,0);
        jsonObject.put(Consts.MSG,"添加失败！");
        return jsonObject;

    }

    /*
     * 删除辅导员
     * */
    @RequestMapping(value = "/delete",method = RequestMethod.GET)
    public Object deleteTeacher(HttpServletRequest request){
        String id = request.getParameter("id").trim();
        boolean flag = teacherService.delete(Integer.parseInt(id));
        return flag;
    }

    /*
     * 修改学生
     * */
    @RequestMapping(value = "/update",method = RequestMethod.POST)
    public Object updateTeacher(HttpServletRequest request){
        JSONObject jsonObject = new JSONObject();
        String id = request.getParameter("id").trim();
        String username = request.getParameter("username").trim();
        String password = request.getParameter("password").trim();
        String number = request.getParameter("number").trim();//工号
        String name = request.getParameter("name").trim();
        String sex = request.getParameter("sex").trim();
        String birth = request.getParameter("birth").trim();
        String mobilePhone = request.getParameter("mobilePhone").trim();  //本人电话号

        if(username == null || "".equals(username)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"用户名不能为空！");
            return jsonObject;
        }
        if(password == null || "".equals(password)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"密码不能为空！");
            return jsonObject;
        }

//       把生日转换成Date格式
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date birthDate = new Date();
        try {
            birthDate = dateFormat.parse(birth);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        // 保存到辅导员的对象中
        Teacher teacher = new Teacher();
        teacher.setId(Integer.parseInt(id));
        teacher.setUsername(username);
        teacher.setPassword(password);
        teacher.setNumber(number);
        teacher.setName(name);
        teacher.setSex(sex);
        teacher.setBirth(birthDate);
        teacher.setMobilePhone(mobilePhone);
        boolean flag = teacherService.update(teacher);

        if(flag){
            jsonObject.put(Consts.CODE,1);
            jsonObject.put(Consts.MSG,"修改成功！");
            return jsonObject;
        }
        jsonObject.put(Consts.CODE,0);
        jsonObject.put(Consts.MSG,"修改失败！");
        return jsonObject;

    }

    /*
     * 修改密码
     * */
    @RequestMapping(value = "/updateTeacherPassword",method = RequestMethod.POST)
    public Object updateTeacherPassword(HttpServletRequest request){
        JSONObject jsonObject = new JSONObject();
        String id = request.getParameter("id").trim();
        String passwordAgain = request.getParameter("passwordAgain").trim();
        String password = request.getParameter("password").trim();



        if(password == null || "".equals(password)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"用户名不能为空！");
            return jsonObject;
        }
        if(passwordAgain == null || "".equals(passwordAgain)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"密码不能为空！");
            return jsonObject;
        }
        if(!password.equals(passwordAgain)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"两次密码不一致！");
            return jsonObject;
        }


//       保存到用户的对象中
        Teacher teacher = new Teacher();
        teacher.setId(Integer.parseInt(id));
        teacher.setPassword(password);
        boolean flag = teacherService.update(teacher);

        if(flag){
            jsonObject.put(Consts.CODE,1);
            jsonObject.put(Consts.MSG,"修改成功！");
            return jsonObject;
        }
        jsonObject.put(Consts.CODE,0);
        jsonObject.put(Consts.MSG,"修改失败！");
        return jsonObject;

    }


    /*
     * 查询所有学生
     * */
    @RequestMapping(value = "/selectAllTeacher",method = RequestMethod.GET)
    public Object selectAllTeacher(HttpServletRequest request){
        return teacherService.selectAllTeacher();
    }

    /*
     *根据登录的用户名查询个人信息
     * */
    @RequestMapping(value = "/selectByUsername", method = RequestMethod.POST)
    public Object selectByUsername(HttpServletRequest request){
        String username = request.getParameter("username").trim();
        return teacherService.selectByUsername(username);
    }

    /*
     * 根据id(主键)查询整个对象
     * */
    @RequestMapping(value = "/selectTeacherByKey",method = RequestMethod.GET)
    public Object selectTeacherByKey(HttpServletRequest request){
        String id = request.getParameter("id").trim();
        return teacherService.selectTeacherByKey(Integer.parseInt(id));
    }

    //根据学生学号精确查询
    @RequestMapping(value = "/selectTeacherByNumber",method = RequestMethod.GET)
    public Object selectTeacherByNumber(HttpServletRequest request){
        String number = request.getParameter("number").trim();
        return teacherService.selectTeacherByName(number);
    }

    //根据学生名字模糊查询
    @RequestMapping(value = "/selectTeacherByName",method = RequestMethod.GET)
    public Object selectTeacherByName(HttpServletRequest request){
        String name = request.getParameter("name").trim();
        return teacherService.selectTeacherByName("%"+name+"%");
    }

    /*
     * 更新学生照片
     * */
    @RequestMapping(value = "/updateTeacherPic",method = RequestMethod.POST)
    public Object updateTeacherPic(@RequestParam("file") MultipartFile avatorFile, @RequestParam("id")int id){
        JSONObject jsonObject = new JSONObject();

        if (avatorFile.isEmpty()){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"文件上传失败！");
            return jsonObject;
        }
//       文件名 = 当前时间到毫秒 + 原来的文件名
        String fileName = System.currentTimeMillis() + avatorFile.getOriginalFilename();
//        文件路径
        String filePath = System.getProperty("user.dir") + System.getProperty("file.separator") + "img"
                + System.getProperty("file.separator") + "teacherPic";
//        如果文件路径不存在，新增路径
        File file1 = new File(filePath);
        if(!file1.exists()){
            file1.mkdir();
        }
//      实际的文件地址
        File dest = new File(filePath + System.getProperty("file.separator") + fileName);
//       存储到数据库里的相对文件地址
        String storeAvatorPath = "img/teacherPic/" + fileName;
        try {
            avatorFile.transferTo(dest);
            Teacher teacher = new Teacher();
            teacher.setId(id);
            teacher.setPhoto(storeAvatorPath);
            boolean flag = teacherService.update(teacher);

            if(flag){
                jsonObject.put(Consts.CODE,1);
                jsonObject.put(Consts.MSG,"上传成功!");
                jsonObject.put("pic",storeAvatorPath);
                return jsonObject;
            }
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"上传失败!");
            return jsonObject;
        } catch (IOException e) {
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"上传失败!"+e.getMessage());
        }finally {
            return jsonObject;
        }

    }


}
