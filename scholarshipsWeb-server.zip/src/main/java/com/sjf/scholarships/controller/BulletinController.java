package com.sjf.scholarships.controller;

import com.alibaba.fastjson.JSONObject;
import com.sjf.scholarships.domain.Bulletin;
import com.sjf.scholarships.service.BulletinService;
import com.sjf.scholarships.utils.Consts;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/bulletin")
public class BulletinController {

    @Autowired
    private BulletinService bulletinService;
    /*
     * 添加
     * */
    @RequestMapping(value = "/add",method = RequestMethod.POST)
    public Object addBulletin(HttpServletRequest request) {
        JSONObject jsonObject = new JSONObject();
        String title = request.getParameter("title").trim();
        String author = request.getParameter("author").trim();
        String news = request.getParameter("news").trim();//
        String type = request.getParameter("type").trim();


        if(title == null || "".equals(title)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"标题不能为空！");
            return jsonObject;
        }

        // 保存到对象中
        Bulletin bulletin = new Bulletin();
        bulletin.setTitle(title);
        bulletin.setAuthor(author);
        bulletin.setNews(news);
        bulletin.setType(type);

        boolean flag = bulletinService.insert(bulletin);
        if(flag){
            jsonObject.put(Consts.CODE,1);
            jsonObject.put(Consts.MSG,"添加成功！");
            return jsonObject;
        }
        jsonObject.put(Consts.CODE,0);
        jsonObject.put(Consts.MSG,"添加失败！");
        return jsonObject;

    }

    /*
     * 删除
     * */
    @RequestMapping(value = "/delete",method = RequestMethod.GET)
    public Object deleteBulletin(HttpServletRequest request){
        String id = request.getParameter("id").trim();
        boolean flag = bulletinService.delete(Integer.parseInt(id));
        return flag;
    }

    /*
     * 修改
     * */
    @RequestMapping(value = "/update",method = RequestMethod.POST)
    public Object updateBulletin(HttpServletRequest request){
        JSONObject jsonObject = new JSONObject();
        String id = request.getParameter("id").trim();
        String title = request.getParameter("title").trim();
        String author = request.getParameter("author").trim();
        String news = request.getParameter("news").trim();//
        String type = request.getParameter("type").trim();

        if(title == null || "".equals(title)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"标题不能为空！");
            return jsonObject;
        }

        // 保存到对象中
        Bulletin bulletin = new Bulletin();
        bulletin.setId(Integer.parseInt(id));
        bulletin.setTitle(title);
        bulletin.setAuthor(author);
        bulletin.setNews(news);
        bulletin.setType(type);
        boolean flag = bulletinService.update(bulletin);

        if(flag){
            jsonObject.put(Consts.CODE,1);
            jsonObject.put(Consts.MSG,"修改成功！");
            return jsonObject;
        }
        jsonObject.put(Consts.CODE,0);
        jsonObject.put(Consts.MSG,"修改失败！");
        return jsonObject;

    }

    /*
     * 查询所有
     * */
    @RequestMapping(value = "/selectAllBulletin",method = RequestMethod.GET)
    public Object selectAllBulletin(HttpServletRequest request){
        return bulletinService.selectAllBulletin();
    }

    /*
     * 根据id(主键)查询整个对象
     * */
    @RequestMapping(value = "/selectBulletinForJiang",method = RequestMethod.GET)
    public Object selectBulletinForJiang(HttpServletRequest request){
        String type = request.getParameter("type").trim();
        return bulletinService.selectBulletinForJiang(type);
    }
    /*
     * 根据id(主键)查询整个对象
     * */
    @RequestMapping(value = "/selectBulletinByKey",method = RequestMethod.GET)
    public Object selectBulletinrByKey(HttpServletRequest request){
        String id = request.getParameter("id");
        return bulletinService.selectBulletinByKey(Integer.parseInt(id));
    }


    //根据标题模糊查询
    @RequestMapping(value = "/selectBulletinByTitle",method = RequestMethod.GET)
    public Object selectBulletinByName(HttpServletRequest request){
        String title = request.getParameter("title").trim();
        return bulletinService.selectBulletinByTitle("%"+title+"%");
    }

}
