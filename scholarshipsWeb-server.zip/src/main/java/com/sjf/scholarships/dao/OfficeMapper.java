package com.sjf.scholarships.dao;

import com.sjf.scholarships.domain.Admin;
import com.sjf.scholarships.domain.Office;
import com.sjf.scholarships.domain.Teacher;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface OfficeMapper {
    //添加
    public int insert(Office office);

    // 删除
    public int delete(Integer id);

    // 修改
    public int update(Office office);

    // 查询所有
    public List<Office> selectAllOffice();

    // 根据姓名模糊查询
    public Office selectOfficeByName(String name);

    // 根据主键查询
    public Office selectOfficeByKey(Integer id);

    // 根据工号查询
    public Office selectOfficeByNumber(String number);

    // 校验登录身份
    public int verifyPassword(String username,String password,String role);

    //  根据用户名查询用户信息
    public Office selectByUsername(String username);
}
