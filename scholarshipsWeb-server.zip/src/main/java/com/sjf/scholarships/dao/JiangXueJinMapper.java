package com.sjf.scholarships.dao;

import com.sjf.scholarships.domain.JiangXueJin;
import com.sjf.scholarships.domain.Office;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface JiangXueJinMapper {
    //添加
    public int insert(JiangXueJin jiangXueJin);

    // 删除
    public int delete(Integer id);

    // 修改
    public int update(JiangXueJin jiangXueJin);

    // 查询所有
    public List<JiangXueJin> selectAllJiangXueJin();

    // 根据姓名模糊查询
    public JiangXueJin selectJiangXueJinByName(String name);

    // 根据主键查询
    public JiangXueJin selectJiangXueJinByKey(Integer id);

    // 根据工号查询
    public JiangXueJin selectJiangXueJinByNumber(String number);
}
