package com.sjf.scholarships.dao;

import com.sjf.scholarships.domain.Admin;
import com.sjf.scholarships.domain.Teacher;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface TeacherMapper {
    //添加辅导员
    public int insert(Teacher teacher);

    // 删除辅导员
    public int delete(Integer id);

    // 修改辅导员信息
    public int update(Teacher teacher);

    // 查询所有辅导员
    public List<Teacher> selectAllTeacher();

    // 根据辅导员姓名模糊查询
    public Teacher selectTeacherByName(String name);

    // 根据主键查询
    public Teacher selectTeacherByKey(Integer id);

    // 根据教职工号查询
    public Teacher selectTeacherByNumber(String number);

    // 校验登录身份
    public int verifyPassword(String username,String password,String role);

    //  根据用户名查询用户信息
    public Teacher selectByUsername(String username);
}
