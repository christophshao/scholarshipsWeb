package com.sjf.scholarships.dao;

import com.sjf.scholarships.domain.PoorStudent;
import com.sjf.scholarships.domain.ZhuXueJinApply;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ZhuXueJinApplyMapper {
    //添加
    public int insert(ZhuXueJinApply zhuXueJinApply);

    // 删除
    public int delete(Integer id);

    // 修改
    public int update(ZhuXueJinApply zhuXueJinApply);

    // 辅导员助学金审批
    public int updateZhuXueJinApplyForTeacher(ZhuXueJinApply zhuXueJinApply);

    // 教务处助学金审批
    public int updateZhuXueJinApplyForOffice(ZhuXueJinApply zhuXueJinApply);

    // 查询所有
    public List<ZhuXueJinApply> selectAllZhuXueJinApply();

    // 查询辅导员审批同意的助助学金申请学生信息
    public List<ZhuXueJinApply> selectZhuXueJinApplyByTeacherPass();

    // 根据姓名模糊查询
    public ZhuXueJinApply selectZhuXueJinApplyByName(String name);

    // 根据主键查询
    public ZhuXueJinApply selectZhuXueJinApplyByKey(Integer id);

    // 根据学号查询
    public ZhuXueJinApply selectZhuXueJinApplyByNumber(String number);
}
