package com.sjf.scholarships.dao;

import com.sjf.scholarships.domain.Bulletin;
import com.sjf.scholarships.domain.Office;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BulletinMapper {
    //添加
    public int insert(Bulletin bulletin);

    // 删除
    public int delete(Integer id);

    // 修改
    public int update(Bulletin bulletin);

    // 查询所有
    public List<Bulletin> selectAllBulletin();

    // 根据标题模糊查询
    public Bulletin selectBulletinByTitle(String title);

    // 根据主键查询
    public Bulletin selectBulletinByKey(Integer id);

    //  根据type查询信息
    public Bulletin selectBulletinForJiang(String type);
}
