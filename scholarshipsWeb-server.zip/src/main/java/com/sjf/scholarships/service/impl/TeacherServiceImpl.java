package com.sjf.scholarships.service.impl;


import com.sjf.scholarships.dao.TeacherMapper;
import com.sjf.scholarships.domain.Admin;
import com.sjf.scholarships.domain.Teacher;
import com.sjf.scholarships.service.TeacherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class TeacherServiceImpl implements TeacherService {

    @Autowired(required = false)
    private TeacherMapper teacherMapper;

    @Override
    public boolean verifyPassword(String username, String password,String role) {
        return teacherMapper.verifyPassword(username,password,role)>0;
    }
    @Override
    public boolean insert(Teacher teacher) {
        return teacherMapper.insert(teacher)>0;
    }

    @Override
    public boolean delete(Integer id) {
        return teacherMapper.delete(id)>0;
    }

    @Override
    public boolean update(Teacher teacher) {
        return teacherMapper.update(teacher)>0;
    }

    @Override
    public List<Teacher> selectAllTeacher() {
        return teacherMapper.selectAllTeacher();
    }
    @Override
    public Teacher selectTeacherByKey(Integer id) {
        return teacherMapper.selectTeacherByKey(id);
    }

    @Override
    public Teacher selectTeacherByNumber(String number) {
        return teacherMapper.selectTeacherByNumber(number);
    }

    @Override
    public Teacher selectTeacherByName(String name) {
        return teacherMapper.selectTeacherByName(name);
    }

    @Override
    public Teacher selectByUsername(String username) {
        return teacherMapper.selectByUsername(username);
    }

}
