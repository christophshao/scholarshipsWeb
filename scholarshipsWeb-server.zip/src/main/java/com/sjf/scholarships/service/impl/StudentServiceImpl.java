package com.sjf.scholarships.service.impl;

import com.sjf.scholarships.dao.StudentMapper;
import com.sjf.scholarships.domain.Admin;
import com.sjf.scholarships.domain.Student;
import com.sjf.scholarships.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class StudentServiceImpl implements StudentService {

    @Override
    public boolean verifyPassword(String username, String password,String role) {
        return studentMapper.verifyPassword(username,password,role)>0;
    }

    @Autowired
    private StudentMapper studentMapper;

    @Override
    public boolean insert(Student student) {
        return studentMapper.insert(student)>0;
    }

    @Override
    public boolean delete(Integer id) {
        return studentMapper.delete(id)>0;
    }

    @Override
    public boolean update(Student student) {
        return studentMapper.update(student)>0;
    }

    @Override
    public List<Student> selectAllStudent() {
        return studentMapper.selectAllStudent();
    }

    @Override
    public Student selectByUsername(String username) {
        return studentMapper.selectByUsername(username);
    }

    @Override
    public Student selectStudentByKey(Integer id) {
        return studentMapper.selectStudentByKey(id);
    }

    @Override
    public Student selectStudentByNumber(String number) {
        return studentMapper.selectStudentByNumber(number);
    }

    @Override
    public Student selectStudentByName(String name) {
        return studentMapper.selectStudentByName(name);
    }
}
