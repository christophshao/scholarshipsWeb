package com.sjf.scholarships.service;

import com.sjf.scholarships.domain.Admin;
import com.sjf.scholarships.domain.Student;

import java.util.List;

public interface AdminService {
    public boolean verifyPassword(String username,String password,String role);

    //  根据用户名查询用户信息
    public Admin selectAdminByUsername(String username);

    // 查询所有
    public List<Admin> selectAllAdmin();

    // 修改信息
    public boolean update(Admin admin);
}
