package com.sjf.scholarships.service;

import com.sjf.scholarships.domain.PoorStudent;
import com.sjf.scholarships.domain.ZhuXueJinApply;

import java.util.List;

public interface ZhuXueJinApplyService {
    // 添加
    public boolean insert(ZhuXueJinApply zhuXueJinApply);

    // 删除
    public boolean delete(Integer id);

    // 修改信息
    public boolean update(ZhuXueJinApply zhuXueJinApply);

    // 辅导员审批
    public boolean updateZhuXueJinApplyForTeacher(ZhuXueJinApply zhuXueJinApply);

    // 教务处审批
    public boolean updateZhuXueJinApplyForOffice(ZhuXueJinApply zhuXueJinApply);

    // 根据id查询
    public ZhuXueJinApply selectZhuXueJinApplyByKey(Integer id);

    // 根据工号查询
    public ZhuXueJinApply selectZhuXueJinApplyByNumber(String number);

    // 查询所有
    public List<ZhuXueJinApply> selectAllZhuXueJinApply();

    // 查询辅导员审批同意的助助学金申请学生信息
    public List<ZhuXueJinApply> selectZhuXueJinApplyByTeacherPass();


    // 根据姓名模糊查询
    public ZhuXueJinApply selectZhuXueJinApplyByName(String name);
}
