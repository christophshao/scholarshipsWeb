package com.sjf.scholarships.service.impl;


import com.sjf.scholarships.dao.JiangXueJinMapper;
import com.sjf.scholarships.dao.OfficeMapper;
import com.sjf.scholarships.domain.JiangXueJin;
import com.sjf.scholarships.domain.Office;
import com.sjf.scholarships.service.JiangXueJinService;
import com.sjf.scholarships.service.OfficeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class JiangXueJinServiceImpl implements JiangXueJinService {
    @Autowired(required = false)
    private JiangXueJinMapper jiangXueJinMapper;

    @Override
    public boolean insert(JiangXueJin jiangXueJin) {
        return jiangXueJinMapper.insert(jiangXueJin)>0;
    }

    @Override
    public boolean delete(Integer id) {
        return jiangXueJinMapper.delete(id)>0;
    }

    @Override
    public boolean update(JiangXueJin jiangXueJin) {
        return jiangXueJinMapper.update(jiangXueJin)>0;
    }

    @Override
    public List<JiangXueJin> selectAllJiangXueJin() {
        return jiangXueJinMapper.selectAllJiangXueJin();
    }
    @Override
    public JiangXueJin selectJiangXueJinByKey(Integer id) {
        return jiangXueJinMapper.selectJiangXueJinByKey(id);
    }

    @Override
    public JiangXueJin selectJiangXueJinByNumber(String number) {
        return jiangXueJinMapper.selectJiangXueJinByNumber(number);
    }

    @Override
    public JiangXueJin selectJiangXueJinByName(String name) {
        return jiangXueJinMapper.selectJiangXueJinByName(name);
    }
}
