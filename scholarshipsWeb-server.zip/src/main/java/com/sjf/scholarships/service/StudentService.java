package com.sjf.scholarships.service;

import com.sjf.scholarships.domain.Admin;
import com.sjf.scholarships.domain.Student;
import com.sjf.scholarships.domain.Teacher;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public interface StudentService {
    //校验登录身份
    public boolean verifyPassword(String username,String password,String role);

    // 添加学生
    public boolean insert(Student student);

    // 删除学生
    public boolean delete(Integer id);

    // 修改学生信息
    public boolean update(Student student);

    //  根据用户名查询用户信息
    public Student selectByUsername(String username);

    // 根据id查询学生
    public Student selectStudentByKey(Integer id);

    // 根据学号查询学生
    public Student selectStudentByNumber(String number);

    // 查询所有学生
    public List<Student> selectAllStudent();

    // 根据学生姓名模糊查询学生
    public Student selectStudentByName(String name);
}
