package com.sjf.scholarships.service;

import com.sjf.scholarships.domain.JiangXueJinType;
import com.sjf.scholarships.domain.Office;

import java.util.List;

public interface JiangXueJinTypeService {
    // 添加
    public boolean insert(JiangXueJinType jiangXueJinType);

    // 删除
    public boolean delete(Integer id);

    // 修改信息
    public boolean update(JiangXueJinType jiangXueJinType);

    // 根据id查询
    public JiangXueJinType selectJiangXueJinTypeByKey(Integer id);

    // 根据工号查询
    public JiangXueJinType selectJiangXueJinTypeByType(String type);

    // 查询所有
    public List<JiangXueJinType> selectAllJiangXueJinType();
}
