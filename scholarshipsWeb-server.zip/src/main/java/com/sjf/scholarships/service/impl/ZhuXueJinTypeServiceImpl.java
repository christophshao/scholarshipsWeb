package com.sjf.scholarships.service.impl;


import com.sjf.scholarships.dao.ZhuXueJinTypeMapper;
import com.sjf.scholarships.domain.ZhuXueJinType;
import com.sjf.scholarships.service.ZhuXueJinTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ZhuXueJinTypeServiceImpl implements ZhuXueJinTypeService {
    @Autowired(required = false)
    private ZhuXueJinTypeMapper zhuXueJinTypeMapper;

    @Override
    public boolean insert(ZhuXueJinType zhuXueJinType) {
        return zhuXueJinTypeMapper.insert(zhuXueJinType)>0;
    }

    @Override
    public boolean delete(Integer id) {
        return zhuXueJinTypeMapper.delete(id)>0;
    }

    @Override
    public boolean update(ZhuXueJinType zhuXueJinType) {
        return zhuXueJinTypeMapper.update(zhuXueJinType)>0;
    }

    @Override
    public List<ZhuXueJinType> selectAllZhuXueJinType() {
        return zhuXueJinTypeMapper.selectAllZhuXueJinType();
    }
    @Override
    public ZhuXueJinType selectZhuXueJinTypeByKey(Integer id) {
        return zhuXueJinTypeMapper.selectZhuXueJinTypeByKey(id);
    }

    @Override
    public ZhuXueJinType selectZhuXueJinTypeByType(String type) {
        return zhuXueJinTypeMapper.selectZhuXueJinTypeByType(type);
    }
}
