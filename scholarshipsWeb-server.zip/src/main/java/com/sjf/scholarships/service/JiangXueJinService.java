package com.sjf.scholarships.service;

import com.sjf.scholarships.domain.JiangXueJin;
import com.sjf.scholarships.domain.Office;

import java.util.List;

public interface JiangXueJinService {
    // 添加
    public boolean insert(JiangXueJin jiangXueJin);

    // 删除
    public boolean delete(Integer id);

    // 修改信息
    public boolean update(JiangXueJin jiangXueJin);

    // 根据id查询
    public JiangXueJin selectJiangXueJinByKey(Integer id);

    // 根据工号查询
    public JiangXueJin selectJiangXueJinByNumber(String number);

    // 查询所有
    public List<JiangXueJin> selectAllJiangXueJin();

    // 根据姓名模糊查询
    public JiangXueJin selectJiangXueJinByName(String name);
}
