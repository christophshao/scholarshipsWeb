package com.sjf.scholarships.service;

import com.sjf.scholarships.domain.Admin;
import com.sjf.scholarships.domain.Office;
import com.sjf.scholarships.domain.Teacher;

import java.util.List;

public interface OfficeService {
    //校验登录身份
    public boolean verifyPassword(String username,String password,String role);

    // 添加
    public boolean insert(Office office);

    // 删除
    public boolean delete(Integer id);

    // 修改信息
    public boolean update(Office office);

    // 根据id查询
    public Office selectOfficeByKey(Integer id);

    // 根据工号查询
    public Office selectOfficeByNumber(String number);

    // 查询所有
    public List<Office> selectAllOffice();

    // 根据姓名模糊查询
    public Office selectOfficeByName(String name);

    //  根据用户名查询用户信息
    public Office selectByUsername(String username);
}
