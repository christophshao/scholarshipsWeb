package com.sjf.scholarships.service.impl;


import com.sjf.scholarships.dao.ZhuXueJinApplyMapper;
import com.sjf.scholarships.domain.PoorStudent;
import com.sjf.scholarships.domain.ZhuXueJinApply;
import com.sjf.scholarships.service.ZhuXueJinApplyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ZhuXueJinApplyServiceImpl implements ZhuXueJinApplyService {
    @Autowired(required = false)
    private ZhuXueJinApplyMapper zhuXueJinApplyMapper;

    @Override
    public boolean insert(ZhuXueJinApply zhuXueJinApply) {
        return zhuXueJinApplyMapper.insert(zhuXueJinApply)>0;
    }

    @Override
    public boolean delete(Integer id) {
        return zhuXueJinApplyMapper.delete(id)>0;
    }

    @Override
    public boolean update(ZhuXueJinApply zhuXueJinApply) {
        return zhuXueJinApplyMapper.update(zhuXueJinApply)>0;
    }
    @Override
    public boolean updateZhuXueJinApplyForTeacher(ZhuXueJinApply zhuXueJinApply) {
        return zhuXueJinApplyMapper.updateZhuXueJinApplyForTeacher(zhuXueJinApply)>0;
    }

    @Override
    public boolean updateZhuXueJinApplyForOffice(ZhuXueJinApply zhuXueJinApply) {
        return zhuXueJinApplyMapper.updateZhuXueJinApplyForOffice(zhuXueJinApply)>0;
    }

    @Override
    public List<ZhuXueJinApply> selectAllZhuXueJinApply() {
        return zhuXueJinApplyMapper.selectAllZhuXueJinApply();
    }

    // 查询辅导员审批同意的助助学金申请学生信息
    @Override
    public List<ZhuXueJinApply> selectZhuXueJinApplyByTeacherPass() {
        return zhuXueJinApplyMapper.selectZhuXueJinApplyByTeacherPass();
    }


    @Override
    public ZhuXueJinApply selectZhuXueJinApplyByKey(Integer id) {
        return zhuXueJinApplyMapper.selectZhuXueJinApplyByKey(id);
    }

    @Override
    public ZhuXueJinApply selectZhuXueJinApplyByNumber(String number) {
        return zhuXueJinApplyMapper.selectZhuXueJinApplyByNumber(number);
    }

    @Override
    public ZhuXueJinApply selectZhuXueJinApplyByName(String name) {
        return zhuXueJinApplyMapper.selectZhuXueJinApplyByName(name);
    }
}
