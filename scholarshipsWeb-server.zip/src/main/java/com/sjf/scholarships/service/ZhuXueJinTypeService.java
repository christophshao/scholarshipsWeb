package com.sjf.scholarships.service;

import com.sjf.scholarships.domain.ZhuXueJinType;

import java.util.List;

public interface ZhuXueJinTypeService {
    // 添加
    public boolean insert(ZhuXueJinType zhuXueJinType);

    // 删除
    public boolean delete(Integer id);

    // 修改信息
    public boolean update(ZhuXueJinType zhuXueJinType);

    // 根据id查询
    public ZhuXueJinType selectZhuXueJinTypeByKey(Integer id);

    // 根据工号查询
    public ZhuXueJinType selectZhuXueJinTypeByType(String type);

    // 查询所有
    public List<ZhuXueJinType> selectAllZhuXueJinType();
}
