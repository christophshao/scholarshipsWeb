package com.sjf.scholarships.service;

import com.sjf.scholarships.domain.JiangXueJinApply;
import com.sjf.scholarships.domain.JiangXueJinApply;

import java.util.List;

public interface JiangXueJinApplyService {
    // 添加
    public boolean insert(JiangXueJinApply jiangXueJinApply);

    // 删除
    public boolean delete(Integer id);

    // 修改信息
    public boolean update(JiangXueJinApply jiangXueJinApply);

    // 辅导员审批
    public boolean updateJiangXueJinApplyForTeacher(JiangXueJinApply jiangXueJinApply);

    // 教务处审批
    public boolean updateJiangXueJinApplyForOffice(JiangXueJinApply jiangXueJinApply);

    // 根据id查询
    public JiangXueJinApply selectJiangXueJinApplyByKey(Integer id);

    // 根据工号查询
    public JiangXueJinApply selectJiangXueJinApplyByNumber(String number);

    // 查询所有
    public List<JiangXueJinApply> selectAllJiangXueJinApply();

    // 查询辅导员审批同意的奖学金申请学生信息
    public List<JiangXueJinApply> selectJiangXueJinApplyByTeacherPass();



    // 根据姓名模糊查询
    public JiangXueJinApply selectJiangXueJinApplyByName(String name);
}
