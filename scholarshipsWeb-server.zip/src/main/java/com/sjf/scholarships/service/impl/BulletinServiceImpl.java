package com.sjf.scholarships.service.impl;


import com.sjf.scholarships.dao.BulletinMapper;
import com.sjf.scholarships.domain.Bulletin;
import com.sjf.scholarships.service.BulletinService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BulletinServiceImpl implements BulletinService {
    @Autowired(required = false)
    private BulletinMapper bulletinMapper;

    @Override
    public boolean insert(Bulletin bulletin) {
        return bulletinMapper.insert(bulletin)>0;
    }

    @Override
    public boolean delete(Integer id) {
        return bulletinMapper.delete(id)>0;
    }

    @Override
    public boolean update(Bulletin bulletin) {
        return bulletinMapper.update(bulletin)>0;
    }

    @Override
    public List<Bulletin> selectAllBulletin() {
        return bulletinMapper.selectAllBulletin();
    }
    @Override
    public Bulletin selectBulletinByKey(Integer id) {
        return bulletinMapper.selectBulletinByKey(id);
    }
    @Override
    public Bulletin selectBulletinByTitle(String title) {
        return bulletinMapper.selectBulletinByTitle(title);
    }

    @Override
    public Bulletin selectBulletinForJiang(String type) {
        return bulletinMapper.selectBulletinForJiang(type);
    }
}
