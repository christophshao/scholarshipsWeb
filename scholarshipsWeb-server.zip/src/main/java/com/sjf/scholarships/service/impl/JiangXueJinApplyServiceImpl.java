package com.sjf.scholarships.service.impl;


import com.sjf.scholarships.dao.JiangXueJinApplyMapper;
import com.sjf.scholarships.domain.JiangXueJinApply;
import com.sjf.scholarships.service.JiangXueJinApplyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class JiangXueJinApplyServiceImpl implements JiangXueJinApplyService {
    @Autowired(required = false)
    private JiangXueJinApplyMapper jiangXueJinApplyMapper;

    @Override
    public boolean insert(JiangXueJinApply jiangXueJinApply) {
        return jiangXueJinApplyMapper.insert(jiangXueJinApply)>0;
    }

    @Override
    public boolean delete(Integer id) {
        return jiangXueJinApplyMapper.delete(id)>0;
    }

    @Override
    public boolean update(JiangXueJinApply jiangXueJinApply) {
        return jiangXueJinApplyMapper.update(jiangXueJinApply)>0;
    }

    @Override
    public boolean updateJiangXueJinApplyForTeacher(JiangXueJinApply jiangXueJinApply) {
        return jiangXueJinApplyMapper.updateJiangXueJinApplyForTeacher(jiangXueJinApply)>0;
    }

    @Override
    public boolean updateJiangXueJinApplyForOffice(JiangXueJinApply jiangXueJinApply) {
        return jiangXueJinApplyMapper.updateJiangXueJinApplyForOffice(jiangXueJinApply)>0;
    }

    @Override
    public List<JiangXueJinApply> selectAllJiangXueJinApply() {
        return jiangXueJinApplyMapper.selectAllJiangXueJinApply();
    }

    @Override
    public List<JiangXueJinApply> selectJiangXueJinApplyByTeacherPass() {
        return jiangXueJinApplyMapper.selectJiangXueJinApplyByTeacherPass();
    }

    @Override
    public JiangXueJinApply selectJiangXueJinApplyByKey(Integer id) {
        return jiangXueJinApplyMapper.selectJiangXueJinApplyByKey(id);
    }

    @Override
    public JiangXueJinApply selectJiangXueJinApplyByNumber(String number) {
        return jiangXueJinApplyMapper.selectJiangXueJinApplyByNumber(number);
    }

    @Override
    public JiangXueJinApply selectJiangXueJinApplyByName(String name) {
        return jiangXueJinApplyMapper.selectJiangXueJinApplyByName(name);
    }
}
