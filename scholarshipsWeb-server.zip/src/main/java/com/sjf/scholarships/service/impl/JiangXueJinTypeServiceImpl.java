package com.sjf.scholarships.service.impl;


import com.sjf.scholarships.dao.JiangXueJinTypeMapper;
import com.sjf.scholarships.dao.OfficeMapper;
import com.sjf.scholarships.domain.JiangXueJinType;
import com.sjf.scholarships.domain.Office;
import com.sjf.scholarships.service.JiangXueJinTypeService;
import com.sjf.scholarships.service.OfficeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class JiangXueJinTypeServiceImpl implements JiangXueJinTypeService {
    @Autowired(required = false)
    private JiangXueJinTypeMapper jiangXueJinTypeMapper;

    @Override
    public boolean insert(JiangXueJinType jiangXueJinType) {
        return jiangXueJinTypeMapper.insert(jiangXueJinType)>0;
    }

    @Override
    public boolean delete(Integer id) {
        return jiangXueJinTypeMapper.delete(id)>0;
    }

    @Override
    public boolean update(JiangXueJinType jiangXueJinType) {
        return jiangXueJinTypeMapper.update(jiangXueJinType)>0;
    }

    @Override
    public List<JiangXueJinType> selectAllJiangXueJinType() {
        return jiangXueJinTypeMapper.selectAllJiangXueJinType();
    }
    @Override
    public JiangXueJinType selectJiangXueJinTypeByKey(Integer id) {
        return jiangXueJinTypeMapper.selectJiangXueJinTypeByKey(id);
    }

    @Override
    public JiangXueJinType selectJiangXueJinTypeByType(String type) {
        return jiangXueJinTypeMapper.selectJiangXueJinTypeByType(type);
    }
}
