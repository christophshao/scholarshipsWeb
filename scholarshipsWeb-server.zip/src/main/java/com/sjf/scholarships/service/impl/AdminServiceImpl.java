package com.sjf.scholarships.service.impl;

import com.sjf.scholarships.dao.AdminMapper;
import com.sjf.scholarships.domain.Admin;
import com.sjf.scholarships.domain.Student;
import com.sjf.scholarships.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/*
* 管理员service实现类
* */
@Service
public class AdminServiceImpl implements AdminService {

    @Autowired
    private AdminMapper adminMapper;
    /*
    *验证密码是否正确
    * */
    @Override
    public boolean verifyPassword(String username, String password,String role) {
        return adminMapper.verifyPassword(username,password,role)>0;
    }

    @Override
    public Admin selectAdminByUsername(String username) {
        return adminMapper.selectAdminByUsername(username);
    }

    @Override
    public List<Admin> selectAllAdmin() {
        return adminMapper.selectAllAdmin();
    }

    @Override
    public boolean update(Admin admin) {
        return adminMapper.update(admin)>0;
    }

}
