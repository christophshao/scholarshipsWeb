package com.sjf.scholarships;

import com.sjf.scholarships.controller.StudentController;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScholarshipsWebServerApplicationTests {

    @Test
    void contextLoads() {

    }

}
