package com.sjf.scholarships.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/*
*定位各种文件，头像，图片的地址
* 会自动加载，然后写的这个支持该路径的Configurer会替换掉默认的，也就是重定向图片地址
* */
@Configuration
public class FilePicConfig implements WebMvcConfigurer {

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
/*   原理：通过addResourceHandler判断前端路径如果是/img/singerPic/ 中的所有的文件
*    都会通过addResourceLocations转换成，这边后端的img文件夹下的singerPic中的文件
* */
        //        管理行业的头像地址
        registry.addResourceHandler("/img/adminPic/**").addResourceLocations(
                "file:" + System.getProperty("user.dir") + System.getProperty("file.separator") + "img"
                        + System.getProperty("file.separator") + "adminPic" + System.getProperty("file.separator")
        );
        //        学生的照片地址
        registry.addResourceHandler("/img/studentPic/**").addResourceLocations(
                "file:" + System.getProperty("user.dir") + System.getProperty("file.separator") + "img"
                + System.getProperty("file.separator") + "studentPic" + System.getProperty("file.separator")
        );

        //        辅导员的照片地址
        registry.addResourceHandler("/img/teacherPic/**").addResourceLocations(
                "file:" + System.getProperty("user.dir") + System.getProperty("file.separator") + "img"
                        + System.getProperty("file.separator") + "teacherPic" + System.getProperty("file.separator")
        );
        //        奖学金的照片地址
        registry.addResourceHandler("/img/jiangxuejinPic/**").addResourceLocations(
                "file:" + System.getProperty("user.dir") + System.getProperty("file.separator") + "img"
                        + System.getProperty("file.separator") + "jiangxuejinPic" + System.getProperty("file.separator")
        );
        //        助学金的照片地址
        registry.addResourceHandler("/img/zhuxuejinPic/**").addResourceLocations(
                "file:" + System.getProperty("user.dir") + System.getProperty("file.separator") + "img"
                        + System.getProperty("file.separator") + "zhuxuejinPic" + System.getProperty("file.separator")
        );


    }
}
