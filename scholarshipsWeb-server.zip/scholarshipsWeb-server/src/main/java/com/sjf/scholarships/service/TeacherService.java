package com.sjf.scholarships.service;

import com.sjf.scholarships.domain.Office;
import com.sjf.scholarships.domain.Teacher;

import java.util.List;

public interface TeacherService {
    //校验登录身份
    public boolean verifyPassword(String username,String password,String role);

    // 添加教师
    public boolean insert(Teacher teacher);

    // 删除教师
    public boolean delete(Integer id);

    // 修改教师信息
    public boolean update(Teacher teacher);

    // 根据id查询教师
    public Teacher selectTeacherByKey(Integer id);

    // 根据教师号查询教师
    public Teacher selectTeacherByNumber(String number);

    // 查询所有教师
    public List<Teacher> selectAllTeacher();

    // 根据学生姓名模糊查询教师
    public Teacher selectTeacherByName(String name);

    //  根据用户名查询用户信息
    public Teacher selectByUsername(String username);
}
