package com.sjf.scholarships.service;

import com.sjf.scholarships.domain.Bulletin;

import java.util.List;

public interface BulletinService {
    // 添加
    public boolean insert(Bulletin bulletin);

    // 删除
    public boolean delete(Integer id);

    // 修改信息
    public boolean update(Bulletin bulletin);

    // 根据id查询
    public Bulletin selectBulletinByKey(Integer id);

    // 查询所有
    public List<Bulletin> selectAllBulletin();

    // 根据title模糊查询
    public Bulletin selectBulletinByTitle(String title);

    // 根据type模糊查询
    public Bulletin selectBulletinForJiang(String type);
}
