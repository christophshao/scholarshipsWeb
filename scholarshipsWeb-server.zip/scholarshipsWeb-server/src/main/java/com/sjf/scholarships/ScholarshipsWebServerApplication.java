package com.sjf.scholarships;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.sjf.scholarships.dao")
public class ScholarshipsWebServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(ScholarshipsWebServerApplication.class, args);
    }

}
