package com.sjf.scholarships.domain;

public class JiangXueJinType {
    private Integer id;
    private String type;
    private String jxjLevel;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getJxjLevel() {
        return jxjLevel;
    }

    public void setJxjLevel(String jxjLevel) {
        this.jxjLevel = jxjLevel;
    }
}
