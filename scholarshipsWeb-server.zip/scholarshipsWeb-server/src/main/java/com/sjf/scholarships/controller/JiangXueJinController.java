package com.sjf.scholarships.controller;

import com.alibaba.fastjson.JSONObject;
import com.sjf.scholarships.domain.JiangXueJin;
import com.sjf.scholarships.domain.Office;
import com.sjf.scholarships.domain.Student;
import com.sjf.scholarships.service.JiangXueJinService;
import com.sjf.scholarships.service.OfficeService;
import com.sjf.scholarships.utils.Consts;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@RestController
@RequestMapping("/jiangxuejin")
public class JiangXueJinController {

    @Autowired
    private JiangXueJinService jiangXueJinService;
    /*
     * 添加
     * */
    @RequestMapping(value = "/add",method = RequestMethod.POST)
    public Object addOffice(HttpServletRequest request) {
        JSONObject jsonObject = new JSONObject();
        String number = request.getParameter("number").trim();
        String typeId = request.getParameter("typeId").trim();
        String startTime = request.getParameter("startTime").trim();
        String deadline = request.getParameter("deadline").trim();  //
        String photo = request.getParameter("photo").trim();
        String introduce = request.getParameter("introduce").trim();

        if(number == null || "".equals(number)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"奖学金编号不能为空！");
            return jsonObject;
        }
        if(typeId == null || "".equals(typeId)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"奖学金等级不能为空！");
            return jsonObject;
        }
        //       把申请时间转换成Date格式
        DateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd");
        Date startTiemDate = new Date();
        try {
            startTiemDate = dateFormat1.parse(startTime);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        //       把截至时间转换成Date格式
        DateFormat dateFormat2 = new SimpleDateFormat("yyyy-MM-dd");
        Date deadlineDate = new Date();
        try {
            deadlineDate = dateFormat2.parse(deadline);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        // 保存到对象中
        JiangXueJin jiangXueJin = new JiangXueJin();
        jiangXueJin.setNumber(number);
        jiangXueJin.setTypeId(typeId);
        jiangXueJin.setStartTime(startTiemDate);
        jiangXueJin.setDeadline(deadlineDate);
        jiangXueJin.setPhoto(photo);
        jiangXueJin.setIntroduce(introduce);

        boolean flag = jiangXueJinService.insert(jiangXueJin);
        if(flag){
            jsonObject.put(Consts.CODE,1);
            jsonObject.put(Consts.MSG,"添加成功！");
            return jsonObject;
        }
        jsonObject.put(Consts.CODE,0);
        jsonObject.put(Consts.MSG,"添加失败！");
        return jsonObject;

    }

    /*
     * 删除
     * */
    @RequestMapping(value = "/delete",method = RequestMethod.GET)
    public Object deleteJiangXueJin(HttpServletRequest request){
        String id = request.getParameter("id").trim();
        boolean flag = jiangXueJinService.delete(Integer.parseInt(id));
        return flag;
    }

    /*
     * 修改
     * */
    @RequestMapping(value = "/update",method = RequestMethod.POST)
    public Object updateJiangXueJin(HttpServletRequest request){
        JSONObject jsonObject = new JSONObject();
        String id = request.getParameter("id").trim();
        String number = request.getParameter("number").trim();
        String typeId = request.getParameter("typeId").trim();
        String startTime = request.getParameter("startTime").trim();
        String deadline = request.getParameter("deadline").trim();  //本人电话号
        String introduce = request.getParameter("introduce").trim();

        if(number == null || "".equals(number)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"奖学金编号不能为空！");
            return jsonObject;
        }
        if(typeId == null || "".equals(typeId)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"奖学金名称不能为空！");
            return jsonObject;
        }
        //       把申请时间转换成Date格式
        DateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd");
        Date startTiemDate = new Date();
        try {
            startTiemDate = dateFormat1.parse(startTime);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        //       把截至时间转换成Date格式
        DateFormat dateFormat2 = new SimpleDateFormat("yyyy-MM-dd");
        Date deadlineDate = new Date();
        try {
            deadlineDate = dateFormat2.parse(deadline);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        // 保存到对象中
        JiangXueJin jiangXueJin = new JiangXueJin();
        jiangXueJin.setId(Integer.parseInt(id));
        jiangXueJin.setNumber(number);
        jiangXueJin.setTypeId(typeId);
        jiangXueJin.setStartTime(startTiemDate);
        jiangXueJin.setDeadline(deadlineDate);
        jiangXueJin.setIntroduce(introduce);
        boolean flag = jiangXueJinService.update(jiangXueJin);

        if(flag){
            jsonObject.put(Consts.CODE,1);
            jsonObject.put(Consts.MSG,"修改成功！");
            return jsonObject;
        }
        jsonObject.put(Consts.CODE,0);
        jsonObject.put(Consts.MSG,"修改失败！");
        return jsonObject;

    }

    /*
     * 查询所有
     * */
    @RequestMapping(value = "/selectAllJiangXueJin",method = RequestMethod.GET)
    public Object selectAllJiangXueJin(HttpServletRequest request){
        return jiangXueJinService.selectAllJiangXueJin();
    }

    /*
     * 根据id(主键)查询整个对象
     * */
    @RequestMapping(value = "/selectJiangXueJinByKey",method = RequestMethod.GET)
    public Object selectJiangXueJinByKey(HttpServletRequest request){
        String id = request.getParameter("id").trim();
        return jiangXueJinService.selectJiangXueJinByKey(Integer.parseInt(id));
    }

    //根据工号精确查询
    @RequestMapping(value = "/selectJiangXueJinByNumber",method = RequestMethod.GET)
    public Object selectJiangXueJinByNumber(HttpServletRequest request){
        String number = request.getParameter("number").trim();
        return jiangXueJinService.selectJiangXueJinByNumber(number);
    }

    //根据名字模糊查询
    @RequestMapping(value = "/selectJiangXueJinByName",method = RequestMethod.GET)
    public Object selectJiangXueJinByName(HttpServletRequest request){
        String name = request.getParameter("name").trim();
        return jiangXueJinService.selectJiangXueJinByName("%"+name+"%");
    }

    /*
     * 更新照片
     * */
    @RequestMapping(value = "/updateJiangXueJinPic",method = RequestMethod.POST)
    public Object updateStudentPic(@RequestParam("file") MultipartFile avatorFile, @RequestParam("id")int id){
        JSONObject jsonObject = new JSONObject();

        if (avatorFile.isEmpty()){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"文件上传失败！");
            return jsonObject;
        }
//       文件名 = 当前时间到毫秒 + 原来的文件名
        String fileName = System.currentTimeMillis() + avatorFile.getOriginalFilename();
//        文件路径
        String filePath = System.getProperty("user.dir") + System.getProperty("file.separator") + "img"
                + System.getProperty("file.separator") + "jiangxuejinPic";
//        如果文件路径不存在，新增路径
        File file1 = new File(filePath);
        if(!file1.exists()){
            file1.mkdir();
        }
//      实际的文件地址
        File dest = new File(filePath + System.getProperty("file.separator") + fileName);
//       存储到数据库里的相对文件地址
        String storeAvatorPath = "img/jiangxuejinPic/" + fileName;
        try {
            avatorFile.transferTo(dest);
            JiangXueJin jiangXueJin = new JiangXueJin();
            jiangXueJin.setId(id);
            jiangXueJin.setPhoto(storeAvatorPath);
            boolean flag = jiangXueJinService.update(jiangXueJin);

            if(flag){
                jsonObject.put(Consts.CODE,1);
                jsonObject.put(Consts.MSG,"上传成功!");
                jsonObject.put("pic",storeAvatorPath);
                return jsonObject;
            }
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"上传失败!");
            return jsonObject;
        } catch (IOException e) {
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"上传失败!"+e.getMessage());
        }finally {
            return jsonObject;
        }

    }


}
