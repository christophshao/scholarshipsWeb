package com.sjf.scholarships.dao;

import com.sjf.scholarships.domain.JiangXueJinApply;
import com.sjf.scholarships.domain.PoorStudent;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PoorStudentMapper {
    //添加
    public int insert(PoorStudent poorStudent);

    // 删除
    public int delete(Integer id);

    // 修改信息
    public int update(PoorStudent poorStudent);

    // 辅导员贫困生审批
    public int updatePoorStudentForTeacher(PoorStudent poorStudent);
    // 教务处贫困生审批
    public int updatePoorStudentForOffice(PoorStudent poorStudent);

    // 查询所有信息
    public List<PoorStudent> selectAllPoorStudent();

    // 查询所有信息
    public List<PoorStudent> getPoorStudentByUsername(String username);

    // 查询辅导员审批同意的贫困生申请学生信息
    public List<PoorStudent> selectAllPoorStudentByTeacherPass();

    // 根据姓名模糊查询
    public PoorStudent selectPoorStudentByName(String name);

    // 根据主键查询
    public PoorStudent selectPoorStudentByKey(Integer id);

    // 根据学号精确查询
    public PoorStudent selectPoorStudentByNumber(String number);
}
