package com.sjf.scholarships.dao;

import com.sjf.scholarships.domain.ListJiangXueJin;
import com.sjf.scholarships.domain.ListPoorStudent;
import com.sjf.scholarships.domain.ListZhuXueJin;
import org.springframework.stereotype.Repository;
import java.util.List;
@Repository
public interface ListAdminMapper {
    // 添加贫困生学生到名单
    public int addListPoorStudent(ListPoorStudent listPoorStudent);

    // 添加助学金申请学生到名单
    public int addListZhuXueJinApply(ListZhuXueJin listZhuXueJin);

    // 添加助学金申请学生到名单
    public int addListJiangXueJinApply(ListJiangXueJin listJiangXueJin);

    // 根据选项查询数据表
    public List<ListZhuXueJin> getAllListForPoorStudent(String option);

    //
    public List<ListZhuXueJin> getAllListForZhuXuejin(String option);

    //
    public List<ListZhuXueJin> getAllListForJiangXuejin(String option);
}
