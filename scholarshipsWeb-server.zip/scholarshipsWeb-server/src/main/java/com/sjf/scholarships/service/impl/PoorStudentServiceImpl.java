package com.sjf.scholarships.service.impl;

import com.sjf.scholarships.dao.PoorStudentMapper;
import com.sjf.scholarships.domain.PoorStudent;
import com.sjf.scholarships.service.PoorStudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PoorStudentServiceImpl implements PoorStudentService {

    @Autowired
    private PoorStudentMapper poorStudentMapper;

    @Override
    public boolean insert(PoorStudent poorStudent) {
        return poorStudentMapper.insert(poorStudent)>0;
    }

    @Override
    public boolean delete(Integer id) {
        return poorStudentMapper.delete(id)>0;
    }

    @Override
    public boolean update(PoorStudent poorStudent) {
        return poorStudentMapper.update(poorStudent)>0;
    }

    @Override
    public boolean updatePoorStudentForTeacher(PoorStudent poorStudent) {
        return poorStudentMapper.updatePoorStudentForTeacher(poorStudent)>0;
    }

    @Override
    public boolean updatePoorStudentForOffice(PoorStudent poorStudent) {
        return poorStudentMapper.updatePoorStudentForOffice(poorStudent)>0;
    }

    @Override
    public List<PoorStudent> selectAllPoorStudent() {
        return poorStudentMapper.selectAllPoorStudent();
    }

    @Override
    public List<PoorStudent> getPoorStudentByUsername(String username) {
        return poorStudentMapper.getPoorStudentByUsername(username);
    }

    @Override
    public List<PoorStudent> selectAllPoorStudentByTeacherPass() {
        return poorStudentMapper.selectAllPoorStudentByTeacherPass();
    }

    @Override
    public PoorStudent selectPoorStudentByKey(Integer id) {
        return poorStudentMapper.selectPoorStudentByKey(id);
    }

    @Override
    public PoorStudent selectPoorStudentByNumber(String number) {
        return poorStudentMapper.selectPoorStudentByNumber(number);
    }

    @Override
    public PoorStudent selectPoorStudentByName(String name) {
        return poorStudentMapper.selectPoorStudentByName(name);
    }
}
