package com.sjf.scholarships.service.impl;

import com.sjf.scholarships.dao.ListAdminMapper;
import com.sjf.scholarships.domain.ListJiangXueJin;
import com.sjf.scholarships.domain.ListPoorStudent;
import com.sjf.scholarships.domain.ListZhuXueJin;
import com.sjf.scholarships.service.ListAdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ListAdminServiceImpl implements ListAdminService {

    @Autowired
    private ListAdminMapper listAdminMapper;


    @Override
    public boolean addListPoorStudent(ListPoorStudent listPoorStudent) {
        return listAdminMapper.addListPoorStudent(listPoorStudent)>0;
    }

    @Override
    public boolean addListZhuXueJinApply(ListZhuXueJin listZhuXueJin) {
        return listAdminMapper.addListZhuXueJinApply(listZhuXueJin)>0;
    }

    @Override
    public boolean addListJiangXueJinApply(ListJiangXueJin listJiangXueJin) {
        return listAdminMapper.addListJiangXueJinApply(listJiangXueJin)>0;
    }

    @Override
    public List<ListZhuXueJin> getAllListForPoorStudent(String option) {
        return listAdminMapper.getAllListForPoorStudent(option);
    }

    @Override
    public List<ListZhuXueJin> getAllListForZhuXuejin(String option) {
        return listAdminMapper.getAllListForZhuXuejin(option);
    }

    @Override
    public List<ListZhuXueJin> getAllListForJiangXuejin(String option) {
        return listAdminMapper.getAllListForJiangXuejin(option);
    }
}
