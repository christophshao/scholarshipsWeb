package com.sjf.scholarships.service;

import com.sjf.scholarships.domain.ListJiangXueJin;
import com.sjf.scholarships.domain.ListPoorStudent;
import com.sjf.scholarships.domain.ListZhuXueJin;

import java.util.List;

public interface ListAdminService {
    //添加贫困生学生到名单
    public boolean addListPoorStudent(ListPoorStudent listPoorStudent);

    //添加助学金申请学生到名单
    public boolean addListZhuXueJinApply(ListZhuXueJin listZhuXueJin);

    //添加奖学金申请学生到名单
    public boolean addListJiangXueJinApply(ListJiangXueJin listJiangXueJin);

    // 根据选项查询数据表
    public List<ListZhuXueJin> getAllListForPoorStudent(String option);

    //
    public List<ListZhuXueJin> getAllListForZhuXuejin(String option);

    //
    public List<ListZhuXueJin> getAllListForJiangXuejin(String option);
}
