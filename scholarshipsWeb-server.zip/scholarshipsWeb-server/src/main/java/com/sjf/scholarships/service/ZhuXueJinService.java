package com.sjf.scholarships.service;

import com.sjf.scholarships.domain.ZhuXueJin;

import java.util.List;

public interface ZhuXueJinService {
    // 添加
    public boolean insert(ZhuXueJin zhuXueJin);

    // 删除
    public boolean delete(Integer id);

    // 修改信息
    public boolean update(ZhuXueJin zhuXueJin);

    // 根据id查询
    public ZhuXueJin selectZhuXueJinByKey(Integer id);

    // 根据工号查询
    public ZhuXueJin selectZhuXueJinByNumber(String number);

    // 查询所有
    public List<ZhuXueJin> selectAllZhuXueJin();

    // 根据姓名模糊查询
    public ZhuXueJin selectZhuXueJinByName(String name);
}
