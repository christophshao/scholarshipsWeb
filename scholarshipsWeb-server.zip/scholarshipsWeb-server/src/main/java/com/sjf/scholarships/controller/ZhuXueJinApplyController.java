package com.sjf.scholarships.controller;

import com.alibaba.fastjson.JSONObject;
import com.sjf.scholarships.domain.PoorStudent;
import com.sjf.scholarships.domain.ZhuXueJinApply;
import com.sjf.scholarships.service.ZhuXueJinApplyService;
import com.sjf.scholarships.utils.Consts;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@RestController
@RequestMapping("/zhuxuejinapply")
public class ZhuXueJinApplyController {

    @Autowired
    private ZhuXueJinApplyService zhuXueJinApplyService;
    /*
     * 添加
     * */
    @RequestMapping(value = "/add",method = RequestMethod.POST)
    public Object addZhuXueJinApply(HttpServletRequest request) {
        JSONObject jsonObject = new JSONObject();
        String username = request.getParameter("username").trim();
        String number = request.getParameter("number").trim();
        String name = request.getParameter("name").trim();
        String zxj_level = request.getParameter("zxjLevel").trim(); //助学金类型
        String address = request.getParameter("address").trim();//
        String className = request.getParameter("className").trim();
        String applyTime = request.getParameter("applyTime").trim();  //
        if(username == null || "".equals(username)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"用户名不能为空！");
            return jsonObject;
        }
        if(number == null || "".equals(number)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"助学金编号不能为空！");
            return jsonObject;
        }
        if(name == null || "".equals(name)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"助学金名称不能为空！");
            return jsonObject;
        }
        //       把申请时间转换成Date格式
        DateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd");
        Date applyTimeDate = new Date();
        try {
            applyTimeDate = dateFormat1.parse(applyTime);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        // 保存到对象中
        ZhuXueJinApply zhuXueJinApply = new ZhuXueJinApply();
        zhuXueJinApply.setUsername(username);
        zhuXueJinApply.setNumber(number);
        zhuXueJinApply.setName(name);
        zhuXueJinApply.setZxjLevel(zxj_level);
        zhuXueJinApply.setAddress(address);
        zhuXueJinApply.setClassName(className);
        zhuXueJinApply.setApplyTime(applyTimeDate);

        boolean flag = zhuXueJinApplyService.insert(zhuXueJinApply);
        if(flag){
            jsonObject.put(Consts.CODE,1);
            jsonObject.put(Consts.MSG,"添加成功！");
            return jsonObject;
        }
        jsonObject.put(Consts.CODE,0);
        jsonObject.put(Consts.MSG,"添加失败！");
        return jsonObject;

    }

    /*
     * 删除
     * */
    @RequestMapping(value = "/delete",method = RequestMethod.GET)
    public Object deleteZhuXueJinApply(HttpServletRequest request){
        String id = request.getParameter("id").trim();
        boolean flag = zhuXueJinApplyService.delete(Integer.parseInt(id));
        return flag;
    }

    /*
     * 修改
     * */
    @RequestMapping(value = "/update",method = RequestMethod.POST)
    public Object updateZhuXueJinApply(HttpServletRequest request){
        JSONObject jsonObject = new JSONObject();
        String id = request.getParameter("id").trim();
        String number = request.getParameter("number").trim();
        String name = request.getParameter("name").trim();
        String zxj_level = request.getParameter("zxjLevel").trim(); //助学金类型
        String address = request.getParameter("address").trim();//
        String className = request.getParameter("className").trim();
        String applyTime = request.getParameter("applyTime").trim();  //

        if(number == null || "".equals(number)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"助学金编号不能为空！");
            return jsonObject;
        }
        if(name == null || "".equals(name)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"助学金名称不能为空！");
            return jsonObject;
        }
        //       把申请时间转换成Date格式
        DateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd");
        Date applyTiemDate = new Date();
        try {
            applyTiemDate = dateFormat1.parse(applyTime);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        // 保存到对象中
        ZhuXueJinApply zhuXueJinApply = new ZhuXueJinApply();
        zhuXueJinApply.setId(Integer.parseInt(id));
        zhuXueJinApply.setNumber(number);
        zhuXueJinApply.setName(name);
        zhuXueJinApply.setZxjLevel(zxj_level);
        zhuXueJinApply.setAddress(address);
        zhuXueJinApply.setClassName(className);
        zhuXueJinApply.setApplyTime(applyTiemDate);

        boolean flag = zhuXueJinApplyService.update(zhuXueJinApply);
        if(flag){
            jsonObject.put(Consts.CODE,1);
            jsonObject.put(Consts.MSG,"添加成功！");
            return jsonObject;
        }
        jsonObject.put(Consts.CODE,0);
        jsonObject.put(Consts.MSG,"添加失败！");
        return jsonObject;

    }

    /*
     * 辅导员审批助学金
     * */
    @RequestMapping(value = "/updateZhuXueJinApplyForTeacher",method = RequestMethod.POST)
    public Object updateZhuXueJinApplyForTeacher(HttpServletRequest request){
        JSONObject jsonObject = new JSONObject();
        String id = request.getParameter("id").trim();
        String teacherCheck = request.getParameter("teacherCheck").trim(); //
        String teacherOpinion = request.getParameter("teacherOpinion").trim(); //

        if(teacherCheck == null || "".equals(teacherCheck)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"是否同意不能为空！");
            return jsonObject;
        }

//       保存到用户的对象中
        ZhuXueJinApply zhuXueJinApply = new ZhuXueJinApply();
        zhuXueJinApply.setId(Integer.parseInt(id));
        zhuXueJinApply.setTeacherCheck(teacherCheck);
        zhuXueJinApply.setTeacherOpinion(teacherOpinion);
        boolean flag = zhuXueJinApplyService.updateZhuXueJinApplyForTeacher(zhuXueJinApply);

        if(flag){
            jsonObject.put(Consts.CODE,1);
            jsonObject.put(Consts.MSG,"提交成功！");
            return jsonObject;
        }
        jsonObject.put(Consts.CODE,0);
        jsonObject.put(Consts.MSG,"提交失败！");
        return jsonObject;

    }
    /*
     * 教务处审批助学金
     * */
    @RequestMapping(value = "/updateZhuXueJinApplyForOffice",method = RequestMethod.POST)
    public Object updateZhuXueJinApplyForOffice(HttpServletRequest request){
        JSONObject jsonObject = new JSONObject();
        String id = request.getParameter("id").trim();
        String officeCheck = request.getParameter("officeCheck").trim(); //
        String officeOpinion = request.getParameter("officeOpinion").trim(); //

        if(officeCheck == null || "".equals(officeCheck)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"是否同意不能为空！");
            return jsonObject;
        }

//       保存到用户的对象中
        ZhuXueJinApply zhuXueJinApply = new ZhuXueJinApply();
        zhuXueJinApply.setId(Integer.parseInt(id));
        zhuXueJinApply.setOfficeCheck(officeCheck);
        zhuXueJinApply.setOfficeOpinion(officeOpinion);
        boolean flag = zhuXueJinApplyService.updateZhuXueJinApplyForOffice(zhuXueJinApply);

        if(flag){
            jsonObject.put(Consts.CODE,1);
            jsonObject.put(Consts.MSG,"提交成功！");
            return jsonObject;
        }
        jsonObject.put(Consts.CODE,0);
        jsonObject.put(Consts.MSG,"提交失败！");
        return jsonObject;

    }



    /*
     * 查询所有
     * */
    @RequestMapping(value = "/selectAllZhuXueJinApply",method = RequestMethod.GET)
    public Object selectAllZhuXueJinApply(HttpServletRequest request){
        return zhuXueJinApplyService.selectAllZhuXueJinApply();
    }

    /*
     * By username
     * */
    @RequestMapping(value = "/getZhuXueJinApplyByUsername",method = RequestMethod.POST)
    public Object getZhuXueJinApplyByUsername(HttpServletRequest request){
        String username = request.getParameter("username").trim();
        return zhuXueJinApplyService.getZhuXueJinApplyByUsername(username);
    }

    //查询辅导员审批同意的助助学金申请学生信息
    @RequestMapping(value = "/selectZhuXueJinApplyByTeacherPass",method = RequestMethod.GET)
    public Object selectZhuXueJinApplyByTeacherPass(HttpServletRequest request){
        return zhuXueJinApplyService.selectZhuXueJinApplyByTeacherPass();
    }

    /*
     * 根据id(主键)查询整个对象
     * */
    @RequestMapping(value = "/selectZhuXueJinApplyByKey",method = RequestMethod.GET)
    public Object selectZhuXueJinApplyByKey(HttpServletRequest request){
        String id = request.getParameter("id").trim();
        return zhuXueJinApplyService.selectZhuXueJinApplyByKey(Integer.parseInt(id));
    }

    //根据工号精确查询
    @RequestMapping(value = "/selectZhuXueJinApplyByNumber",method = RequestMethod.GET)
    public Object selectZhuXueJinApplyByNumber(HttpServletRequest request){
        String number = request.getParameter("number").trim();
        return zhuXueJinApplyService.selectZhuXueJinApplyByNumber(number);
    }

    //根据名字模糊查询
    @RequestMapping(value = "/selectZhuXueJinApplyByName",method = RequestMethod.GET)
    public Object selectZhuXueJinApplyByName(HttpServletRequest request){
        String name = request.getParameter("name").trim();
        return zhuXueJinApplyService.selectZhuXueJinApplyByName("%"+name+"%");
    }

}
