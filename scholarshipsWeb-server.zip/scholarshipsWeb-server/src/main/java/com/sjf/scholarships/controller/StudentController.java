package com.sjf.scholarships.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.sjf.scholarships.domain.Student;
import com.sjf.scholarships.service.StudentService;
import com.sjf.scholarships.utils.Consts;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/student")
public class StudentController {
    @Autowired
    private StudentService studentService;

    /*
     * 判断学生是否登录成功(status 状态)
     * */
    @RequestMapping(value = "/login/status",method = RequestMethod.POST)
    //需要从前端获取数据（一些get或post方法传来的请求，所以需要HttpServletRequest），
    public Object StudentLoginStatus(HttpServletRequest request, HttpSession session){
        JSONObject jsonObject = new JSONObject();
        //getParameter就是获取前端表单中对应的值
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String role = request.getParameter("role");
        boolean flag = studentService.verifyPassword(username,password,role);
        if(flag){
            //用json传递数据到前端
            jsonObject.put(Consts.CODE,1);
            jsonObject.put(Consts.MSG,"学生，登录成功！");
            // 将前端表单拿到的值 存入session
            session.setAttribute(Consts.USERNAME,username);
            return jsonObject;
        }
        jsonObject.put(Consts.CODE,0);
        jsonObject.put(Consts.MSG,"用户名或密码错误！");
        return jsonObject;
    }

    /*
     * 添加学生
     * */
    @RequestMapping(value = "/add",method = RequestMethod.POST)
    public Object addStudent(HttpServletRequest request) {
        JSONObject jsonObject = new JSONObject();
        String username = request.getParameter("username").trim();
        String password = request.getParameter("password").trim();
        String number = request.getParameter("number").trim();//学号
        String name = request.getParameter("name").trim();
        String gpa = request.getParameter("gpa").trim();//绩点
        String sex = request.getParameter("sex").trim();
        String photo = request.getParameter("photo").trim(); //学生照片
        String className = request.getParameter("className").trim();//所属班级
        String birth = request.getParameter("birth").trim();
        String nationality = request.getParameter("nationality").trim();//民族
        String politicalStatus = request.getParameter("politicalStatus").trim(); //政治面貌
        String nativePlace = request.getParameter("nativePlace").trim();  //籍贯
        String address = request.getParameter("address").trim();  //家庭住址
        String postcard = request.getParameter("postcard").trim();  //邮编
        String familyPhone = request.getParameter("familyPhone").trim();  //家庭电话
        String mobilePhone = request.getParameter("mobilePhone").trim();  //本人电话号

        if(username == null || "".equals(username)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"用户名不能为空！");
            return jsonObject;
        }
        if(password == null || "".equals(password)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"密码不能为空！");
            return jsonObject;
        }

        //  把生日转换成Date格式
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date birthDate = new Date();
        try {
            birthDate = dateFormat.parse(birth);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        // 保存到学生的对象中
        Student student = new Student();
        student.setUsername(username);
        student.setPassword(password);
        student.setNumber(number);
        student.setName(name);
        student.setGpa(gpa);
        student.setSex(sex);
        student.setPhoto(photo);
        student.setClassName(className);
        student.setBirth(birthDate);
        student.setNationality(nationality);
        student.setPoliticalStatus(politicalStatus);
        student.setNativePlace(nativePlace);
        student.setAddress(address);
        student.setPostcard(postcard);
        student.setFamilyPhone(familyPhone);
        student.setMobilePhone(mobilePhone);

        boolean flag = studentService.insert(student);
        if(flag){
            jsonObject.put(Consts.CODE,1);
            jsonObject.put(Consts.MSG,"添加成功！");
            return jsonObject;
        }
        jsonObject.put(Consts.CODE,0);
        jsonObject.put(Consts.MSG,"添加失败！");
        return jsonObject;

    }

    /*
    *  批量导入
    * */
    @RequestMapping(value = "/excel/upload", method = RequestMethod.POST)
    public JSONObject handleExcelUpload(HttpServletRequest request) {
        // 解析上传的 Excel 文件，转换为 Student 对象的列表
        List<Student> students = null;
        try {
            String newData = request.getParameter("newData");
            students = JSON.parseArray(newData, Student.class);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        // 处理学院名称
        for (Student student : students) {
            String className = student.getClassName();
            switch (className) {
                case "人文学院":
                    student.setClassName("2");
                    break;
                case "数工学院":
                    student.setClassName("1");
                    break;
                case "计算机学院":
                    student.setClassName("3");
                    break;
                case "经贸学院":
                    student.setClassName("4");
                    break;
                case "艺术学院":
                    student.setClassName("5");
                    break;
                default:
                    break;
            }
        }
        // 处理学生性别
        for (Student student : students) {
            String sex = student.getSex();
            switch (sex) {
                case "男":
                    student.setSex("1");
                    break;
                case "女":
                    student.setSex("2");
                    break;
                default:
                    break;
            }
        }

        // 调用 StudentService 的批量插入方法
        int flag = studentService.batchInsert(students);
        // 返回响应结果
        JSONObject jsonObject = new JSONObject();
        if (flag > 0) {
            jsonObject.put(Consts.CODE,1);
            jsonObject.put(Consts.MSG,"批量添加成功！");
            return jsonObject;
        }
        jsonObject.put(Consts.CODE,0);
        jsonObject.put(Consts.MSG,"添加失败！");
        return jsonObject;
    }

    /*
    * 删除学生
    * */
    @RequestMapping(value = "/delete",method = RequestMethod.GET)
    public Object deleteStudent(HttpServletRequest request){
        String id = request.getParameter("id").trim();
        boolean flag = studentService.delete(Integer.parseInt(id));
        return flag;
    }

    /*
    * 修改学生
    * */
    @RequestMapping(value = "/update",method = RequestMethod.POST)
    public Object updateStudent(HttpServletRequest request){
        JSONObject jsonObject = new JSONObject();
        String id = request.getParameter("id").trim();
        String username = request.getParameter("username").trim();
        String password = request.getParameter("password").trim();
        String number = request.getParameter("number").trim();//学号
        String name = request.getParameter("name").trim();
        String gpa = request.getParameter("gpa").trim();
        String sex = request.getParameter("sex").trim();
        String className = request.getParameter("className").trim();//所属班级
        String birth = request.getParameter("birth").trim();
        String nationality = request.getParameter("nationality").trim();//民族
        String politicalStatus = request.getParameter("politicalStatus").trim(); //政治面貌
        String nativePlace = request.getParameter("nativePlace").trim();  //籍贯
        String address = request.getParameter("address").trim();  //家庭住址
        String postcard = request.getParameter("postcard").trim();  //邮编
        String familyPhone = request.getParameter("familyPhone").trim();  //家庭电话
        String mobilePhone = request.getParameter("mobilePhone").trim();  //本人电话号

        if(username == null || "".equals(username)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"用户名不能为空！");
            return jsonObject;
        }
        if(password == null || "".equals(password)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"密码不能为空！");
            return jsonObject;
        }

//       把生日转换成Date格式
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date birthDate = new Date();
        try {
            birthDate = dateFormat.parse(birth);
        } catch (ParseException e) {
            e.printStackTrace();
        }

//       保存到用户的对象中
        Student student = new Student();
        student.setId(Integer.parseInt(id));
        student.setUsername(username);
        student.setPassword(password);
        student.setNumber(number);
        student.setName(name);
        student.setGpa(gpa);
        student.setSex(sex);
        student.setClassName(className);
        student.setBirth(birthDate);
        student.setNationality(nationality);
        student.setPoliticalStatus(politicalStatus);
        student.setNativePlace(nativePlace);
        student.setAddress(address);
        student.setPostcard(postcard);
        student.setFamilyPhone(familyPhone);
        student.setMobilePhone(mobilePhone);
        boolean flag = studentService.update(student);

        if(flag){
            jsonObject.put(Consts.CODE,1);
            jsonObject.put(Consts.MSG,"修改成功！");
            return jsonObject;
        }
        jsonObject.put(Consts.CODE,0);
        jsonObject.put(Consts.MSG,"修改失败！");
        return jsonObject;

    }

    /*
     * 修改密码
     * */
    @RequestMapping(value = "/updateStudentPassword",method = RequestMethod.POST)
    public Object updateMine(HttpServletRequest request){
        JSONObject jsonObject = new JSONObject();
        String id = request.getParameter("id").trim();
        String passwordAgain = request.getParameter("passwordAgain").trim();
        String password = request.getParameter("password").trim();

        if(password == null || "".equals(password)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"用户名不能为空！");
            return jsonObject;
        }
        if(passwordAgain == null || "".equals(passwordAgain)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"密码不能为空！");
            return jsonObject;
        }
        if(!password.equals(passwordAgain)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"两次密码不一致！");
            return jsonObject;
        }


//       保存到用户的对象中
        Student student = new Student();
        student.setId(Integer.parseInt(id));
        student.setPassword(password);
        boolean flag = studentService.update(student);

        if(flag){
            jsonObject.put(Consts.CODE,1);
            jsonObject.put(Consts.MSG,"修改成功！");
            return jsonObject;
        }
        jsonObject.put(Consts.CODE,0);
        jsonObject.put(Consts.MSG,"修改失败！");
        return jsonObject;

    }

    /*
     * 学生修改个人信息
     * */
    @RequestMapping(value = "/updateStudentByMine",method = RequestMethod.POST)
    public Object updateStudentByMine(HttpServletRequest request){
        JSONObject jsonObject = new JSONObject();
        String id = request.getParameter("id").trim();
        String username = request.getParameter("username").trim();
        String number = request.getParameter("number").trim();//学号
        String name = request.getParameter("name").trim();
        String sex = request.getParameter("sex").trim();
        String className = request.getParameter("className").trim();//所属班级
        String birth = request.getParameter("birth").trim();
        String nationality = request.getParameter("nationality").trim();//民族
        String politicalStatus = request.getParameter("politicalStatus").trim(); //政治面貌
        String nativePlace = request.getParameter("nativePlace").trim();  //籍贯
        String address = request.getParameter("address").trim();  //家庭住址
        String postcard = request.getParameter("postcard").trim();  //邮编
        String familyPhone = request.getParameter("familyPhone").trim();  //家庭电话
        String mobilePhone = request.getParameter("mobilePhone").trim();  //本人电话号

        if(username == null || "".equals(username)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"用户名不能为空！");
            return jsonObject;
        }

//       把生日转换成Date格式
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date birthDate = new Date();
        try {
            birthDate = dateFormat.parse(birth);
        } catch (ParseException e) {
            e.printStackTrace();
        }

//       保存到用户的对象中
        Student student = new Student();
        student.setId(Integer.parseInt(id));
        student.setUsername(username);
        student.setNumber(number);
        student.setName(name);
        student.setSex(sex);
        student.setClassName(className);
        student.setBirth(birthDate);
        student.setNationality(nationality);
        student.setPoliticalStatus(politicalStatus);
        student.setNativePlace(nativePlace);
        student.setAddress(address);
        student.setPostcard(postcard);
        student.setFamilyPhone(familyPhone);
        student.setMobilePhone(mobilePhone);
        boolean flag = studentService.updateStudentByMine(student);

        if(flag){
            jsonObject.put(Consts.CODE,1);
            jsonObject.put(Consts.MSG,"修改成功！");
            return jsonObject;
        }
        jsonObject.put(Consts.CODE,0);
        jsonObject.put(Consts.MSG,"修改失败！");
        return jsonObject;

    }

    /*
    * 查询所有学生
    * */
    @RequestMapping(value = "/selectAllStudent",method = RequestMethod.GET)
    public Object selectAllStudent(HttpServletRequest request){
        return studentService.selectAllStudent();
    }

    /*
     *根据登录的用户名查询个人信息
     * */
    @RequestMapping(value = "/selectByUsername", method = RequestMethod.POST)
    public Object selectByUsername(HttpServletRequest request){
        String username = request.getParameter("username").trim();
        return studentService.selectByUsername(username);
    }

    /*
     * 根据id(主键)查询整个对象
     * */
    @RequestMapping(value = "/selectStudentByKey",method = RequestMethod.GET)
    public Object selectStudentByKey(HttpServletRequest request){
        String id = request.getParameter("id").trim();
        return studentService.selectStudentByKey(Integer.parseInt(id));
    }

    //根据学生学号精确查询
    @RequestMapping(value = "/selectStudentByNumber",method = RequestMethod.GET)
    public Object selectStudentByNumber(HttpServletRequest request){
        String number = request.getParameter("number").trim();
        return studentService.selectStudentByNumber(number);
    }

    //根据学生名字模糊查询
    @RequestMapping(value = "/selectStudentByName",method = RequestMethod.GET)
    public Object selectStudentByName(HttpServletRequest request){
        String name = request.getParameter("name").trim();
        return studentService.selectStudentByName("%"+name+"%");
    }


    /*
    * 更新学生照片
    * */
    @RequestMapping(value = "/updateStudentPic",method = RequestMethod.POST)
    public Object updateStudentPic(@RequestParam("file") MultipartFile avatorFile, @RequestParam("id")int id){
        JSONObject jsonObject = new JSONObject();

        if (avatorFile.isEmpty()){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"文件上传失败！");
            return jsonObject;
        }
//       文件名 = 当前时间到毫秒 + 原来的文件名
        String fileName = System.currentTimeMillis() + avatorFile.getOriginalFilename();
//        文件路径
        String filePath = System.getProperty("user.dir") + System.getProperty("file.separator") + "img"
                + System.getProperty("file.separator") + "studentPic";
//        如果文件路径不存在，新增路径
        File file1 = new File(filePath);
        if(!file1.exists()){
            file1.mkdir();
        }
//      实际的文件地址
        File dest = new File(filePath + System.getProperty("file.separator") + fileName);
//       存储到数据库里的相对文件地址
        String storeAvatorPath = "img/studentPic/" + fileName;
        try {
            avatorFile.transferTo(dest);
            Student student = new Student();
            student.setId(id);
            student.setPhoto(storeAvatorPath);
            boolean flag = studentService.update(student);

            if(flag){
                jsonObject.put(Consts.CODE,1);
                jsonObject.put(Consts.MSG,"上传成功!");
                jsonObject.put("pic",storeAvatorPath);
                return jsonObject;
            }
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"上传失败!");
            return jsonObject;
        } catch (IOException e) {
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"上传失败!"+e.getMessage());
        }finally {
            return jsonObject;
        }

    }

}
