package com.sjf.scholarships.service.impl;


import com.sjf.scholarships.dao.OfficeMapper;
import com.sjf.scholarships.dao.TeacherMapper;
import com.sjf.scholarships.domain.Office;
import com.sjf.scholarships.domain.Teacher;
import com.sjf.scholarships.service.OfficeService;
import com.sjf.scholarships.service.TeacherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OfficeServiceImpl implements OfficeService {
    @Autowired(required = false)
    private OfficeMapper officeMapper;

    @Override
    public boolean verifyPassword(String username, String password,String role) {
        return officeMapper.verifyPassword(username,password,role)>0;
    }
    @Override
    public boolean insert(Office office) {
        return officeMapper.insert(office)>0;
    }

    @Override
    public boolean delete(Integer id) {
        return officeMapper.delete(id)>0;
    }

    @Override
    public boolean update(Office office) {
        return officeMapper.update(office)>0;
    }

    @Override
    public List<Office> selectAllOffice() {
        return officeMapper.selectAllOffice();
    }
    @Override
    public Office selectOfficeByKey(Integer id) {
        return officeMapper.selectOfficeByKey(id);
    }

    @Override
    public Office selectOfficeByNumber(String number) {
        return officeMapper.selectOfficeByNumber(number);
    }

    @Override
    public Office selectOfficeByName(String name) {
        return officeMapper.selectOfficeByName(name);
    }

    @Override
    public Office selectByUsername(String username) {
        return officeMapper.selectByUsername(username);
    }

}
