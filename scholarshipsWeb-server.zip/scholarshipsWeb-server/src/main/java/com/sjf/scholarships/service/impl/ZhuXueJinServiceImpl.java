package com.sjf.scholarships.service.impl;


import com.sjf.scholarships.dao.ZhuXueJinMapper;
import com.sjf.scholarships.domain.ZhuXueJin;
import com.sjf.scholarships.service.ZhuXueJinService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ZhuXueJinServiceImpl implements ZhuXueJinService {
    @Autowired(required = false)
    private ZhuXueJinMapper zhuXueJinMapper;

    @Override
    public boolean insert(ZhuXueJin zhuXueJin) {
        return zhuXueJinMapper.insert(zhuXueJin)>0;
    }

    @Override
    public boolean delete(Integer id) {
        return zhuXueJinMapper.delete(id)>0;
    }

    @Override
    public boolean update(ZhuXueJin zhuXueJin) {
        return zhuXueJinMapper.update(zhuXueJin)>0;
    }

    @Override
    public List<ZhuXueJin> selectAllZhuXueJin() {
        return zhuXueJinMapper.selectAllZhuXueJin();
    }
    @Override
    public ZhuXueJin selectZhuXueJinByKey(Integer id) {
        return zhuXueJinMapper.selectZhuXueJinByKey(id);
    }

    @Override
    public ZhuXueJin selectZhuXueJinByNumber(String number) {
        return zhuXueJinMapper.selectZhuXueJinByNumber(number);
    }

    @Override
    public ZhuXueJin selectZhuXueJinByName(String name) {
        return zhuXueJinMapper.selectZhuXueJinByName(name);
    }
}
