package com.sjf.scholarships.domain;

/*联表查询，通过贫困生表中的贫困生姓名 == 学生表中的学生姓名*/
public class Test {
    private Integer id;
    private String username;
    private String password;
    private String number;  //学号
    private String name;
    private String sex;

}
