package com.sjf.scholarships.dao;

import com.sjf.scholarships.domain.JiangXueJinApply;
import com.sjf.scholarships.domain.JiangXueJinApply;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface JiangXueJinApplyMapper {
    //添加
    public int insert(JiangXueJinApply jiangXueJinApply);

    // 删除
    public int delete(Integer id);

    // 修改
    public int update(JiangXueJinApply jiangXueJinApply);
    // 辅导员助学金审批
    public int updateJiangXueJinApplyForTeacher(JiangXueJinApply jiangXueJinApply);

    // 教务处助学金审批
    public int updateJiangXueJinApplyForOffice(JiangXueJinApply jiangXueJinApply);
    // 查询所有
    public List<JiangXueJinApply> selectAllJiangXueJinApply();

    public List<JiangXueJinApply> getJiangXueJinApplyByUsername(String username);
    // 查询辅导员审批同意的奖学金申请学生信息
    public List<JiangXueJinApply> selectJiangXueJinApplyByTeacherPass();

    // 根据姓名模糊查询
    public JiangXueJinApply selectJiangXueJinApplyByName(String name);

    // 根据主键查询
    public JiangXueJinApply selectJiangXueJinApplyByKey(Integer id);

    // 根据学号查询
    public JiangXueJinApply selectJiangXueJinApplyByNumber(String number);
}
