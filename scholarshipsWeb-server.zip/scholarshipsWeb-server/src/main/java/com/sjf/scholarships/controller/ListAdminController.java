package com.sjf.scholarships.controller;

import com.alibaba.fastjson.JSONObject;
import com.sjf.scholarships.domain.ListJiangXueJin;
import com.sjf.scholarships.domain.ListPoorStudent;
import com.sjf.scholarships.domain.ListZhuXueJin;
import com.sjf.scholarships.service.ListAdminService;
import com.sjf.scholarships.utils.Consts;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.text.DecimalFormat;

@RestController
@RequestMapping("/list")
public class ListAdminController {

    @Autowired
    private ListAdminService listAdminService;
    /*
     * 贫困生加入到名单
     * */
    @RequestMapping(value = "/addListPoorStudent",method = RequestMethod.POST)
    public Object addListPoorStudent(HttpServletRequest request) {
        JSONObject jsonObject = new JSONObject();
        String number = request.getParameter("number").trim();
        String gpa = request.getParameter("gpa").trim();
        String teacherOpinion = request.getParameter("teacherOpinion").trim();
        String officeOpinion = request.getParameter("officeOpinion").trim();
        Double gradeDouble = weightedAverage(gpa, teacherOpinion, officeOpinion);

        DecimalFormat df = new DecimalFormat("0.00");
        String grade = df.format(gradeDouble).toString();  //

        // String grade = gradeDouble.toString();


        if(number == null || "".equals(number)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"学号不能为空！");
            return jsonObject;
        }

        // 保存到对象中
        ListPoorStudent listPoorStudent = new ListPoorStudent();
        listPoorStudent.setNumber(number);
        listPoorStudent.setGrade(grade);

        boolean flag = listAdminService.addListPoorStudent(listPoorStudent);
        if(flag){
            jsonObject.put(Consts.CODE,1);
            jsonObject.put(Consts.MSG,"添加成功！");
            return jsonObject;
        }
        jsonObject.put(Consts.CODE,0);
        jsonObject.put(Consts.MSG,"添加失败！");
        return jsonObject;

    }

    /*
     * 申请助学金的学生加入到名单
     * */
    @RequestMapping(value = "/addListZhuXueJinApply",method = RequestMethod.POST)
    public Object addListZhuXueJinApply(HttpServletRequest request) {
        JSONObject jsonObject = new JSONObject();
        String number = request.getParameter("number").trim();
        String gpa = request.getParameter("gpa").trim();
        String teacherOpinion = request.getParameter("teacherOpinion").trim();
        String officeOpinion = request.getParameter("officeOpinion").trim();
        Double gradeDouble = weightedAverage(gpa, teacherOpinion, officeOpinion);
        DecimalFormat df = new DecimalFormat("0.00");

        String grade = df.format(gradeDouble).toString();  //

        if(number == null || "".equals(number)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"学号不能为空！");
            return jsonObject;
        }

        // 保存到对象中
        ListZhuXueJin listZhuXueJin = new ListZhuXueJin();
        listZhuXueJin.setNumber(number);
        listZhuXueJin.setGrade(grade);

        boolean flag = listAdminService.addListZhuXueJinApply(listZhuXueJin);
        if(flag){
            jsonObject.put(Consts.CODE,1);
            jsonObject.put(Consts.MSG,"添加成功！");
            return jsonObject;
        }
        jsonObject.put(Consts.CODE,0);
        jsonObject.put(Consts.MSG,"添加失败！");
        return jsonObject;

    }

    /*
     * 申请助学金的学生加入到名单
     * */
    @RequestMapping(value = "/addListJiangXueJinApply",method = RequestMethod.POST)
    public Object addListJiangXueJinApply(HttpServletRequest request) {
        JSONObject jsonObject = new JSONObject();
        String number = request.getParameter("number").trim();
        String gpa = request.getParameter("gpa").trim();
        String teacherOpinion = request.getParameter("teacherOpinion").trim();
        String officeOpinion = request.getParameter("officeOpinion").trim();
        Double gradeDouble = weightedAverage(gpa, teacherOpinion, officeOpinion);
        DecimalFormat df = new DecimalFormat("0.00");

        String grade = df.format(gradeDouble).toString();  //

        if(number == null || "".equals(number)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"学号不能为空！");
            return jsonObject;
        }

        // 保存到对象中
        ListJiangXueJin listJiangXueJin = new ListJiangXueJin();
        listJiangXueJin.setNumber(number);
        listJiangXueJin.setGrade(grade);

        boolean flag = listAdminService.addListJiangXueJinApply(listJiangXueJin);
        if(flag){
            jsonObject.put(Consts.CODE,1);
            jsonObject.put(Consts.MSG,"添加成功！");
            return jsonObject;
        }
        jsonObject.put(Consts.CODE,0);
        jsonObject.put(Consts.MSG,"添加失败！");
        return jsonObject;

    }

    // 加权平均算法
    public double weightedAverage(String gpa, String teacherOption, String officeOption) {
        // 根据不同因素的重要程度确定权重
        double gpaWeight = 0.5;
        double teacherWeight = 0.2;
        double officeWeight = 0.3;

        // 转为double形
        double gpaDouble = Double.parseDouble(gpa);
        double teacherScoreDouble = Double.parseDouble(teacherOption);
        double officeScoreDouble = Double.parseDouble(officeOption);

        // 将各个分值乘以相应的权重得到加权分值
        double weightedGpa = gpaDouble * gpaWeight;
        double weightedTeacherScore = teacherScoreDouble * teacherWeight;
        double weightedOfficeScore = officeScoreDouble * officeWeight;

        // 将各个加权分值加起来得到总分
        double totalScore = weightedGpa + weightedTeacherScore + weightedOfficeScore;

        // 将总分映射到指定范围内
        double minScore = 0;
        double maxScore = 10;
        double grade = minScore + (totalScore / (gpaWeight + teacherWeight + officeWeight)) * (maxScore - minScore);

        return grade;
    }

    /*
     * 根据选项查询数据
     * */
    @RequestMapping(value = "/getAllListByOption",method = RequestMethod.POST)
    public Object selectBulletinForJiang(HttpServletRequest request){
        String option = request.getParameter("option").trim();
        if ("poor_student".equals(option)) {
            return listAdminService.getAllListForPoorStudent(option);
        } else if ("zhuxuejin_apply".equals(option)) {
            return listAdminService.getAllListForZhuXuejin(option);
        } else {
            return listAdminService.getAllListForJiangXuejin(option);
        }
    }

}
