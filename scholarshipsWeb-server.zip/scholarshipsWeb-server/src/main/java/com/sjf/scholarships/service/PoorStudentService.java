package com.sjf.scholarships.service;

import com.sjf.scholarships.domain.JiangXueJinApply;
import com.sjf.scholarships.domain.PoorStudent;
import java.util.List;

public interface PoorStudentService {
    // 添加贫困学生
    public boolean insert(PoorStudent poorStudent);

    // 删除贫困学生
    public boolean delete(Integer id);

    // 修改贫困学生信息
    public boolean update(PoorStudent poorStudent);

    // 辅导员审批
    public boolean updatePoorStudentForTeacher(PoorStudent poorStudent);

    // 教务处审批
    public boolean updatePoorStudentForOffice(PoorStudent poorStudent);

    // 查询所有贫困学生
    public List<PoorStudent> selectAllPoorStudent();

    //根据username 查询贫困生
    public List<PoorStudent> getPoorStudentByUsername(String username);

    // 查询辅导员审批同意的贫困生申请学生信息
    public List<PoorStudent> selectAllPoorStudentByTeacherPass();

    // 根据id查询贫困学生
    public PoorStudent selectPoorStudentByKey(Integer id);

    // 根据学号查询贫困学生
    public PoorStudent selectPoorStudentByNumber(String number);

    // 根据贫困学生姓名模糊查询贫困学生
    public PoorStudent selectPoorStudentByName(String name);
}
