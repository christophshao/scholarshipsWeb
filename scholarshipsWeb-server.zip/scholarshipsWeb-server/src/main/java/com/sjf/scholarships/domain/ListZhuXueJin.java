package com.sjf.scholarships.domain;


public class ListZhuXueJin {
    private Integer id;
    private String number;
    private String name;
    private String className;
    private String poorType;
    private String grade;
    // private String zxjLevel;

    private String type;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getPoorType() {
        return poorType;
    }

    public void setPoorType(String poorType) {
        this.poorType = poorType;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    // public String getZxjLevel() {
    //     return zxjLevel;
    // }
    //
    // public void setZxjLevel(String zxjLevel) {
    //     this.zxjLevel = zxjLevel;
    // }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
