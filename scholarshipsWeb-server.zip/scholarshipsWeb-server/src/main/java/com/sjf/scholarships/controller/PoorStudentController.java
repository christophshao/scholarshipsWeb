package com.sjf.scholarships.controller;

import com.alibaba.fastjson.JSONObject;
import com.sjf.scholarships.domain.PoorStudent;
import com.sjf.scholarships.service.PoorStudentService;
import com.sjf.scholarships.utils.Consts;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@RestController
@RequestMapping("/poorstudent")
public class PoorStudentController {
    @Autowired
    private PoorStudentService poorStudentService;

    /*
     * 申请贫困生
     * */
    @RequestMapping(value = "/add",method = RequestMethod.POST)
    public Object addPoorStudent(HttpServletRequest request) {
        JSONObject jsonObject = new JSONObject();
        String username = request.getParameter("username").trim();
        String number = request.getParameter("number").trim();
        String name = request.getParameter("name").trim();
        String sex = request.getParameter("sex").trim();//
        String address = request.getParameter("address").trim();
        String familySize = request.getParameter("familySize").trim();
        String familyIncome = request.getParameter("familyIncome").trim(); //
        String annualIncome = request.getParameter("annualIncome").trim();//
        String incomeSource = request.getParameter("incomeSource").trim();
        String poorType = request.getParameter("poorType").trim();//
        String startTime = request.getParameter("startTime").trim(); //
        if(username == null || "".equals(username)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"用户名不能为空！");
            return jsonObject;
        }
        if(number == null || "".equals(number)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"学号不能为空！");
            return jsonObject;
        }
        if(name == null || "".equals(name)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"姓名不能为空！");
            return jsonObject;
        }

        //  把日期转换成Date格式
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date start = new Date();
        try {
            start = dateFormat.parse(startTime);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        // 保存到学生的对象中
        PoorStudent poorStudent = new PoorStudent();
        poorStudent.setUsername(username);
        poorStudent.setNumber(number);
        poorStudent.setName(name);
        poorStudent.setSex(sex);
        poorStudent.setAddress(address);
        poorStudent.setFamilySize(familySize);
        poorStudent.setFamilyIncome(familyIncome);
        poorStudent.setAnnualIncome(annualIncome);
        poorStudent.setIncomeSource(incomeSource);
        poorStudent.setPoorType(poorType);
        poorStudent.setStartTime(start);

        boolean flag = poorStudentService.insert(poorStudent);
        if(flag){
            jsonObject.put(Consts.CODE,1);
            jsonObject.put(Consts.MSG,"添加成功！");
            return jsonObject;
        }
        jsonObject.put(Consts.CODE,0);
        jsonObject.put(Consts.MSG,"添加失败！");
        return jsonObject;

    }

    /*
    * 删除学生
    * */
    @RequestMapping(value = "/delete",method = RequestMethod.GET)
    public Object deletePoorStudent(HttpServletRequest request){
        String id = request.getParameter("id").trim();
        boolean flag = poorStudentService.delete(Integer.parseInt(id));
        return flag;
    }


    /*
     * 修改学生
     * */
    @RequestMapping(value = "/update",method = RequestMethod.POST)
    public Object updatePoorStudent(HttpServletRequest request){
        JSONObject jsonObject = new JSONObject();
        String id = request.getParameter("id").trim();
        String number = request.getParameter("number").trim();
        String name = request.getParameter("name").trim();
        String sex = request.getParameter("sex").trim();//
        String address = request.getParameter("address").trim();
        String familySize = request.getParameter("familySize").trim();
        String familyIncome = request.getParameter("familyIncome").trim(); //
        String annualIncome = request.getParameter("annualIncome").trim();//
        String incomeSource = request.getParameter("incomeSource").trim();
        String poorType = request.getParameter("poorType").trim();//
        String startTime = request.getParameter("startTime").trim(); //

        if(number == null || "".equals(number)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"学号不能为空！");
            return jsonObject;
        }
        if(name == null || "".equals(name)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"姓名不能为空！");
            return jsonObject;
        }

        //  把日期转换成Date格式
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date start = new Date();
        try {
            start = dateFormat.parse(startTime);
        } catch (ParseException e) {
            e.printStackTrace();
        }

//       保存到用户的对象中
        PoorStudent poorStudent = new PoorStudent();
        poorStudent.setId(Integer.parseInt(id));
        poorStudent.setNumber(number);
        poorStudent.setName(name);
        poorStudent.setSex(sex);
        poorStudent.setAddress(address);
        poorStudent.setFamilySize(familySize);
        poorStudent.setFamilyIncome(familyIncome);
        poorStudent.setAnnualIncome(annualIncome);
        poorStudent.setIncomeSource(incomeSource);
        poorStudent.setPoorType(poorType);
        poorStudent.setStartTime(start);
        boolean flag = poorStudentService.update(poorStudent);

        if(flag){
            jsonObject.put(Consts.CODE,1);
            jsonObject.put(Consts.MSG,"修改成功！");
            return jsonObject;
        }
        jsonObject.put(Consts.CODE,0);
        jsonObject.put(Consts.MSG,"修改失败！");
        return jsonObject;

    }

    /*
     * 辅导员审批
     * */
    @RequestMapping(value = "/updatePoorStudentForTeacher",method = RequestMethod.POST)
    public Object updatePoorStudentForTeacher(HttpServletRequest request){
        JSONObject jsonObject = new JSONObject();
        String id = request.getParameter("id").trim();
        String teacherCheck = request.getParameter("teacherCheck").trim(); //
        String teacherOpinion = request.getParameter("teacherOpinion").trim(); //

        if(teacherCheck == null || "".equals(teacherCheck)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"是否同意不能为空！");
            return jsonObject;
        }

//       保存到用户的对象中
        PoorStudent poorStudent = new PoorStudent();
        poorStudent.setId(Integer.parseInt(id));
        poorStudent.setTeacherCheck(teacherCheck);
        poorStudent.setTeacherOpinion(teacherOpinion);
        boolean flag = poorStudentService.updatePoorStudentForTeacher(poorStudent);

        if(flag){
            jsonObject.put(Consts.CODE,1);
            jsonObject.put(Consts.MSG,"提交成功！");
            return jsonObject;
        }
        jsonObject.put(Consts.CODE,0);
        jsonObject.put(Consts.MSG,"提交失败！");
        return jsonObject;

    }
    /*
     * 教务处审批
     * */
    @RequestMapping(value = "/updatePoorStudentForOffice",method = RequestMethod.POST)
    public Object updatePoorStudentForOffice(HttpServletRequest request){
        JSONObject jsonObject = new JSONObject();
        String id = request.getParameter("id").trim();
        String officeCheck = request.getParameter("officeCheck").trim(); //
        String officeOpinion = request.getParameter("officeOpinion").trim(); //

        if(officeCheck == null || "".equals(officeCheck)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"是否同意不能为空！");
            return jsonObject;
        }

//       保存到用户的对象中
        PoorStudent poorStudent = new PoorStudent();
        poorStudent.setId(Integer.parseInt(id));
        poorStudent.setOfficeCheck(officeCheck);
        poorStudent.setOfficeOpinion(officeOpinion);
        boolean flag = poorStudentService.updatePoorStudentForOffice(poorStudent);

        if(flag){
            jsonObject.put(Consts.CODE,1);
            jsonObject.put(Consts.MSG,"提交成功！");
            return jsonObject;
        }
        jsonObject.put(Consts.CODE,0);
        jsonObject.put(Consts.MSG,"提交失败！");
        return jsonObject;

    }


    /*
    * 查询所有学生
    * */
    @RequestMapping(value = "/selectAllPoorStudent",method = RequestMethod.GET)
    public Object selectAllPoorStudent(HttpServletRequest request){
        return poorStudentService.selectAllPoorStudent();
    }

    /*
     * 根据username 查询贫困生
     * */
    @RequestMapping(value = "/getPoorStudentByUsername",method = RequestMethod.POST)
    public Object getPoorStudentByUsername(HttpServletRequest request){
        String username = request.getParameter("username").trim();
        return poorStudentService.getPoorStudentByUsername(username);
    }




    //查询辅导员审批同意的奖学金申请学生信息
    @RequestMapping(value = "/selectAllPoorStudentByTeacherPass",method = RequestMethod.GET)
    public Object selectAllPoorStudentByTeacherPass(HttpServletRequest request){

        return poorStudentService.selectAllPoorStudentByTeacherPass();
    }

    /*
     * 根据id(主键)查询整个对象
     * */
    @RequestMapping(value = "/selectPoorStudentByKey",method = RequestMethod.GET)
    public Object selectPoorStudentByKey(HttpServletRequest request){
        String id = request.getParameter("id").trim();
        return poorStudentService.selectPoorStudentByKey(Integer.parseInt(id));
    }

    //根据学生学号精确查询
    @RequestMapping(value = "/selectPoorStudentByNumber",method = RequestMethod.GET)
    public Object selectPoorStudentByNumber(HttpServletRequest request){
        String number = request.getParameter("number").trim();
        return poorStudentService.selectPoorStudentByNumber(number);
    }

    //根据学生名字模糊查询
    @RequestMapping(value = "/selectPoorStudentByName",method = RequestMethod.GET)
    public Object selectPoorStudentByName(HttpServletRequest request){
        String name = request.getParameter("name").trim();
        return poorStudentService.selectPoorStudentByName("%"+name+"%");
    }
}
