package com.sjf.scholarships.utils;

public class Consts {
    /*登录名*/
    public static final String NAME = "name";
    /*返回码，判断1 or 0是否执行成功*/
    public static final String CODE = "code";
    /*返回信息，*/
    public static final String MSG = "msg";
    /*用户名*/
    public static final String USERNAME = "username";
}
