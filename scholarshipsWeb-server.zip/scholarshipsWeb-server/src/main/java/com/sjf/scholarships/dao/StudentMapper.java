package com.sjf.scholarships.dao;

import com.sjf.scholarships.domain.Student;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StudentMapper {
    //添加学生
    public int insert(Student student);


    // 插入 Student 批量信息
    // public int batchInsert(String studentList);
    public int batchInsert(List<Student> students);

    // 删除学生
    public int delete(Integer id);

    // 修改学生信息
    public int update(Student student);

    // 修改学生信息
    public int updateStudentByMine(Student student);

    // 查询所有学生
    public List<Student> selectAllStudent();

    //  根据用户名查询用户信息
    public Student selectByUsername(String username);

    // 根据学生姓名模糊查询学生
    public Student selectStudentByName(String name);

    public Student selectStudentByKey(Integer id);

    public Student selectStudentByNumber(String number);

    // 校验登录身份
    public int verifyPassword(String username,String password,String role);
}
