package com.sjf.scholarships.domain;

import java.io.Serializable;
import java.util.Date;

public class StudentAndPoorStudent implements Serializable {
    private Integer id;
    private String username;
    private String number; //学号
    private String name; //姓名
    private String sex;
    private String address;
    private String familySize;//家庭人口数
    private String familyIncome;//家庭年收入
    private String annualIncome;//家庭年人均收入
    private String incomeSource;//家庭主要收入来源
    private String poorType;//贫困类型
    private Date startTime;//申请日期
    private String teacherCheck;//辅导员审核
    private String officeCheck;//教务处审核
    private String teacherOpinion;
    private String officeOpinion;
    private String gpa;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getFamilySize() {
        return familySize;
    }

    public void setFamilySize(String familySize) {
        this.familySize = familySize;
    }

    public String getFamilyIncome() {
        return familyIncome;
    }

    public void setFamilyIncome(String familyIncome) {
        this.familyIncome = familyIncome;
    }

    public String getAnnualIncome() {
        return annualIncome;
    }

    public void setAnnualIncome(String annualIncome) {
        this.annualIncome = annualIncome;
    }

    public String getIncomeSource() {
        return incomeSource;
    }

    public void setIncomeSource(String incomeSource) {
        this.incomeSource = incomeSource;
    }

    public String getPoorType() {
        return poorType;
    }

    public void setPoorType(String poorType) {
        this.poorType = poorType;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public String getTeacherCheck() {
        return teacherCheck;
    }

    public void setTeacherCheck(String teacherCheck) {
        this.teacherCheck = teacherCheck;
    }

    public String getOfficeCheck() {
        return officeCheck;
    }

    public void setOfficeCheck(String officeCheck) {
        this.officeCheck = officeCheck;
    }

    public String getTeacherOpinion() {
        return teacherOpinion;
    }

    public void setTeacherOpinion(String teacherOpinion) {
        this.teacherOpinion = teacherOpinion;
    }

    public String getOfficeOpinion() {
        return officeOpinion;
    }

    public void setOfficeOpinion(String officeOpinion) {
        this.officeOpinion = officeOpinion;
    }

    public String getGpa() {
        return gpa;
    }

    public void setGpa(String gpa) {
        this.gpa = gpa;
    }
}
