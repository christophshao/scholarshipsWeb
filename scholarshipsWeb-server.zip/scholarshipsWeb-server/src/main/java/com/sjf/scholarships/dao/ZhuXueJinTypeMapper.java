package com.sjf.scholarships.dao;

import com.sjf.scholarships.domain.ZhuXueJinType;
import org.springframework.stereotype.Repository;

import java.util.List;
/*
* Dao
* */

@Repository
public interface ZhuXueJinTypeMapper {
    /*
    *添加
    * */
    public int insert(ZhuXueJinType zhuXueJinType);

    // 删除
    public int delete(Integer id);

    // 修改信息
    public int update(ZhuXueJinType zhuXueJinType);

    // 查询所有
    public List<ZhuXueJinType> selectAllZhuXueJinType();

    // 根据名称模糊查询
    public ZhuXueJinType selectZhuXueJinTypeByType(String type);

    //
    public ZhuXueJinType selectZhuXueJinTypeByKey(Integer id);
}
