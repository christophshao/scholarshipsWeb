package com.sjf.scholarships.dao;

import com.sjf.scholarships.domain.JiangXueJin;
import com.sjf.scholarships.domain.Office;
import com.sjf.scholarships.domain.ZhuXueJin;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface ZhuXueJinMapper {
    //添加
    public int insert(ZhuXueJin zhuXueJin);

    // 删除
    public int delete(Integer id);

    // 修改
    public int update(ZhuXueJin zhuXueJin);

    // 查询所有
    public List<ZhuXueJin> selectAllZhuXueJin();

    // 根据姓名模糊查询
    public ZhuXueJin selectZhuXueJinByName(String name);

    // 根据主键查询
    public ZhuXueJin selectZhuXueJinByKey(Integer id);

    // 根据工号查询
    public ZhuXueJin selectZhuXueJinByNumber(String number);
}
