package com.sjf.scholarships.controller;

import com.alibaba.fastjson.JSONObject;
import com.sjf.scholarships.domain.JiangXueJinApply;
import com.sjf.scholarships.domain.PoorStudent;
import com.sjf.scholarships.service.JiangXueJinApplyService;
import com.sjf.scholarships.utils.Consts;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@RestController
@RequestMapping("/jiangxuejinapply")
public class JiangXueJinApplyController {

    @Autowired
    private JiangXueJinApplyService jiangXueJinApplyService;
    /*
     * 添加
     * */
    @RequestMapping(value = "/add",method = RequestMethod.POST)
    public Object addJiangXueJinApply(HttpServletRequest request) {
        JSONObject jsonObject = new JSONObject();
        String username = request.getParameter("username").trim();
        String number = request.getParameter("number").trim();
        String name = request.getParameter("name").trim();
        String jxj_level = request.getParameter("jxjLevel").trim(); //奖学金类型
        String address = request.getParameter("address").trim();//
        String className = request.getParameter("className").trim();
        String applyTime = request.getParameter("applyTime").trim();  //
        if(username == null || "".equals(username)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"username不能为空！");
            return jsonObject;
        }
        if(number == null || "".equals(number)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"奖学金编号不能为空！");
            return jsonObject;
        }
        if(name == null || "".equals(name)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"奖学金名称不能为空！");
            return jsonObject;
        }
        //       把申请时间转换成Date格式
        DateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd");
        Date applyTimeDate = new Date();
        try {
            applyTimeDate = dateFormat1.parse(applyTime);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        // 保存到对象中
        JiangXueJinApply jiangXueJinApply = new JiangXueJinApply();
        jiangXueJinApply.setUsername(username);
        jiangXueJinApply.setNumber(number);
        jiangXueJinApply.setName(name);
        jiangXueJinApply.setJxjLevel(jxj_level);
        jiangXueJinApply.setAddress(address);
        jiangXueJinApply.setClassName(className);
        jiangXueJinApply.setApplyTime(applyTimeDate);

        boolean flag = jiangXueJinApplyService.insert(jiangXueJinApply);
        if(flag){
            jsonObject.put(Consts.CODE,1);
            jsonObject.put(Consts.MSG,"添加成功！");
            return jsonObject;
        }
        jsonObject.put(Consts.CODE,0);
        jsonObject.put(Consts.MSG,"添加失败！");
        return jsonObject;

    }

    /*
     * 删除
     * */
    @RequestMapping(value = "/delete",method = RequestMethod.GET)
    public Object deleteJiangXueJinApply(HttpServletRequest request){
        String id = request.getParameter("id").trim();
        boolean flag = jiangXueJinApplyService.delete(Integer.parseInt(id));
        return flag;
    }

    /*
     * 修改
     * */
    @RequestMapping(value = "/update",method = RequestMethod.POST)
    public Object updateJiangXueJinApply(HttpServletRequest request){
        JSONObject jsonObject = new JSONObject();
        String id = request.getParameter("id").trim();
        String number = request.getParameter("number").trim();
        String name = request.getParameter("name").trim();
        String jxj_level = request.getParameter("jxjLevel").trim(); //奖学金类型
        String address = request.getParameter("address").trim();//
        String className = request.getParameter("className").trim();
        String applyTime = request.getParameter("applyTime").trim();  //

        if(number == null || "".equals(number)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"奖学金编号不能为空！");
            return jsonObject;
        }
        if(name == null || "".equals(name)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"奖学金名称不能为空！");
            return jsonObject;
        }
        //       把申请时间转换成Date格式
        DateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd");
        Date applyTiemDate = new Date();
        try {
            applyTiemDate = dateFormat1.parse(applyTime);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        // 保存到对象中
        JiangXueJinApply jiangXueJinApply = new JiangXueJinApply();
        jiangXueJinApply.setId(Integer.parseInt(id));
        jiangXueJinApply.setNumber(number);
        jiangXueJinApply.setName(name);
        jiangXueJinApply.setJxjLevel(jxj_level);
        jiangXueJinApply.setAddress(address);
        jiangXueJinApply.setClassName(className);
        jiangXueJinApply.setApplyTime(applyTiemDate);

        boolean flag = jiangXueJinApplyService.update(jiangXueJinApply);
        if(flag){
            jsonObject.put(Consts.CODE,1);
            jsonObject.put(Consts.MSG,"添加成功！");
            return jsonObject;
        }
        jsonObject.put(Consts.CODE,0);
        jsonObject.put(Consts.MSG,"添加失败！");
        return jsonObject;

    }

    /*
     * 辅导员审批
     * */
    @RequestMapping(value = "/updateJiangXueJinApplyForTeacher",method = RequestMethod.POST)
    public Object updateJiangXueJinApplyForTeacher(HttpServletRequest request){
        JSONObject jsonObject = new JSONObject();
        String id = request.getParameter("id").trim();
        String teacherCheck = request.getParameter("teacherCheck").trim(); //
        String teacherOpinion = request.getParameter("teacherOpinion").trim(); //

        if(teacherCheck == null || "".equals(teacherCheck)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"是否同意不能为空！");
            return jsonObject;
        }

//       保存到用户的对象中
        JiangXueJinApply jiangXueJinApply = new JiangXueJinApply();
        jiangXueJinApply.setId(Integer.parseInt(id));
        jiangXueJinApply.setTeacherCheck(teacherCheck);
        jiangXueJinApply.setTeacherOpinion(teacherOpinion);
        boolean flag = jiangXueJinApplyService.updateJiangXueJinApplyForTeacher(jiangXueJinApply);

        if(flag){
            jsonObject.put(Consts.CODE,1);
            jsonObject.put(Consts.MSG,"提交成功！");
            return jsonObject;
        }
        jsonObject.put(Consts.CODE,0);
        jsonObject.put(Consts.MSG,"提交失败！");
        return jsonObject;

    }
    /*
     * 教务处审批
     * */
    @RequestMapping(value = "/updateJiangXueJinApplyForOffice",method = RequestMethod.POST)
    public Object updateJiangXueJinApplyForOffice(HttpServletRequest request){
        JSONObject jsonObject = new JSONObject();
        String id = request.getParameter("id").trim();
        String officeCheck = request.getParameter("officeCheck").trim(); //
        String officeOpinion = request.getParameter("officeOpinion").trim(); //

        if(officeCheck == null || "".equals(officeCheck)){
            jsonObject.put(Consts.CODE,0);
            jsonObject.put(Consts.MSG,"是否同意不能为空！");
            return jsonObject;
        }

//       保存到用户的对象中
        JiangXueJinApply jiangXueJinApply = new JiangXueJinApply();
        jiangXueJinApply.setId(Integer.parseInt(id));
        jiangXueJinApply.setOfficeCheck(officeCheck);
        jiangXueJinApply.setOfficeOpinion(officeOpinion);
        boolean flag = jiangXueJinApplyService.updateJiangXueJinApplyForOffice(jiangXueJinApply);

        if(flag){
            jsonObject.put(Consts.CODE,1);
            jsonObject.put(Consts.MSG,"提交成功！");
            return jsonObject;
        }
        jsonObject.put(Consts.CODE,0);
        jsonObject.put(Consts.MSG,"提交失败！");
        return jsonObject;

    }


    /*
     * 查询所有
     * */
    @RequestMapping(value = "/selectAllJiangXueJinApply",method = RequestMethod.GET)
    public Object selectAllJiangXueJinApply(HttpServletRequest request){
        return jiangXueJinApplyService.selectAllJiangXueJinApply();
    }

    // 根据登录用户 查询申请奖学金情况
    @RequestMapping(value = "/getJiangXueJinApplyByUsername",method = RequestMethod.POST)
    public Object getJiangXueJinApplyByUsername(HttpServletRequest request){
        String username = request.getParameter("username").trim();
        return jiangXueJinApplyService.getJiangXueJinApplyByUsername(username);
    }
    //查询辅导员审批同意的奖学金申请学生信息
    @RequestMapping(value = "/selectJiangXueJinApplyByTeacherPass",method = RequestMethod.GET)
    public Object selectJiangXueJinApplyByTeacherPass(HttpServletRequest request){
        return jiangXueJinApplyService.selectJiangXueJinApplyByTeacherPass();
    }

    //查询教务处审批同意的金申请学生信息
    // @RequestMapping(value = "/selectJiangXueJinApplyByOfficePass",method = RequestMethod.GET)
    // public Object selectJiangXueJinApplyByOfficePass(HttpServletRequest request){
    //     return jiangXueJinApplyService.selectJiangXueJinApplyByOfficePass();
    // }

    /*
     * 根据id(主键)查询整个对象
     * */
    @RequestMapping(value = "/selectJiangXueJinApplyByKey",method = RequestMethod.GET)
    public Object selectJiangXueJinApplyByKey(HttpServletRequest request){
        String id = request.getParameter("id").trim();
        return jiangXueJinApplyService.selectJiangXueJinApplyByKey(Integer.parseInt(id));
    }

    //根据工号精确查询
    @RequestMapping(value = "/selectJiangXueJinApplyByNumber",method = RequestMethod.GET)
    public Object selectJiangXueJinApplyByNumber(HttpServletRequest request){
        String number = request.getParameter("number").trim();
        return jiangXueJinApplyService.selectJiangXueJinApplyByNumber(number);
    }

    //根据名字模糊查询
    @RequestMapping(value = "/selectJiangXueJinApplyByName",method = RequestMethod.GET)
    public Object selectJiangXueJinApplyByName(HttpServletRequest request){
        String name = request.getParameter("name").trim();
        return jiangXueJinApplyService.selectJiangXueJinApplyByName("%"+name+"%");
    }

}
