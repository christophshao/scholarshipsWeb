package com.sjf.scholarships.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sjf.scholarships.dao.StudentMapper;
import com.sjf.scholarships.domain.Student;
import com.sjf.scholarships.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentServiceImpl implements StudentService {

    @Override
    public boolean verifyPassword(String username, String password,String role) {
        return studentMapper.verifyPassword(username,password,role)>0;
    }

    @Autowired
    private StudentMapper studentMapper;

    @Override
    public boolean insert(Student student) {
        return studentMapper.insert(student)>0;
    }

    @Override
    public int batchInsert(List<Student> students) {
        try {
            return studentMapper.batchInsert(students);
        } catch (DataAccessException e) {
            // 处理数据库异常
            // 可以返回错误信息给前端，或者记录日志等
            e.printStackTrace();
            return 0; // 根据实际情况返回合适的值
        }
    }


    // @Override
    // public void batchInsert(List<Student> students) {
    //     studentMapper.batchInsert(students);
    // }


    // @Override
    // public boolean batchInsert(List<Student> studentList) {
    //     return studentMapper.batchInsert(studentList.toString()) > 0;
    // }
    // @Override
    // public boolean batchInsert(List<Student> studentList){
    //     ObjectMapper mapper = new ObjectMapper();
    //     String studentJson = null;
    //     try {
    //         studentJson = mapper.writeValueAsString(studentList);
    //     } catch (JsonProcessingException e) {
    //         throw new RuntimeException(e);
    //     }
    //     return studentMapper.batchInsert(studentJson) > 0;
    // }

    // @Override
    // public boolean batchInsert(String studentList) {
    //     return studentMapper.batchInsert(studentList) > 0;
    // }

    @Override
    public boolean delete(Integer id) {
        return studentMapper.delete(id)>0;
    }

    @Override
    public boolean update(Student student) {
        return studentMapper.update(student)>0;
    }

    @Override
    public boolean updateStudentByMine(Student student) {
        return studentMapper.updateStudentByMine(student)>0;
    }

    @Override
    public List<Student> selectAllStudent() {
        return studentMapper.selectAllStudent();
    }

    @Override
    public Student selectByUsername(String username) {
        return studentMapper.selectByUsername(username);
    }

    @Override
    public Student selectStudentByKey(Integer id) {
        return studentMapper.selectStudentByKey(id);
    }

    @Override
    public Student selectStudentByNumber(String number) {
        return studentMapper.selectStudentByNumber(number);
    }

    @Override
    public Student selectStudentByName(String name) {
        return studentMapper.selectStudentByName(name);
    }
}
