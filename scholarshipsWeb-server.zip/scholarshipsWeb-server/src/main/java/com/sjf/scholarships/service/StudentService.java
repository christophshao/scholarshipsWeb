package com.sjf.scholarships.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.sjf.scholarships.domain.Student;

import java.util.List;

public interface StudentService {
    //校验登录身份
    public boolean verifyPassword(String username,String password,String role);

    // 添加学生
    public boolean insert(Student student);

    // 插入 Student 批量信息
    public int batchInsert(List<Student> students);

    // public boolean batchInsert(List<Student> studentList) throws JsonProcessingException;

    // boolean batchInsert(String studentList);

    // 删除学生
    public boolean delete(Integer id);

    // 修改学生信息
    public boolean update(Student student);

    public boolean updateStudentByMine(Student student);

    //  根据用户名查询用户信息
    public Student selectByUsername(String username);

    // 根据id查询学生
    public Student selectStudentByKey(Integer id);

    // 根据学号查询学生
    public Student selectStudentByNumber(String number);

    // 查询所有学生
    public List<Student> selectAllStudent();

    // 根据学生姓名模糊查询学生
    public Student selectStudentByName(String name);
}
