package com.sjf.scholarships.dao;

import com.sjf.scholarships.domain.Admin;
import com.sjf.scholarships.domain.Bulletin;
import com.sjf.scholarships.domain.Student;
import org.springframework.stereotype.Repository;

import java.util.List;
/*
* 管理员Dao
* */

@Repository
public interface AdminMapper {
    /*
    * 校验账号密码
    * */
    public int verifyPassword(String username,String password,String role);

    //  根据用户名查询用户信息
    public Admin selectAdminByUsername(String username);

    // 查询所有管理员
    public List<Admin> selectAllAdmin();

    // 修改信息
    public int update(Admin admin);
}
