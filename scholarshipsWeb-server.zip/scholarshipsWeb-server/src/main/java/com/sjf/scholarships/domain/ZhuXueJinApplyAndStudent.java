package com.sjf.scholarships.domain;

import java.io.Serializable;
import java.util.Date;

public class ZhuXueJinApplyAndStudent implements Serializable {
    private Integer id;
    private String username;
    private String number;
    private String name;
    private String zxjLevel;
    private String address;
    private String className;
    private Date applyTime;
    private String teacherCheck;//辅导员审核
    private String officeCheck;//教务处审核
    private String teacherOpinion;
    private String officeOpinion;

    /******/
    private String gpa;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getZxjLevel() {
        return zxjLevel;
    }

    public void setZxjLevel(String zxjLevel) {
        this.zxjLevel = zxjLevel;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public Date getApplyTime() {
        return applyTime;
    }

    public void setApplyTime(Date applyTime) {
        this.applyTime = applyTime;
    }

    public String getTeacherCheck() {
        return teacherCheck;
    }

    public void setTeacherCheck(String teacherCheck) {
        this.teacherCheck = teacherCheck;
    }

    public String getOfficeCheck() {
        return officeCheck;
    }

    public void setOfficeCheck(String officeCheck) {
        this.officeCheck = officeCheck;
    }

    public String getTeacherOpinion() {
        return teacherOpinion;
    }

    public void setTeacherOpinion(String teacherOpinion) {
        this.teacherOpinion = teacherOpinion;
    }

    public String getOfficeOpinion() {
        return officeOpinion;
    }

    public void setOfficeOpinion(String officeOpinion) {
        this.officeOpinion = officeOpinion;
    }

    public String getGpa() {
        return gpa;
    }

    public void setGpa(String gpa) {
        this.gpa = gpa;
    }
}
