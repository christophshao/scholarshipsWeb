package com.sjf.scholarships.dao;

import com.sjf.scholarships.domain.JiangXueJinType;
import com.sjf.scholarships.domain.Office;
import com.sjf.scholarships.domain.Student;
import org.springframework.stereotype.Repository;

import java.util.List;
/*
* Dao
* */

@Repository
public interface JiangXueJinTypeMapper {
    /*
    *添加
    * */
    public int insert(JiangXueJinType jiangXueJinType);

    // 删除
    public int delete(Integer id);

    // 修改信息
    public int update(JiangXueJinType jiangXueJinType);

    // 查询所有
    public List<JiangXueJinType> selectAllJiangXueJinType();

    // 根据学生姓名模糊查询
    public JiangXueJinType selectJiangXueJinTypeByType(String type);

    //
    public JiangXueJinType selectJiangXueJinTypeByKey(Integer id);
}
