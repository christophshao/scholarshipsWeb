/*
*往后台传递相关的参数的js文件
*/

import {get,post} from "./http";

// ==============================不同用户角色登录==========================================
// 判断管理员是否登录成功（向后台的登录的代码传递参数）
export const getLoginStatus = (params) => post(`admin/login/status`,params);
// 判断学生是否登录成功（向后台的登录的代码传递参数）
export const getStudentLoginStatus = (params) => post(`student/login/status`,params);
// 判断辅导员是否登录成功（向后台的登录的代码传递参数）
export const getTeacherLoginStatus = (params) => post(`teacher/login/status`,params);
// 判断教务处是否登录成功（向后台的登录的代码传递参数）
export const getOfficeLoginStatus = (params) => post(`office/login/status`,params);


//==============================后台管理模块======================================================================

// 根据登录用户名查询用户信息
export const getAdminUser = (params) => post(`admin/selectAdminByUsername`,params);
// export const getAllAdminUser = () => get(`admin/selectAllAdmin`);
// 修改密码
export const updateMine = (params) => post(`admin/updateMine`,params);

/******学生角色相关 转到后台的地址页面******/
// 根据登录用户名查询用户信息
export const getStudentUser = (params) => post(`student/selectByUsername`,params);
// 查询学生
export const getAllStudent = () => get(`student/selectAllStudent`);
// 添加学生
export const addStudent = (params) => post(`student/add`,params);
//
export const excelUpload = (params) => post(`student/excel/upload`,params);
// 删除学生
export const deleteStudent = (id) => get(`student/delete?id=${id}`);
// 修改学生
export const updateStudent = (params) => post(`student/update`,params);

// 修改学生
export const updateStudentByMine = (params) => post(`student/updateStudentByMine`,params);
// 修改学生密码
export const updateStudentPassword = (params) => post(`student/updateStudentPassword`,params);

/******辅导员相关 转到后台的地址页面******/
// 根据登录用户名查询用户信息
export const getTeacherUser = (params) => post(`teacher/selectByUsername`,params);
// 查询辅导员
export const getAllTeacher = () => get(`teacher/selectAllTeacher`);
// 添加辅导员
export const addTeacher = (params) => post(`teacher/add`,params);
// 删除辅导员
export const deleteTeacher = (id) => get(`teacher/delete?id=${id}`);
// 修改辅导员
export const updateTeacher = (params) => post(`teacher/update`,params);
// 修改学生密码
export const updateTeacherPassword = (params) => post(`teacher/updateTeacherPassword`,params);

/******教务处相关 转到后台的地址页面******/
// 根据登录用户名查询用户信息
export const getOfficeUser = (params) => post(`office/selectByUsername`,params)
// 查询教务处
export const getAllOffice = () => get(`office/selectAllOffice`)
// 添加教务处
export const addOffice = (params) => post(`office/add`,params)
// 删除教务处
export const deleteOffice = (id) => get(`office/delete?id=${id}`)
// 修改教务处
export const updateOffice = (params) => post(`office/update`,params)
// 修改教务处密码
export const updateOfficePassword = (params) => post(`office/updateOfficePassword`,params)
// 提交贫困生名单
export const addListPoorStudent = (params) => post(`list/addListPoorStudent`,params)
// 提交助学金申请名单
export const addListZhuXueJinApply = (params) => post(`list/addListZhuXueJinApply`,params)
// 提交奖学金申请名单
export const addListJiangXueJinApply = (params) => post(`list/addListJiangXueJinApply`,params)
// 根据选项 查询名单
export const getAllListByOption = (params) => post(`list/getAllListByOption`,params)

/******奖学金相关 转到后台的地址页面******/
// 查询奖学金
export const getAllJiangXueJin = () => get(`jiangxuejin/selectAllJiangXueJin`);
// 添加奖学金
export const addJiangXueJin = (params) => post(`jiangxuejin/add`,params);
// 删除奖学金
export const deleteJiangXueJin = (id) => get(`jiangxuejin/delete?id=${id}`);
// 修改奖学金
export const updateJiangXueJin = (params) => post(`jiangxuejin/update`,params);
//查询奖学金类型
export const getJxjData = () => get(`jiangxuejintype/selectAllJingXueJinType`);

/******奖学金类型相关 转到后台的地址页面******/
// 查询奖学金类型
export const getAllJiangXueJinType = () => get(`jiangxuejintype/selectAllJingXueJinType`);
// 添加奖学金类型
export const addJiangXueJinType = (params) => post(`jiangxuejintype/add`,params);
// 删除奖学金类型
export const deleteJiangXueJinType = (id) => get(`jiangxuejintype/delete?id=${id}`);
// 修改奖学金类型
export const updateJiangXueJinType = (params) => post(`jiangxuejintype/update`,params);

/******助学金相关 转到后台的地址页面******/
// 查询助学金
export const getAllZhuXueJin = () => get(`zhuxuejin/selectAllZhuXueJin`);
// 添加助学金
export const addZhuXueJin = (params) => post(`zhuxuejin/add`,params);
// 删除助学金
export const deleteZhuXueJin = (id) => get(`zhuxuejin/delete?id=${id}`);
// 修改奖学金
export const updateZhuXueJin = (params) => post(`zhuxuejin/update`,params);

/******助学金类型相关 转到后台的地址页面******/
// 查询助学金类型
export const getAllZhuXueJinType = () => get(`zhuxuejintype/selectAllZhuXueJinType`);
// 添加助学金类型
export const addZhuXueJinType = (params) => post(`zhuxuejintype/add`,params);
// 删除助学金类型
export const deleteZhuXueJinType = (id) => get(`zhuxuejintype/delete?id=${id}`);
// 修改助学金类型
export const updateZhuXueJinType = (params) => post(`zhuxuejintype/update`,params);

/******公告管理相关 转到后台的地址页面******/
// 查询公告管理
export const getAllBulletin = () => get(`bulletin/selectAllBulletin`);
// 添加公告管理
export const addBulletin = (params) => post(`bulletin/add`,params);
// 删除公告管理
export const deleteBulletin = (id) => get(`bulletin/delete?id=${id}`);
// 修改公告管理
export const updateBulletin = (params) => post(`bulletin/update`,params);

/******贫困生申请管理相关 转到后台的地址页面******/
// 贫困生申请管理
export const getAllPoorStudent = () => get(`poorstudent/selectAllPoorStudent`);
// export const getPoorStudentByUsername = (params) =>post(`poorstudent/getPoorStudentByUsername`,params);
export const getPoorStudentByUsername = (params) => post(`poorstudent/getPoorStudentByUsername`,params);
// 查询辅导员审批同意的奖学金申请学生信息
export const selectAllPoorStudentByTeacherPass = () => get(`poorstudent/selectAllPoorStudentByTeacherPass`);

// 添加贫困生申请管理
export const addPoorStudent = (params) => post(`poorstudent/add`,params);
// 删除贫困生申请管理
export const deletePoorStudent = (id) => get(`poorstudent/delete?id=${id}`);
// 修改贫困生申请管理
export const updatePoorStudent = (params) => post(`poorstudent/update`,params);
// 辅导员审批
export const updatePoorStudentForTeacher = (params) => post(`poorstudent/updatePoorStudentForTeacher`,params);
// 教务处审批
export const updatePoorStudentForOffice = (params) => post(`poorstudent/updatePoorStudentForOffice`,params);


/*********************申请奖学金*********************** */
// 查询奖学金申请
export const getAllJiangXueJinApply = () => get(`jiangxuejinapply/selectAllJiangXueJinApply`);
//jxj
export const getJiangXueJinApplyByUsername = (params) => post(`jiangxuejinapply/getJiangXueJinApplyByUsername`,params);
// 查询辅导员审批同意的奖学金申请学生信息
export const selectJiangXueJinApplyByTeacherPass = () => get(`jiangxuejinapply/selectJiangXueJinApplyByTeacherPass`);
// 添加奖学金申请
export const addJiangXueJinApply = (params) => post(`jiangxuejinapply/add`,params);
// 删除奖学金申请
export const deleteJiangXueJinApply = (id) => get(`jiangxuejinapply/delete?id=${id}`);
// 修改奖学金申请
export const updateJiangXueJinApply = (params) => post(`jiangxuejinapply/update`,params);
// 辅导员审批奖学金
export const updateJiangXueJinApplyForTeacher = (params) => post(`jiangxuejinapply/updateJiangXueJinApplyForTeacher`,params);
// 教务处审批奖学金
export const updateJiangXueJinApplyForOffice = (params) => post(`jiangxuejinapply/updateJiangXueJinApplyForOffice`,params);


/*********************申请助学金*********************** */
// 查询助学金申请
export const getAllZhuXueJinApply = () => get(`zhuxuejinapply/selectAllZhuXueJinApply`);
export const getZhuXueJinApplyByUsername = (params) => post(`zhuxuejinapply/getZhuXueJinApplyByUsername`,params);

// 查询辅导员审批同意的助学金申请学生信息
export const selectZhuXueJinApplyByTeacherPass = () => get(`zhuxuejinapply/selectZhuXueJinApplyByTeacherPass`);
// 添加奖学金申请
export const addZhuXueJinApply = (params) => post(`zhuxuejinapply/add`,params);
// 删除奖学金申请
export const deleteZhuXueJinApply = (id) => get(`zhuxuejinapply/delete?id=${id}`);
// 修改奖学金申请
export const updateZhuXueJinApply = (params) => post(`zhuxuejinapply/update`,params);
// 辅导员审批助学金
export const updateZhuXueJinApplyForTeacher = (params) => post(`zhuxuejinapply/updateZhuXueJinApplyForTeacher`,params);
// 教务处审批助学金
export const updateZhuXueJinApplyForOffice = (params) => post(`zhuxuejinapply/updateZhuXueJinApplyForOffice`,params);


