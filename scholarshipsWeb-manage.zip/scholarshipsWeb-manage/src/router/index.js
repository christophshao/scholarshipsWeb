import Vue, {
  computed
} from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter);

// 配置导出路由
export default new VueRouter({
  // 注意这里是routes
  routes: [
    // 404 not found
    
    {
      name: '登录',
      path: '/',
      component: resolve => require(['../views/Login'], resolve)
    },
    // 后台管理
    {
      name:'后台管理',
      path: '/admin/Home',
      component: resolve => require(['../components/admin/Home.vue'],resolve),
      children:[
        {
          path: '/admin/Info',
          component: resolve => require(['../views/admin/InfoPage.vue'], resolve)
        },
        {
          path: '/admin/Mine',
          component: resolve => require(['../views/admin/MinePage.vue'], resolve)
        },
        {
          path: '/admin/Student',
          component: resolve => require(['../views/admin/StudentPage.vue'], resolve)
        },
        {
          path: '/admin/Teacher',
          component: resolve => require(['../views/admin/TeacherPage.vue'], resolve)
        },
        {
          path: '/admin/Office',
          component: resolve => require(['../views/admin/OfficePage.vue'], resolve)
        },
        {
          path: '/admin/JiangXueJinType',
          component: resolve => require(['../views/admin/JiangXueJinTypePage.vue'], resolve)
        },
        {
          path: '/admin/JiangXueJinMessage',
          component: resolve => require(['../views/admin/JiangXueJinMessagePage.vue'], resolve)
        },
        {
          path: '/admin/PoorStudent',
          component: resolve => require(['../views/admin/PoorStudentPage.vue'], resolve)
        },
        {
          path: '/admin/ZhuXueJinType',
          component: resolve => require(['../views/admin/ZhuXueJinTypePage.vue'], resolve)
        },
        {
          path: '/admin/ZhuXueJinMessage',
          component: resolve => require(['../views/admin/ZhuXueJinMessagePage.vue'], resolve)
        },
        {
          path: '/admin/ZhuXueJinApply',
          component: resolve => require(['../views/admin/ZhuXueJinApply.vue'], resolve)
        },
        {
          path: '/admin/JiangXueJinApply',
          component: resolve => require(['../views/admin/JiangXueJinApply.vue'], resolve)
        },
        {
          name:'公告栏管理',
          path: '/admin/Bulletin',
          component: resolve => require(['../views/admin/BulletinPage.vue'], resolve)
        },

      ]
    },
    // 学生模块后台管理
    {
      name:'学生模块后台管理',
      path: '/student/Home',
      component: resolve => require(['../components/student/Home.vue'],resolve),
      children:[
        {
          path: '/student/Mine',
          component: resolve => require(['../views/student/MinePage.vue'], resolve)
        },
        {
          path: '/student/PoorStudent',
          component: resolve => require(['../views/student/PoorStudentPage.vue'], resolve)
        },
        {
          path: '/student/ZhuXueJinApply',
          component: resolve => require(['../views/student/ZhuXueJinApply.vue'], resolve)
        },
        {
          path: '/student/JiangXueJinApply',
          component: resolve => require(['../views/student/JiangXueJinApply.vue'], resolve)
        },

      ]
    },
    // 辅导员模块后台管理
    {
      name:'辅导员模块后台管理',
      path: '/teacher/Home',
      component: resolve => require(['../components/teacher/Home.vue'],resolve),
      children:[
        {
          path: '/teacher/Info',
          component: resolve => require(['../views/teacher/TeacherInfoPage.vue'], resolve)
        },
        {
          path: '/teacher/Mine',
          component: resolve => require(['../views/teacher/MinePage.vue'], resolve)
        },
        {
          path: '/teacher/PoorStudent',
          component: resolve => require(['../views/teacher/PoorStudentPage.vue'], resolve)
        },
        {
          path: '/teacher/ZhuXueJinApply',
          component: resolve => require(['../views/teacher/ZhuXueJinApply.vue'], resolve)
        },
        {
          path: '/teacher/JiangXueJinApply',
          component: resolve => require(['../views/teacher/JiangXueJinApply.vue'], resolve)
        },

      ]
    },
    // 教务处模块后台管理
    {
      name:'教务处模块后台管理',
      path: '/office/Home',
      component: resolve => require(['../components/office/Home.vue'],resolve),
      children:[
        {
          path: '/office/Info',
          component: resolve => require(['../views/office/OfficeInfoPage.vue'], resolve)
        },
        {
          path: '/office/Mine',
          component: resolve => require(['../views/office/MinePage.vue'], resolve)
        },
        {
          path: '/office/PoorStudent',
          component: resolve => require(['../views/office/PoorStudentPage.vue'], resolve)
        },
        {
          path: '/office/ZhuXueJinApply',
          component: resolve => require(['../views/office/ZhuXueJinApply.vue'], resolve)
        },
        {
          path: '/office/JiangXueJinApply',
          component: resolve => require(['../views/office/JiangXueJinApply.vue'], resolve)
        },
        {
          path: '/office/ListAdmin',
          component: resolve => require(['../views/office/ListAdmin.vue'], resolve)
        },
        {
          path: '/office/Bulletin',
          component: resolve => require(['../views/office/BulletinPage.vue'], resolve)
        },

      ]
    },
    {
      name: '404',
      path: '*',
      component: resolve => require(['../views/404'], resolve),
    },
    


  ]
});
