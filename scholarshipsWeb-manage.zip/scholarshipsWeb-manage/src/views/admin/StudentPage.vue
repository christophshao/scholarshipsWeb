<template>
  <div class="table">
    <!-- 功能区域 -->
    <div class="container">
      <div class="handle-box">
        <!-- 批量删除 -->
        <el-button type="danger" size="small" @click="deleteAll">
          批量删除
        </el-button>
        <!-- 添加 -->
        <el-button type="primary" size="small" @click="addDialogVisible = true">
          添加用户
        </el-button>
        <!-- 查询 -->
        <el-input v-model="select_word" placeholder="请输入学生名..." class="handle-input" size="small">
        </el-input>
        <!-- 批量导入从 excel -->
        <div style="float: right; width: 400px;">
          <el-upload action accept=".xlsx,.xls" :auto-upload="false" :show-file-list="false" :on-change="handle"
            style="float:left">
            <el-button type="primary" slot="trigger">导入 Excel 文件</el-button>&nbsp;&nbsp;
          </el-upload>
          <el-button type="primary" @click="excelImportVisible = true" style="float:left">预览数据</el-button>
          <el-button type="success" @click="submit" style="float:left">采集数据提交</el-button>
        </div>
      </div>
    </div>
    <!-- 添加学生-弹窗 -->
    <el-dialog title="添加学生" :visible.sync="addDialogVisible" width="450px" center>
      <el-form :model="registerForm" ref="registerForm" label-width="80px" :rules="rules">
        <el-form-item prop="number" label="学号" size="mini">
          <el-input v-model="registerForm.number" placeholder="学号"></el-input>
        </el-form-item>
        <el-form-item prop="name" label="学生姓名" size="mini">
          <el-input v-model="registerForm.name" placeholder="学生姓名"></el-input>
        </el-form-item>
        <el-form-item prop="gpa" label="GPA" size="mini">
          <el-input v-model="registerForm.gpa" placeholder="GPA"></el-input>
        </el-form-item>
        <el-form-item prop="username" label="用户名" size="mini">
          <el-input v-model="registerForm.username" placeholder="用户名"></el-input>
        </el-form-item>
        <el-form-item prop="password" label="密码" size="mini">
          <el-input v-model="registerForm.password" placeholder="密码" type="password"></el-input>
        </el-form-item>
        <el-form-item prop="sex" label="性别" size="mini">
          <input type="radio" name="sex" value="1" v-model="registerForm.sex" />&nbsp;男&nbsp;&nbsp;
          <input type="radio" name="sex" value="0" v-model="registerForm.sex" />&nbsp;女
        </el-form-item>
        <!-- <el-form-item prop="className" label="学院" size="mini">
            <el-input v-model="registerForm.className" placeholder="学院"></el-input>
          </el-form-item> -->
        <el-form-item prop="className" label="所属学院" size="mini">
          <el-select v-model="registerForm.className" placeholder="请选择">
            <el-option label="数工学院" value="1" key="1"></el-option>
            <el-option label="人文学院" value="2"></el-option>
            <el-option label="计算机学院" value="3"></el-option>
            <el-option label="经贸学院" value="4"></el-option>
            <el-option label="艺术学院" value="5"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item prop="birth" label="生日" size="mini">
          <el-date-picker v-model="registerForm.birth" placeholder="选择日期" type="date" style="width:100%"></el-date-picker>
        </el-form-item>
        <el-form-item prop="nationality" label="民族" size="mini">
          <el-input v-model="registerForm.nationality" placeholder="民族"></el-input>
        </el-form-item>
        <el-form-item prop="politicalStatus" label="政治面貌" size="mini">
          <el-input v-model="registerForm.politicalStatus" placeholder="政治面貌"></el-input>
        </el-form-item>
        <el-form-item prop="nativePlace" label="籍贯" size="mini">
          <el-input v-model="registerForm.nativePlace" placeholder="籍贯"></el-input>
        </el-form-item>
        <el-form-item prop="address" label="家庭住址" size="mini">
          <el-input v-model="registerForm.address" placeholder="家庭住址"></el-input>
        </el-form-item>
        <el-form-item prop="postcard" label="邮政编码" size="mini">
          <el-input v-model="registerForm.postcard" placeholder="邮政编码"></el-input>
        </el-form-item>
        <el-form-item prop="familyPhone" label="家庭电话" size="mini">
          <el-input v-model="registerForm.familyPhone" placeholder="家庭电话"></el-input>
        </el-form-item>
        <el-form-item prop="mobilePhone" label="个人电话" size="mini">
          <el-input v-model="registerForm.mobilePhone" placeholder="个人电话"></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer">
        <el-button @click="insertSave" size="mini">确定</el-button>
        <el-button @click="addDialogVisible = false" size="mini">取消</el-button>
      </span>
    </el-dialog>

    <!-- 删除歌手-弹窗 -->
    <el-dialog title="删除学生" :visible.sync="deleteVisible" width="300px" center>
      <div style="text-align:center">删除不可恢复，是否确认删除</div>
      <span slot="footer">
        <el-button @click="deleteRow" size="mini">确定</el-button>
        <el-button @click="deleteVisible = false" size="mini">取消</el-button>
      </span>
    </el-dialog>

    <!-- 修改学生信息-弹窗 -->
    <el-dialog title="修改学生信息" :visible.sync="editVisible" width="450px" center>
      <el-form :model="editForm" ref="editForm" label-width="80px" :rules="rules">
        <el-form-item prop="number" label="学号" size="mini">
          <el-input v-model="editForm.number" placeholder="学号"></el-input>
        </el-form-item>
        <el-form-item prop="name" label="学生姓名" size="mini">
          <el-input v-model="editForm.name" placeholder="学生姓名"></el-input>
        </el-form-item>
        <el-form-item prop="gpa" label="GPA" size="mini">
          <el-input v-model="editForm.gpa" placeholder="GPA"></el-input>
        </el-form-item>
        <el-form-item prop="username" label="用户名" size="mini">
          <el-input v-model="editForm.username" placeholder="用户名"></el-input>
        </el-form-item>
        <el-form-item prop="password" label="密码" size="mini">
          <el-input v-model="editForm.password" placeholder="密码" type="password"></el-input>
        </el-form-item>
        <el-form-item prop="sex" label="性别" size="mini">
          <input type="radio" name="sex" value="1" v-model="editForm.sex" />&nbsp;男&nbsp;&nbsp;
          <input type="radio" name="sex" value="2" v-model="editForm.sex" />&nbsp;女
        </el-form-item>
        <el-form-item prop="className" label="所属学院" size="mini">
          <el-select v-model="editForm.className" placeholder="请选择">
            <el-option label="数工学院" value="1" key="1"></el-option>
            <el-option label="人文学院" value="2"></el-option>
            <el-option label="计算机学院" value="3"></el-option>
            <el-option label="经贸学院" value="4"></el-option>
            <el-option label="艺术学院" value="5"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item prop="birth" label="生日" size="mini">
          <el-date-picker v-model="editForm.birth" placeholder="选择日期" type="date" style="width:100%"></el-date-picker>
        </el-form-item>
        <el-form-item prop="nationality" label="民族" size="mini">
          <el-input v-model="editForm.nationality" placeholder="民族"></el-input>
        </el-form-item>
        <el-form-item prop="politicalStatus" label="政治面貌" size="mini">
          <el-input v-model="editForm.politicalStatus" placeholder="政治面貌"></el-input>
        </el-form-item>
        <el-form-item prop="nativePlace" label="籍贯" size="mini">
          <el-input v-model="editForm.nativePlace" placeholder="籍贯"></el-input>
        </el-form-item>
        <el-form-item prop="address" label="家庭住址" size="mini">
          <el-input v-model="editForm.address" placeholder="家庭住址"></el-input>
        </el-form-item>
        <el-form-item prop="postcard" label="邮政编码" size="mini">
          <el-input v-model="editForm.postcard" placeholder="邮政编码"></el-input>
        </el-form-item>
        <el-form-item prop="familyPhone" label="家庭电话" size="mini">
          <el-input v-model="editForm.familyPhone" placeholder="家庭电话"></el-input>
        </el-form-item>
        <el-form-item prop="mobilePhone" label="个人电话" size="mini">
          <el-input v-model="editForm.mobilePhone" placeholder="个人电话"></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer">
        <el-button @click="editSave" size="mini">确定</el-button>
        <el-button @click="editVisible = false" size="mini">取消</el-button>
      </span>
    </el-dialog>

    <!-- 批量导入的数据预提交 -->
    <el-dialog title="批量导入数据" :visible.sync="excelImportVisible">
      <h3>
        <i class="el-icon-info">
          小主，以下是采集完成的数据，请您检查无误后，点击“采集数据提交”按钮上传至服务器
        </i>
      </h3>
      <el-table :data="excelData" border style="width: 100%" :height="height">
        <el-table-column label="学号" prop="number" width="120" align="center"></el-table-column>
        <el-table-column label="姓名" prop="name" width="120" align="center"></el-table-column>
        <el-table-column label="GPA" prop="gpa" width="120" align="center"></el-table-column>
        <el-table-column label="用户名" prop="username" width="120" align="center"></el-table-column>
        <el-table-column label="密码" prop="password" width="120" align="center"></el-table-column>
        <el-table-column label="性别" prop="sex" width="50" align="center"></el-table-column>
        <el-table-column label="学院" prop="className" align="center"></el-table-column>
      </el-table>
    </el-dialog>

    <!-- 查询学生-表格 -->
    <el-table size="small" border style="width:100%" height="510px" :data="data"
      @selection-change="handleSelectionChange">
      <el-table-column label="多选" type="selection" width="50" center></el-table-column>
      <el-table-column label="学号" prop="number" width="120" align="center"></el-table-column>
      <el-table-column label="学生照片" width="110" align="center">
        <template slot-scope="scope">
          <div class="student-img">
            <img :src="getUrl(scope.row.photo)" width="100%" />
          </div>
          <!-- 更新学生图片 -->
          <el-upload :action="uploadUrl(scope.row.id)" :on-success="handleAvatorSuccess">
            <el-button size="mini">更新照片</el-button>
          </el-upload>
        </template>
      </el-table-column>
      <el-table-column label="姓名" prop="name" width="120" align="center"></el-table-column>
      <el-table-column label="GPA" prop="gpa" width="120" align="center"></el-table-column>
      <el-table-column label="用户名" prop="username" width="120" align="center"></el-table-column>
      <el-table-column label="密码" prop="password" width="120" align="center"></el-table-column>
      <el-table-column label="性别" width="50" align="center">
        <template slot-scope="scope">
          {{ getSex(scope.row.sex) }}
        </template>
      </el-table-column>
      <el-table-column label="学院" width="200" align="center">
        <template slot-scope="scope">
          {{ getClassName(scope.row.className) }}
        </template>
      </el-table-column>
      <el-table-column label="生日" width="120" align="center">
        <template slot-scope="scope">
          {{ attachBirth(scope.row.birth) }}
        </template>
      </el-table-column>
      <el-table-column label="民族" prop="nationality" width="120" align="center"></el-table-column>
      <el-table-column label="政治面貌" prop="politicalStatus" width="120" align="center"></el-table-column>
      <el-table-column label="户籍" prop="nativePlace" width="120" align="center"></el-table-column>
      <el-table-column label="家庭住址" prop="address" width="120" align="center"></el-table-column>
      <el-table-column label="家庭电话" prop="familyPhone" width="120" align="center"></el-table-column>
      <el-table-column label="手机号码" prop="mobilePhone" width="120" align="center"></el-table-column>
      <el-table-column label="操作" align="center" width="150px" fixed="right">
        <!-- width:180px -->
        <template slot-scope="scope">
          <el-button type="button" @click="handleEdit(scope.row)" size="small">编辑</el-button>
          <el-button type="danger" @click="handleDelete(scope.row.id)" size="small">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <!-- 分页 -->
    <div class="pageination">
      <el-pagination background layout="total,prev,pager,next" :total="tableData.length" :current-page="currentPage"
        :page-size="pageSize" @current-change="handleCurrentChange">
      </el-pagination>
    </div>

  </div>
</template>

<script>
import { mixin } from "@/mixins/index";
import { getAllStudent, addStudent, updateStudent, deleteStudent, excelUpload } from "@/api/index"
import xlsx from 'xlsx'
import { Loading } from 'element-ui'
import { readFile, character, delay } from '@/assets/js/utils'
export default {
  mixins: [mixin],
  data() {
    return {
      // excel 导入
      height: document.documentElement.clientHeight - 130,
      excelData: [],
      show: false,
      excelImportVisible: false,

      maxSize: 1,
      // 默认为false 当单击事件后变为true 就会显示弹窗
      addDialogVisible: false, //添加弹窗
      editVisible: false,  //修改弹窗
      deleteVisible: false, //删除弹窗

      //添加框
      registerForm: {
        username: '123',
        password: '123',
        number: '123',
        name: '123',
        gpa: '3.0',
        sex: '1',
        className: '123',
        birth: '1',
        nationality: '123',
        politicalStatus: '123',
        nativePlace: '123',
        address: '1123',
        postcard: '123',
        familyPhone: '123',
        mobilePhone: '123',
      },
      //修改框
      editForm: {
        id: '',
        username: '',
        password: '',
        number: '',
        name: '',
        gpa: '',
        sex: '',
        className: '',
        birth: '',
        nationality: '',
        politicalStatus: '',
        nativePlace: '',
        address: '',
        postcard: '',
        familyPhone: '',
        mobilePhone: '',

      },
      tableData: [],  //用于存储查询到的用户信息，一开始默认为空
      tempData: [],
      select_word: '',
      index: -1,   //选择当前项
      multipleSelection: [],   //确定多选项数量
      pageSize: 4, //一张页面展示多少数据
      currentPage: 1, //当前页

      //校验规则
      rules: {
        username: [
          { required: true, message: '请输入用户名', trigger: 'blur' }
        ],
        password: [
          { required: true, message: '请输入密码', trigger: 'blur' }
        ],
        number: [
          { required: true, message: '请输入学生学号', trigger: 'blur' }
        ],
        name: [
          { required: true, message: '请输入学生姓名', trigger: 'blur' }
        ],
        gpa: [
          { required: true, message: '请输入GPA', trigger: 'blur' }
        ],
        className: [
          { required: true, message: '请输入学院', trigger: 'blur' }
        ],
      },
    };
  },
  // 计算当前搜索结果表中的数据
  computed: {
    data() {
      return this.tableData.slice((this.currentPage - 1) * this.pageSize, this.currentPage * this.pageSize);
    }
  },

  // 搜索框发生变化的时候，table中的内容同步变化
  watch: {
    select_word: function () {
      if (this.select_word == '') {
        this.tableData = this.tempData;
      } else {
        this.tableData = [];
        for (let item of this.tempData) {
          if (item.name.includes(this.select_word)) {
            this.tableData.push(item);
          }
        }
      }
    }
  },
  // 创建页面的时候执行
  created() {
    this.getData();
  },
  methods: {
    //查询学生
    getData() {
      this.tempData = [];
      this.tableData = []; //一开始清空tableData 防止之前有残留数据
      getAllStudent().then((res) => {
        this.tempData = res;
        this.tableData = res;
        this.currentPage = 1;
      })
    },
    // 获取当前页
    handleCurrentChange(val) {
      this.currentPage = val;
    },
    // 添加学生
    insertSave() {
      this.$refs['registerForm'].validate(valid => {
        if (valid) {
          let d = this.registerForm.birth;
          let datetime = d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate();

          //接收保存往后台传递的参数,
          let params = new URLSearchParams();
          params.append('username', this.registerForm.username);
          params.append('password', this.registerForm.password);
          params.append('number', this.registerForm.number);
          params.append('name', this.registerForm.name);
          params.append('gpa', this.registerForm.gpa);
          params.append('sex', this.registerForm.sex);
          params.append('photo', 'img/studentPic/default.png');
          params.append('className', this.registerForm.className);
          params.append('birth', datetime);
          params.append('nationality', this.registerForm.nationality + '族');
          params.append('politicalStatus', this.registerForm.politicalStatus);
          params.append('nativePlace', this.registerForm.nativePlace);
          params.append('address', this.registerForm.address);
          params.append('postcard', this.registerForm.postcard);
          params.append('familyPhone', this.registerForm.familyPhone);
          params.append('mobilePhone', this.registerForm.mobilePhone);

          addStudent(params)
            .then((res) => {
              if (res.code == 1) {
                this.getData();
                this.message("添加成功！", "success");
                this.addDialogVisible = false;
              } else {
                this.message("添加失败!", "error");
              }
            })
            .catch(err => {
              console.log(err);
            });
          this.centerDialogVisible = false;
        }
      })


    },
    // 删除信息
    deleteRow() {
      deleteStudent(this.index)
        .then((res) => {
          if (res) {
            this.getData();
            this.message("删除成功！", "success");
          } else {
            this.message("删除失败!", "error");
          }
        })
      this.deleteVisible = false;
    },
    // 弹出编辑用户信息页面
    handleEdit(row) {
      this.editVisible = true;
      this.editForm = {
        id: row.id,
        username: row.username,
        password: row.password,
        number: row.number,
        name: row.name,
        gpa: row.gpa,
        sex: row.sex,
        className: row.className,
        birth: row.birth,
        nationality: row.nationality,
        politicalStatus: row.politicalStatus,
        nativePlace: row.nativePlace,
        address: row.address,
        postcard: row.postcard,
        familyPhone: row.familyPhone,
        mobilePhone: row.mobilePhone,
      }
    },
    // 编辑保存
    editSave() {
      this.$refs['editForm'].validate(valid => {
        if (valid) {
          let d = new Date(this.editForm.birth);
          let datetime = d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate();
          //接收保存往后台传递的参数,
          let params = new URLSearchParams();
          params.append('id', this.editForm.id);
          params.append('username', this.editForm.username);
          params.append('password', this.editForm.password);
          params.append('number', this.editForm.number);
          params.append('name', this.editForm.name);
          params.append('gpa', this.editForm.gpa);
          params.append('sex', this.editForm.sex);
          params.append('className', this.editForm.className);
          params.append('birth', datetime);
          params.append('nationality', this.editForm.nationality);
          params.append('politicalStatus', this.editForm.politicalStatus);
          params.append('nativePlace', this.editForm.nativePlace);
          params.append('address', this.editForm.address);
          params.append('postcard', this.editForm.postcard);
          params.append('familyPhone', this.editForm.familyPhone);
          params.append('mobilePhone', this.editForm.mobilePhone);

          updateStudent(params)
            .then((res) => {
              if (res.code == 1) {
                this.getData();
                this.message("修改成功！", "success");
              } else {
                this.message("修改失败!", "error");
              }
            })
            .catch(err => {
              console.log(err);
            });
          this.editVisible = false;
        }
      })
    },
    // 更新学生照片
    uploadUrl(id) {
      return `${this.$store.state.HOST}/student/updateStudentPic?id=${id}`
    },

    // 采集 EXCEL 数据
    async handle(e) {
      let file = e.raw
      if (!file) return

      this.show = false
      let loading = Loading.service({
        text: '请您稍等片刻，正在玩命处理中...',
        background: 'rgba(0,0,0,.5)'
      })

      await delay(300)

      // 读取FILE中的数据
      let data = await readFile(file)
      let workbook = xlsx.read(data, { type: 'binary' }),
      worksheet = workbook.Sheets[workbook.SheetNames[0]],
      
      list = xlsx.utils.sheet_to_json(worksheet)
      // console.log(list) // 可以有数据

      // 把读取出来的数据变为可以提交为服务器的数据格式
      let arr = []
      let oldData = JSON.parse(window.localStorage.getItem('excel') || '[]')
      // console.log(oldData);
      let index = oldData.length
      list.forEach(item => {
        let obj = {}
        for (let key in character) {
          if (!character.hasOwnProperty(key)) break
          let v = character[key],
            text = v.text,
            type = v.type
          v = item[text] || ''
          type === 'string' ? (v = String(v)) : null
          type === 'number' ? (v = Number(v)) : null
          obj[key] = v
        }
        obj.id = ++index
        // obj.time = new Date()
        arr.push(obj)
      })

      await delay(300)

      // 展示到页面中
      this.show = true
      // console.log(arr)
      this.excelData = arr
      loading.close()
    },
    // 提交数据给服务器
    submit() {
      if (this.excelData.length <= 0) {
        return this.$message({
          message: '小主，请您先选择 EXCEL 文件！',
          type: 'warning',
          showClose: true
        })
      }

      // const apiEndpoint = 'http://localhost:8088/student/excel/upload' // 后端接口 URL

      // let oldData = JSON.parse(window.localStorage.getItem('excel') || '[]')
      let newData = [...this.excelData]
      window.localStorage.setItem('excel', JSON.stringify(newData))
      let newData2 = JSON.stringify(newData)
      // console.log(newData2);
      // return;
      // 发送 POST 请求
      let params = new URLSearchParams();
      params.append('newData',newData2);
      excelUpload(params)
        .then((res) => {
          if (res.code == 1) {
            // console.log(res.data);
            // return;
            this.message("采集成功！", "success");
          }
        })
        .catch (error => {})
    }

  }
};
</script>

<style scoped>
.student-img {
  border-radius: 5px;
  width: 100%;
  height: 80px;
  margin-bottom: 5px;
  overflow: hidden;
}

.handle-box {
  margin-bottom: 10px;
}

.handle-input {
  float: right;
  width: 300px;
  display: inline-block;
}

.pageination {
  margin-top: 10px;
  display: flex;
  justify-content: center;
}

.listj-import {
  float: right;
}

.buttonBox {
  width: 400px;
}
</style>
