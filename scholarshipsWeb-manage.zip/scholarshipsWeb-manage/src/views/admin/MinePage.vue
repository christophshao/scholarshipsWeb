<template>
    <div class="container">
        <el-card style="width:600px">
            <el-form :model="showForm" ref="showForm" label-width="80px" size="small">
                <div style="text-align: center; margin:10px 0;">
                    <el-upload
                    class="avatar-uploader"
                    :action="uploadUrl(showForm.id)"
                    :on-success= "handleAvatorSuccess">
                        <img v-if="showForm.photo" :src="getUrl(showForm.photo)" class="avatar">
                        <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                    </el-upload>
                </div>
                <el-form-item label="角色">
                    <el-select v-model="showForm.role" disabled>
                      <el-option label="管理员" value="0"></el-option>
                      <el-option label="学生" value="3"></el-option>
                      <el-option label="辅导员" value="2"></el-option>
                      <el-option label="教务处" value="1"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="用户名">
                    <el-input v-model="showForm.username" disabled></el-input>
                </el-form-item>
            </el-form>
            <div class="footer">
                <el-button type="primary" size="small"  @click="editDialogVisible = true" >修改密码</el-button>
            </div>
        </el-card>
        
        <!-- 修改密码弹窗 -->
        <el-dialog title="修改密码" :visible.sync="editDialogVisible" width="450px" center>
            <el-form :model="editForm" ref="editForm" label-width="80px" :rules="rules">
                <el-form-item prop="password" label="密码" size="mini">
                    <el-input v-model="editForm.password" placeholder="请输入密码" type="password"></el-input>
                </el-form-item>
                <el-form-item prop="passwordAgain" label="确认密码" size="mini">
                    <el-input v-model="editForm.passwordAgain" placeholder="请再次输入密码" type="password"></el-input>
                </el-form-item>
            </el-form>
        <span slot="footer">
          <el-button  @click="editSave" size="mini">确定</el-button>
          <el-button  @click="editDialogVisible = false" size="mini">取消</el-button>
        </span>
        </el-dialog>
        
    </div>
</template>

<script>
    import { mixin } from "@/mixins/index";
    import {getAdminUser,updateMine} from "@/api/index.js"
    export default {
        mixins: [mixin],
        data() {
            return{
                editDialogVisible:false,//修改弹窗
                showForm:{
                    role: '',
                    username: '',
                },
                // tableData: [],  //用于存储查询到的用户信息，一开始默认为空
                //修改框
                editForm:{   
                    id:'',
                    password:'',
                    passwordAgain:'',
                    
                },
                //校验规则
                rules:{
                    password:[
                        {required: true,message:'请输入密码',trigger:'blur'}
                    ],
                    passwordAgain:[
                        {required: true, message:'请输入再次输入密码', trigger: 'blur'}
                    ],
                    
                },
            };
            
        },
        // 创建页面的时候执行
        created(){
            // this.getData();
            // console.log(this.showForm.role);
            if(!localStorage.getItem('userName') || localStorage.getItem('role') != '0'){
                this.$router.push("/");
                this.message("请您先登录","warning");
            }else{
                this.getData();
            }
            
        },
        methods: {
            //查询
            getData(){
                this.tableData = []; //一开始清空tableData 防止之前有残留数据
                let params = new URLSearchParams();
                params.append('username',localStorage.getItem('userName'));
                getAdminUser(params)
                .then((res) =>{
                    // console.log(res);
                    // this.tableData = res.data;
                    this.showForm = res;
                });
            },
            // 编辑保存
            editSave(){
                if(this.editForm.password != this.editForm.passwordAgain){
                    this.message("两次密码输入不一致！","error");
                    return;
                }else{
                    this.$refs['editForm'].validate(valid =>{
                        if(valid){
                            //接收保存往后台传递的参数,
                            let params = new URLSearchParams();
                            params.append('id',this.showForm.id);
                            params.append('password',this.editForm.password);
                            params.append('passwordAgain',this.editForm.passwordAgain);
                            updateMine(params)
                            .then((res) =>{
                                if(res.code == 1){
                                    this.getData();
                                    this.editDialogVisible = false;
                                    this.message("修改成功,请重新登录！","success");
                                    this.$router.push("/");
                                }else{
                                    this.message("修改失败!","error");
                                }
                            })
                            .catch(err =>{
                                console.log(err);
                            });
                            this.editVisible = false;
                        }
                    })
                    }
            },
            // 更新照片
            uploadUrl(id){
                return `${this.$store.state.HOST}/admin/updateAdminPic?id=${id}`
            },
        }
    }
</script>

<style scoped>

    .footer{
        margin: auto;
        text-align: center;
        margin-top: 20px;
    }
    .avatar-uploader .el-upload {
        border: 1px dashed #d9d9d9;
        border-radius: 6px;
        cursor: pointer;
        position: relative;
        overflow: hidden;
        
    }
    .avatar-uploader .el-upload:hover {
        border-color: #409EFF;
    }
    .avatar-uploader-icon {
        font-size: 28px;
        color: #8c939d;
        width: 178px;
        height: 178px;
        line-height: 178px;
        text-align: center;
    }
    .avatar {
        width: 178px;
        height: 178px;
        display: block;
    }
</style>