<template>
  <div>
    <el-row :gutter="20" class="mgb20">
      <el-col :span="6">
        <el-card>
          <div class="grid-content">
            <div class="grid-cont-center">
              <div class="grid-num">{{studentsCount}}</div>
              <div>学生总数</div>
            </div>
          </div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card>
          <div class="grid-content">
            <div class="grid-cont-center">
              <div class="grid-num">{{jiangApplyCount}}</div>
              <div>奖学金申请数量</div>
            </div>
          </div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card>
          <div class="grid-content">
            <div class="grid-cont-center">
              <div class="grid-num">{{zhuApplyCount}}</div>
              <div>助学金申请数量</div>
            </div>
          </div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card>
          <div class="grid-content">
            <div class="grid-cont-center">
              <div class="grid-num">{{poorStudentCount}}</div>
              <div>贫困生申请数量</div>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>
    <!-- hang1 -->
    <el-row :gutter="20" class="mgb20">
      <el-col :span="12">
        <el-card>
          <h3 style="margin-bottom: 20px; margin-top: 10px; text-align:center">学生院系分布</h3>
          <div style="background-color: #fff">
            <ve-pie :data="studentsClassName" :theme="option"></ve-pie>
            <div ref="studentsClassName" :data="studentsClassName" ></div>
          </div>
        </el-card>
      </el-col>
      <el-col :span="12" >
        <el-card>
          <h3 style="margin-bottom: 20px; margin-top: 10px; text-align:center">各类奖学金申请数量</h3>
          <div style="background-color: #fff">
            <ve-histogram :data="jiangxuejinLevel"></ve-histogram>
          </div>
        </el-card>
      </el-col>
    </el-row>
    <!-- hang2 -->
    <el-row :gutter="20" class="mgb20" style="margin-top:20px">
      <el-col :span="12">
        <el-card>
          <h3 style="margin-bottom: 20px; margin-top: 10px; text-align:center">贫困生类别申请统计</h3>
          <div style="background-color: #fff">
            <ve-pie :data="poorStudentType" :theme="option1"></ve-pie>
            <div ref="poorStudentType" :data="poorStudentType" ></div>
          </div>
        </el-card>
      </el-col>
      <el-col :span="12" >
        <el-card>
          <h3 style="margin-bottom: 20px; margin-top: 10px; text-align:center">各类助学金申请数量</h3>
          <div style="background-color: #fff">
            <ve-histogram :data="zhuxuejinLevel" :theme="option2"></ve-histogram>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- <el-row :gutter="20" class="mgb20" style="margin-top:20px">
      <el-col :span="24">
        <el-card>
          <h3 style="margin-bottom: 10px; margin-top: 10px">歌单风格统计</h3>
          <div style="background-color: #fff">
            <ve-line :data="songStyle" :theme="option3"></ve-line>
          </div>
        </el-card>
      </el-col>
      
    </el-row> -->

  </div>
</template>
 <script>
import {getAllStudent,getAllJiangXueJinApply,getAllZhuXueJinApply,getAllPoorStudent} from "@/api/index";
export default {
  data() {
    return {
        studentsCount: 0, //用户总数
        jiangApplyCount:0,
        zhuApplyCount:0,
        poorStudentCount:0,
        
        students: [], //通过后端拿道的是一个数组，这里定义成students[]
        jiangxuejin:[],
        zhuxuejin:[],
        poorstudent:[],
        
        // 图标样式
        option: {
            color: ["#87cefa", "#ffc0cb","#ee6666","#ffdc60","#95d378"],
        },
        option1:{
            color:["#40b27d","#5470c6"],
        },
        option2:{
            color:["#fc8452"],
        },
        
        //按所属学院分类的学生数
        studentsClassName: {
            columns: ["学院", "总数"],
            rows: [
                { 学院: "数工学院", 总数: 0 },
                { 学院: "人文学院", 总数: 0 },
                { 学院: "计算机学院", 总数: 0 },
                { 学院: "经贸学院", 总数: 0 },
                { 学院: "艺术学院", 总数: 0 },
            ],
        },


        // 各个类别的奖学金申请人数
        jiangxuejinLevel: {
            columns: ["类别", "总数"],
            rows: [
            { 类别: "一等奖学金", 总数: 0 },
            { 类别: "二等奖学金", 总数: 0 },
            { 类别: "三等奖学金", 总数: 0 },
            { 类别: "省政府奖学金", 总数: 0 },
            { 类别: "国家奖学金", 总数: 0 },
            { 类别: "校长奖学金", 总数: 0 },
            ],
        },

        // 贫困生不同类别申请人数
        poorStudentType: {
            columns: ["类别", "总数"],
            rows: [
            { 类别: "一般贫困", 总数: 0 },
            { 类别: "特别贫困", 总数: 0 },
            ],
        },

        // 各个类别的奖学金申请人数
        zhuxuejinLevel: {
            columns: ["类别", "总数"],
            rows: [
            { 类别: "一等助学金", 总数: 0 },
            { 类别: "二等助学金", 总数: 0 },
            { 类别: "国家励志奖学金", 总数: 0 },
            ],
        },

      
      
    };
  },
  created() {

  },
  mounted() {
    this.getStudent();
    this.getJiangXueJin();
    this.getZhuXueJin();
    this.getPoorStudent();
  },

  methods: {
      //学生总数
      getStudent() {
        getAllStudent().then((res) => {
          this.students = res;
          this.studentsCount = res.length;
          //   拿道studentsclassname数组中第一个元素的["总数"]这个元素，然后把setclassname中1和students这个传过去
          this.studentsClassName.rows[0]["总数"] = this.setClassName(1, this.students);
          this.studentsClassName.rows[1]["总数"] = this.setClassName(2, this.students);
          this.studentsClassName.rows[2]["总数"] = this.setClassName(3, this.students);
          this.studentsClassName.rows[3]["总数"] = this.setClassName(4, this.students);
          this.studentsClassName.rows[4]["总数"] = this.setClassName(5, this.students);
        });
      },
      //根据所属学院获取学生数
      setClassName(className, student) {
        let count = 0;
        for (let item of student) {
          if (className == item.className) {
            count++;
          }
        }
        return count;
      },
//--------------------------------------
      // 奖学金申请总数   
      getJiangXueJin() {
        getAllJiangXueJinApply().then((res) => {
          this.jiangxuejin = res;
          this.jiangApplyCount = res.length;
          this.jiangxuejinLevel.rows[0]["总数"] = this.setJiangXueJinType(1, this.jiangxuejin);
          this.jiangxuejinLevel.rows[1]["总数"] = this.setJiangXueJinType(2, this.jiangxuejin);
          this.jiangxuejinLevel.rows[2]["总数"] = this.setJiangXueJinType(14, this.jiangxuejin);
          this.jiangxuejinLevel.rows[3]["总数"] = this.setJiangXueJinType(15, this.jiangxuejin);
          this.jiangxuejinLevel.rows[4]["总数"] = this.setJiangXueJinType(16, this.jiangxuejin);
          this.jiangxuejinLevel.rows[5]["总数"] = this.setJiangXueJinType(17, this.jiangxuejin);
        });
      },
      //根据奖学金类别获取对应申请的学生数
      setJiangXueJinType(jxjLevel, jiangxuejin) {
        let count = 0;
        for (let item of jiangxuejin) {
          if (jxjLevel == item.jxjLevel) {
            count++;
          }
        }
        return count;
      },
      
//--------------------------------------------------------------
      // 助学金申请总数   
      getZhuXueJin(){
        getAllZhuXueJinApply().then((res) => {
          this.zhuxuejin = res;
          this.zhuApplyCount = res.length;
          this.zhuxuejinLevel.rows[0]["总数"] = this.setZhuXueJinType(1, this.zhuxuejin);
          this.zhuxuejinLevel.rows[1]["总数"] = this.setZhuXueJinType(2, this.zhuxuejin);
          this.zhuxuejinLevel.rows[2]["总数"] = this.setZhuXueJinType(17, this.zhuxuejin);
        });
      },
      //根据奖学金类别获取对应申请的学生数
      setZhuXueJinType(zxjLevel, zhuxuejin) {
        let count = 0;
        for (let item of zhuxuejin) {
          if (zxjLevel == item.zxjLevel) {
            count++;
          }
        }
        return count;
      },
     

//----------------------------------------------------------------
      // 贫困生申请总数   
      getPoorStudent() {
        getAllPoorStudent().then((res) => {
          this.poorstudent = res;
          this.poorStudentCount = res.length;
          this.poorStudentType.rows[0]["总数"] = this.setPoorStudentType(1, this.poorstudent);
          this.poorStudentType.rows[1]["总数"] = this.setPoorStudentType(2, this.poorstudent);
        });
      },
      //根据贫困类别获取贫困学生数
      setPoorStudentType(poorType, poorstudent) {
        let count = 0;
        for (let item of poorstudent) {
          if (poorType == item.poorType) {
            count++;
          }
        }
        return count;
      },
      
  },
};
</script>


<style>
.grid-content {
  display: flex;
  align-items: center;
  height: 50px;
  background: #fff;
}
.grid-cont-center {
  flex: 1;
  text-align: center;
  font-size: 14px;
  color: darkgray;
}
.grid-num {
  font-size: 30px;
  font-weight: bold;
}
</style>

