<template>
    <div class="container">
        <el-card style="width:600px">
            <el-form :model="showForm" ref="showForm" label-width="80px" :rules="rules">
                <div style="text-align: center; margin:10px 0;">
                        <img src="@/assets/img/default.png" class="avatar">
                </div>
                <el-form-item label="角色">
                    <el-select v-model="showForm.role" disabled>
                      <el-option label="管理员" value="0"></el-option>
                      <el-option label="学生" value="3"></el-option>
                      <el-option label="辅导员" value="2"></el-option>
                      <el-option label="教务处" value="1"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item prop="number" label="教务处工号" size="mini">
                    <el-input v-model="showForm.number" placeholder="学号" disabled></el-input>
                </el-form-item>
                <el-form-item prop="username" label="用户名" size="mini">
                    <el-input v-model="showForm.username" placeholder="用户名" disabled></el-input>
                </el-form-item> 
                <el-form-item prop="name" label="名称" size="mini">
                    <el-input v-model="showForm.name" placeholder="学生姓名"></el-input>
                </el-form-item>
                <el-form-item prop="phone" label="联系电话" size="mini" >
                    <el-input v-model="showForm.phone" placeholder="联系电话"></el-input>
                </el-form-item>
                <el-form-item prop="email" label="电子邮箱" size="mini">
                    <el-input v-model="showForm.email" placeholder="电子邮箱"></el-input>
                </el-form-item>
            </el-form>
            <div class="footer">
                <el-button type="primary" size="small"  @click="editUser" >修改信息</el-button>
                <el-button type="primary" size="small"  @click="editDialogVisible = true" >修改密码</el-button>
            </div>
        </el-card>
        
        <!-- 修改密码弹窗 -->
        <el-dialog title="修改密码" :visible.sync="editDialogVisible" width="450px" center>
            <el-form :model="editForm" ref="editForm" label-width="80px" :rules="rules">
                <el-form-item prop="password" label="密码" size="mini">
                    <el-input v-model="editForm.password" placeholder="请输入密码" type="password"></el-input>
                </el-form-item>
                <el-form-item prop="passwordAgain" label="确认密码" size="mini">
                    <el-input v-model="editForm.passwordAgain" placeholder="请再次输入密码" type="password"></el-input>
                </el-form-item>
            </el-form>
        <span slot="footer">
          <el-button  @click="editSave" size="mini">确定</el-button>
          <el-button  @click="editDialogVisible = false" size="mini">取消</el-button>
        </span>
        </el-dialog>
        
    </div>
</template>

<script>
    import { mixin } from "@/mixins/index";
    import {getOfficeUser,updateOffice,updateOfficePassword} from "@/api/index.js"
    export default {
        mixins: [mixin],
        data() {
            return{
                editDialogVisible:false,//修改弹窗
                //修改信息框
                showForm:{   
                    id:'',
                    role: '',
                    username: '',
                    number:'',
                    name:'',
                    phone:'',
                    email:'',
                    
                },
                // 修改密码框
                editForm:{
                    id:'',
                    password:'',
                    passwordAgain:''
                },
                //校验规则
                rules:{
                    email:[
                        {type:'email',message:'请输入正确的电子邮箱地址',trigger:['blur','change']}
                    ],
                    name:[
                        {required: true,message:'请输入教务处名称',trigger:'blur'},
                    ],
                    phone:[
                        {required: true,message:'请输入联系电话',trigger:'blur'},
                    ],
                    password:[
                        {required: true,message:'请输入密码',trigger:'blur'}
                    ],
                    passwordAgain:[
                        {required: true, message:'请输入再次输入密码', trigger: 'blur'}
                    ],
                    
                },
            };
            
        },
        // 创建页面的时候执行
        created(){
            if(!localStorage.getItem('userName') || localStorage.getItem('role') != '1'){
                this.$router.push("/");
                this.message("请您先登录","warning");
            }else{
                this.getData();
            }
            
        },
        methods: {
            //查询
            getData(){
                let params = new URLSearchParams();
                params.append('username',localStorage.getItem('userName'));
                getOfficeUser(params)
                .then((res) =>{
                    this.showForm = res;
                });
            },
            // 修改密码
            editSave(){
                if(this.editForm.password != this.editForm.passwordAgain){
                    this.message("两次密码输入不一致！","warning");
                    return;
                }else{
                    this.$refs['editForm'].validate(valid =>{
                        if(valid){
                            //接收保存往后台传递的参数,
                            let params = new URLSearchParams();
                            params.append('id',this.showForm.id);
                            params.append('password',this.editForm.password);
                            params.append('passwordAgain',this.editForm.passwordAgain);
                            updateOfficePassword(params)
                            .then((res) =>{
                                if(res.code == 1){
                                    this.getData();
                                    this.editDialogVisible = false;
                                    this.message("修改成功,请重新登录！","success");
                                    this.$router.push("/");
                                }else{
                                    this.message("修改失败!","error");
                                }
                            })
                            .catch(err =>{
                                console.log(err);
                            });
                            this.editVisible = false;
                        }
                    })
                    }
            },
            // 编辑保存
            editUser(){
                this.$refs['showForm'].validate(valid =>{
                    if(valid){
                        let d = new Date(this.showForm.birth);
                        let datetime = d.getFullYear() + '-' + (d.getMonth()+1) + '-' + d.getDate();
                        //接收保存往后台传递的参数,
                        let params = new URLSearchParams();
                        params.append('id',this.showForm.id);
                        params.append('username',this.showForm.username);
                        params.append('password',this.showForm.password);
                        params.append('number',this.showForm.number);
                        params.append('name',this.showForm.name);
                        params.append('phone',this.showForm.phone);
                        params.append('email',this.showForm.email);

                        updateOffice(params)
                        .then((res) =>{
                            if(res.code == 1){
                                this.getData();
                                this.message("修改成功！","success");
                            }else{
                                this.message("修改失败!","error");
                            }
                        })
                        .catch(err =>{
                            console.log(err);
                        });
                        this.editVisible = false;
                    }
                })
            },
        }
    }
</script>

<style scoped>

    .footer{
        margin: auto;
        text-align: center;
        margin-top: 20px;
    }
    .avatar{
        margin: auto;
    }
    .avatar-uploader .el-upload {
        border: 1px dashed #d9d9d9;
        border-radius: 6px;
        cursor: pointer;
        position: relative;
        overflow: hidden;
        
    }
    .avatar-uploader .el-upload:hover {
        border-color: #409EFF;
    }
    .avatar-uploader-icon {
        font-size: 28px;
        color: #8c939d;
        width: 178px;
        height: 178px;
        line-height: 178px;
        text-align: center;
    }
    .avatar {
        width: 178px;
        height: 178px;
        display: block;
    }
</style>