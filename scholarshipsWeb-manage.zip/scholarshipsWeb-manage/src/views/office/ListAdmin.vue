<template>
    <div class="table">
        <!-- 功能区域 -->
        <div class="container">
            <div class="handle-box">
                <div class="options">
                    <el-select v-model="value" placeholder="请选择" size="small" @change="getListByOption">
                        <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value">
                        </el-option>
                    </el-select>
                </div>
                <!-- Export Excel -->
                <el-button type="primary" size="small" @click="exportExcel">导出Excel</el-button>
                <!-- 查询 -->
                <el-input v-model="select_word" placeholder="请输入学生姓名..." class="handle-input" size="small">
                </el-input>
            </div>
        </div>

        <!-- 查询表格 -->
        <el-table size="mini" border style="width:100%" height="510px" :data="data"
            @selection-change="handleSelectionChange">
            <el-table-column label="序号">
                <template slot-scope="scope">
                    {{ scope.$index + 1 }}
                </template>
            </el-table-column>
            <el-table-column label="学生学号" prop="number"></el-table-column>
            <el-table-column label="学生姓名" prop="name"></el-table-column>
            <el-table-column label="学院" width="120">
                <template slot-scope="scope">
                    {{ getClassName(scope.row.className) }}
                </template>
            </el-table-column>
            <el-table-column label="总成绩" prop="grade"></el-table-column>
            <el-table-column label="贫困类型" v-if="value === 'zhuxuejin_apply' || value === 'poor_student'">
                <template slot-scope="scope">
                    {{ getPoorType(scope.row.poorType) }}
                </template>
            </el-table-column>
            <el-table-column label="助学金" v-if="value === 'zhuxuejin_apply'">
                <template slot-scope="scope">
                    {{ scope.row.type }}
                </template>
            </el-table-column>
            <el-table-column label="奖学金" v-if="value === 'jiangxuejin_apply'">
                <template slot-scope="scope">
                    {{ scope.row.type }}
                </template>
            </el-table-column>
        </el-table>

        <!-- 分页 -->
        <div class="pageination">
            <el-pagination background layout="total,prev,pager,next" :total="tableData.length" :current-page="currentPage"
                :page-size="pageSize" @current-change="handleCurrentChange">
            </el-pagination>
        </div>

    </div>
</template>

<script>
import { mixin } from "@/mixins/index.js";
import { getAllBulletin, getAllListByOption } from "@/api/index.js"
import XLSX from 'xlsx'

export default {
    mixins: [mixin],
    data() {
        return {
            // 默认为false 当单击事件后变为true 就会显示弹窗
            deleteVisible: false, //删除弹窗

            // 选项框
            options: [{
                value: 'poor_student',
                label: '贫困生名单'
            }, {
                value: 'zhuxuejin_apply',
                label: '助学金名单'
            }, {
                value: 'jiangxuejin_apply',
                label: '奖学金名单'
            },],
            value: 'poor_student',


            tableData: [],  //用于存储查询到的用户信息，一开始默认为空
            tempData: [],
            select_word: '',
            index: -1,   //选择当前项
            multipleSelection: [],   //确定多选项数量
            pageSize: 3, //一张页面展示多少数据
            currentPage: 1, //当前页
            index: 0,

            //校验规则
            rules: {
                title: [
                    { required: true, message: '请输入查询学生名', trigger: 'blur' }
                ],
            },
        };
    },
    // 计算当前搜索结果表中的数据
    computed: {
        data() {
            return this.tableData.slice((this.currentPage - 1) * this.pageSize, this.currentPage * this.pageSize);
        }
    },
    // 搜索框发生变化的时候，table中的内容同步变化
    watch: {
        select_word: function () {
            if (this.select_word == '') {
                this.tableData = this.tempData;
            } else {
                this.tableData = [];
                for (let item of this.tempData) {
                    if (item.title.includes(this.select_word)) {
                        this.tableData.push(item);
                    }
                }
            }
        }
    },
    // 创建页面的时候执行
    created() {
        // this.getData();
        this.getListByOption();
    },
    methods: {

        // 查询名单 根据 选项条件
        getListByOption() {
            const params = {
                option: this.value
            };
            return getAllListByOption(params)
                .then(res => {
                    this.tempData = res;
                    this.tableData = res;
                    this.currentPage = 1;
                })
                .catch(error => {
                    console.error('Something went wrong:', error);
                });
        },

        //导出为 Excel文件
        exportExcel() {
            if (this.value === 'poor_student') {
                const headerMap = {
                    'id': '编号',
                    'number': '学号',
                    'name': '姓名',
                    'className': '学院',
                    'grade': '总成绩',
                    'poorType': '贫困类型',
                }

                let counter = 1;
                const data = this.tableData.map(item => {
                    const row = {}
                    for (let key in item) {
                        if (key === 'id') {
                            row[headerMap[key]] = counter++;
                        } else if (key === 'className') {
                            row[headerMap[key]] = this.getClassName(item[key])
                        } else if (key === 'poorType') {
                            row[headerMap[key]] = this.getPoorType(item[key])
                        } else {
                            row[headerMap[key]] = item[key]
                        }
                    }
                    return row
                })

                const worksheet = XLSX.utils.json_to_sheet(data)
                const workbook = XLSX.utils.book_new()
                XLSX.utils.book_append_sheet(workbook, worksheet, 'Sheet1')
                XLSX.writeFile(workbook, 'table.xlsx')
            } else if(this.value === 'zhuxuejin_apply') {
                const headerMap = {
                    'id': '编号',
                    'number': '学号',
                    'name': '姓名',
                    'className': '学院',
                    'grade': '总成绩',
                    'poorType': '贫困类型',
                    'type': '助学金',
                }

                let counter = 1;
                const data = this.tableData.map(item => {
                    const row = {}
                    for (let key in item) {
                        // console.log(item);
                        // return;
                        if (key === 'id') {
                            row[headerMap[key]] = counter++;
                        } else if (key === 'className') {
                            row[headerMap[key]] = this.getClassName(item[key])
                        } else if (key === 'poorType') {
                            row[headerMap[key]] = this.getPoorType(item[key])
                        } else if (key == 'zxj_Level') {
                            continue
                        }else {
                            row[headerMap[key]] = item[key]
                        }
                    }
                    return row
                })

                const worksheet = XLSX.utils.json_to_sheet(data)
                const workbook = XLSX.utils.book_new()
                XLSX.utils.book_append_sheet(workbook, worksheet, 'Sheet1')
                XLSX.writeFile(workbook, 'table.xlsx')
            } else {
                const headerMap = {
                    'id': '编号',
                    'number': '学号',
                    'name': '姓名',
                    'className': '班级',
                    'grade': '成绩',
                    'type': '奖学金',
                    'zxjLevel':'助学金',
                }

                let counter = 1;
                const data = this.tableData.map(item => {
                    const row = {}
                    for (let key in item) {
                        if (key === 'id') {
                            row[headerMap[key]] = counter++;
                        } else if (key === 'className') {
                            row[headerMap[key]] = this.getClassName(item[key])
                        } else if (key === 'zxjLevel') {
                            continue
                        }else {
                            row[headerMap[key]] = item[key]
                        }
                    }
                    return row
                })

                const worksheet = XLSX.utils.json_to_sheet(data)
                const workbook = XLSX.utils.book_new()
                XLSX.utils.book_append_sheet(workbook, worksheet, 'Sheet1')
                XLSX.writeFile(workbook, 'table.xlsx')
            }


        },




        // 获取当前页
        handleCurrentChange(val) {
            this.currentPage = val;
        },
    },



}
</script>


<style scoped>
.handle-box {
    margin-bottom: 10px;
}

.handle-input {
    float: right;
    width: 300px;
    display: inline-block;
}

.pageination {
    margin-top: 10px;
    display: flex;
    justify-content: center;
}

.options {
    width: 200px;
    float: left;
    margin-right: 10px;
}
</style>
