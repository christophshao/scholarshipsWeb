<template>
  <div class="login-wrap">
    <div class="lg-title">高校奖助学金管理系统</div>
    <div class="lg-login">
      <el-form :model="loginForm" :rules="rules" ref="loginForm">
        <el-form-item prop="username">
          <el-input v-model="loginForm.username" placeholder="请输入账号..."></el-input>
        </el-form-item>
        <el-form-item prop="password">
          <el-input type="password" v-model="loginForm.password" placeholder="请输入密码..."></el-input>
        </el-form-item>

        <el-form-item label="选择角色" prop="role">
            <input type="radio" name="role" value="0" v-model="loginForm.role"/>&nbsp;管理员&nbsp;&nbsp;
            <input type="radio" name="role" value="3" v-model="loginForm.role"/>&nbsp;学生&nbsp;&nbsp;
            <input type="radio" name="role" value="2" v-model="loginForm.role"/>&nbsp;辅导员&nbsp;&nbsp;
            <input type="radio" name="role" value="1" v-model="loginForm.role"/>&nbsp;教务处
        </el-form-item>

        <div class="lg-btn">
          <el-button type="primary" @click="adminLogin()">登录</el-button>
        </div>
      </el-form>
    </div>
  </div>
</template>


<script>
import {mixin} from "../mixins/index";
import {getLoginStatus,getTeacherLoginStatus,getStudentLoginStatus,getOfficeLoginStatus} from "../api/index";

export default {
  mixins:[mixin],
  data() {
    return {
      loginForm: {
        username: '',
        password: '',
        role: '0',
      },
      rules: {
        username: [{ required: true, message: "请输入账号", trigger: "blur" }],
        password: [{ required: true, message: "请输入密码", trigger: "blur" }],
      },
    };
  },
  // 这个方法代表，页面加载后执行
  mounted() {

  },
  methods: {
    adminLogin() {
      let params = new URLSearchParams();
      let shenfen = this.loginForm.role;
      params.append("username",this.loginForm.username);
      params.append("password",this.loginForm.password);
      params.append("role",shenfen);
      
      if(shenfen == '0'){
          getLoginStatus(params)
          // 这里先通过上面getLoginStatus方法 到后端判断完数据是否正确后，再回来前端执行下面操作
          .then((res) =>{
            if(res.code == 1){
                localStorage.setItem('role',shenfen); //存权限角色
                localStorage.setItem('userName',this.loginForm.username); //h5的功能能把用户名保存起来
                this.message("管理员“"+this.loginForm.username + "”您好","success");  //$message组件弹窗
                this.$router.push("/admin/Info");
            }else{
                this.message("登录失败！","error");
            }
          });
      }else if(shenfen == '3'){
          getStudentLoginStatus(params)
          // 这里先通过上面getLoginStatus方法 到后端判断完数据是否正确后，再回来前端执行下面操作
          .then((res) =>{
            if(res.code == 1){
              localStorage.setItem('role',shenfen); //存权限角色
              localStorage.setItem('userName',this.loginForm.username); //h5的功能能把用户名保存起来
                this.message("学生“" + this.loginForm.username + "”您好","success");  //$message组件弹窗
                this.$router.push("/student/Mine");
            }else{
                this.message("学生用户名或密码错误！","error");
            }
          });
      }else if(shenfen == '2'){
        getTeacherLoginStatus(params)
          // 这里先通过上面getLoginStatus方法 到后端判断完数据是否正确后，再回来前端执行下面操作
          .then((res) =>{
            if(res.code == 1){
              localStorage.setItem('role',shenfen); //存权限角色
              localStorage.setItem('userName',this.loginForm.username); //h5的功能能把用户名保存起来
                this.message("辅导员“" + this.loginForm.username + "”您好","success");  //$message组件弹窗
                this.$router.push("/teacher/Info");
            }else{
                this.message("辅导员用户名或密码错误！！","error");
            }
          });
      }else if(shenfen == '1'){
        getOfficeLoginStatus(params)
          // 这里先通过上面getLoginStatus方法 到后端判断完数据是否正确后，再回来前端执行下面操作
          .then((res) =>{
            if(res.code == 1){
              localStorage.setItem('role',shenfen); //存权限角色
              localStorage.setItem('userName',this.loginForm.username); //h5的功能能把用户名保存起来
                this.message("教务处“" + this.loginForm.username + "”您好","success");  //$message组件弹窗
                this.$router.push("/office/Info");
            }else{
                this.message("教务处用户名或密码错误！！","error");
            }
          });
      }else{
          this.message("暂未开放！","warning");  //$message组件弹窗
          this.$router.push("/");
      }

    },
  },
};
</script>

<style scoped>
.login-wrap {
  position: relative;
  width: 100%;
  height: 100%;
  background: url("../assets/img/background.jpg");
  background-size: cover;
}
.lg-title {
  position: absolute;
  top: 20%;
  width: 100%;
  text-align: center;
  color: #fff;
  font-size: 30px;
}
.lg-login {
  position: absolute;
  top: 20%;
  left: 33%;
  margin-top: 70px;
  border: 1px solid #fff;
  width: 520px;
  height: 280px;
  background: #fff;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
  border-radius: 5px;
  padding: 40px;
}
.lg-btn {
}
.lg-btn button {
  height: 36px;
  width: 100%;
}
</style>

