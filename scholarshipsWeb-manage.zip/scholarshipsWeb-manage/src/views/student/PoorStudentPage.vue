<template>
  <div class="table">
    <!-- 功能区域 -->
    <div class="container">
      <div class="handle-box">
        <!-- 添加 -->
        <el-button type="primary" size="small" @click="handleAdd">
          贫困生申请
        </el-button>
      </div>
    </div>
    <!-- 申请-弹窗 -->
    <el-dialog title="申请贫困资格" :visible.sync="addDialogVisible" width="450px" center>
      <el-form :model="registerForm" ref="registerForm" label-width="80px" :rules="rules">
        <el-form-item prop="number" label="学号" size="mini">
          <el-input v-model="registerForm.number" placeholder="学号" disabled></el-input>
        </el-form-item>
        <el-form-item prop="name" label="学生姓名" size="mini">
          <el-input v-model="registerForm.name" placeholder="学生姓名" disabled></el-input>
        </el-form-item>
        <el-form-item prop="sex" label="性别" size="mini">
          <input type="radio" name="sex" value="1" v-model="registerForm.sex" disabled/>&nbsp;男&nbsp;&nbsp;
          <input type="radio" name="sex" value="2" v-model="registerForm.sex" disabled/>&nbsp;女
        </el-form-item>
        <el-form-item prop="address" label="家庭住址" size="mini">
          <el-input v-model="registerForm.address" placeholder="家庭住址"></el-input>
        </el-form-item>
        <el-form-item prop="startTime" label="申请日期" size="mini">
          <el-date-picker v-model="registerForm.startTime" placeholder="选择日期" type="date"
            style="width:100%" disabled></el-date-picker>
        </el-form-item>
        <el-form-item prop="familySize" label="家庭人口数" size="mini">
          <el-input v-model="registerForm.familySize" placeholder="家庭人口数"></el-input>
        </el-form-item>
        <el-form-item prop="familyIncome" label="年总收入" size="mini">
          <el-input v-model="registerForm.familyIncome" placeholder="年总收入"></el-input>
        </el-form-item>
        <el-form-item prop="annualIncome" label="人均年收入" size="mini">
          <el-input v-model="registerForm.annualIncome" placeholder="人均年收入"></el-input>
        </el-form-item>
        <el-form-item prop="incomeSource" label="收入来源" size="mini">
          <el-input v-model="registerForm.incomeSource" placeholder="收入来源"></el-input>
        </el-form-item>
        <el-form-item prop="poorType" label="贫困类型" size="mini">
          <el-select v-model="registerForm.poorType" placeholder="请选择">
            <el-option label="一般贫困" value="1" key="1"></el-option>
            <el-option label="特别贫困" value="2"></el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <span slot="footer">
        <el-button @click="insertSave" size="mini">确定</el-button>
        <el-button @click="addDialogVisible = false" size="mini">取消</el-button>
      </span>
    </el-dialog>

    <!-- 删除歌手-弹窗 -->
    <el-dialog title="删除学生" :visible.sync="deleteVisible" width="300px" center>
      <div style="text-align:center">删除不可恢复，是否确认删除</div>
      <span slot="footer">
        <el-button @click="deleteRow" size="mini">确定</el-button>
        <el-button @click="deleteVisible = false" size="mini">取消</el-button>
      </span>
    </el-dialog>

    <!-- 修改学生信息-弹窗 -->
    <el-dialog title="修改学生信息" :visible.sync="editVisible" width="450px" center>
      <el-form :model="editForm" ref="editForm" label-width="80px" :rules="rules">
        <el-form-item prop="number" label="学号" size="mini">
          <el-input v-model="editForm.number" placeholder="学号" disabled></el-input>
        </el-form-item>
        <el-form-item prop="name" label="学生姓名" size="mini">
          <el-input v-model="editForm.name" placeholder="学生姓名" disabled></el-input>
        </el-form-item>
        <el-form-item prop="sex" label="性别" size="mini">
          <input type="radio" name="sex" value="1" v-model="editForm.sex" disabled/>&nbsp;男&nbsp;&nbsp;
          <input type="radio" name="sex" value="0" v-model="editForm.sex" disabled/>&nbsp;女
        </el-form-item>
        <el-form-item prop="address" label="住址" size="mini">
          <el-input v-model="editForm.address" placeholder="住址"></el-input>
        </el-form-item>
        <el-form-item prop="startTime" label="申请日期" size="mini">
          <el-date-picker v-model="editForm.startTime" placeholder="选择日期" type="date" style="width:100%"></el-date-picker>
        </el-form-item>
        <el-form-item prop="familySize" label="家庭人口数" size="mini">
          <el-input v-model="editForm.familySize" placeholder="民族"></el-input>
        </el-form-item>
        <el-form-item prop="familyIncome" label="年总收入" size="mini">
          <el-input v-model="editForm.familyIncome" placeholder="政治面貌"></el-input>
        </el-form-item>
        <el-form-item prop="annualIncome" label="人均年收入" size="mini">
          <el-input v-model="editForm.annualIncome" placeholder="籍贯"></el-input>
        </el-form-item>
        <el-form-item prop="incomeSource" label="收入来源" size="mini">
          <el-input v-model="editForm.incomeSource" placeholder="家庭住址"></el-input>
        </el-form-item>
        <el-form-item prop="poorType" label="贫困类型" size="mini">
          <el-select v-model="editForm.poorType" placeholder="请选择">
            <el-option label="一般贫困" value="1" key="1"></el-option>
            <el-option label="特别贫困" value="2"></el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <span slot="footer">
        <el-button @click="editSave" size="mini">确定</el-button>
        <el-button @click="editVisible = false" size="mini">取消</el-button>
      </span>
    </el-dialog>

    <!-- 根据登录username查询贫困学生-表格 -->
    <el-table size="small" border style="width:100%" height="510px" :data="tableData"
      @selection-change="handleSelectionChange">
      <el-table-column label="学号" prop="number" width="120" align="center"></el-table-column>
      <el-table-column label="姓名" prop="name" width="120" align="center"></el-table-column>
      <el-table-column label="GPA" prop="gpa" width="120" align="center"></el-table-column>
      <el-table-column label="性别" width="50" align="center">
        <template slot-scope="scope">
          {{ getSex(scope.row.sex) }}
        </template>
      </el-table-column>
      <el-table-column label="家庭住址" prop="address" width="120" align="center"></el-table-column>
      <el-table-column label="申请日期" width="120" align="center">
        <template slot-scope="scope">
          {{ attachBirth(scope.row.startTime) }}
        </template>
      </el-table-column>
      <el-table-column label="家庭人口数" prop="familySize" width="120" align="center"></el-table-column>
      <el-table-column label="家庭年总收入" prop="familyIncome" width="120" align="center"></el-table-column>
      <el-table-column label="年平均收入" prop="annualIncome" width="120" align="center"></el-table-column>
      <el-table-column label="贫困类型" width="120" align="center">
        <template slot-scope="scope">
          {{ getPoorType(scope.row.poorType) }}
        </template>
      </el-table-column>
      <el-table-column label="辅导员审核" width="120" align="center">
        <template slot-scope="scope">
          {{ getCheck(scope.row.teacherCheck) }}
        </template>
      </el-table-column>
      <el-table-column label="辅导员意见" align="center" width="120">
        <template slot-scope="scope">
          <p style="height:100px; overflow:hidden;line-height:100px">{{ scope.row.teacherOpinion }}</p>
        </template>
      </el-table-column>
      <el-table-column label="教务处审核" width="120" align="center">
        <template slot-scope="scope">
          {{ getCheck(scope.row.officeCheck) }}
        </template>
      </el-table-column>
      <el-table-column label="教务处意见" prop="officeOpinion" width="120" align="center">
        <template slot-scope="scope">
          <p style="height:100px; overflow:hidden;line-height:100px">{{ scope.row.officeOpinion }}</p>
        </template>
      </el-table-column>


      <el-table-column label="操作" align="center" width="180" fixed="right">
        <template slot-scope="scope">
          <el-button type="button" @click="handleEdit(scope.row)" size="small">编辑</el-button>
          <el-button type="danger" @click="handleDelete(scope.row.id)" size="small">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <!-- 分页 -->
    <div class="pageination">
      <el-pagination background layout="total,prev,pager,next" :total="tableData.length" :current-page="currentPage"
        :page-size="pageSize" @current-change="handleCurrentChange">
      </el-pagination>
    </div>

  </div>
</template>

<script>
import { mixin } from "@/mixins/index";
import {
  getAllPoorStudent, getPoorStudentByUsername,
  addPoorStudent, updatePoorStudent, deletePoorStudent, getStudentUser
} from "@/api/index"
export default {
  mixins: [mixin],
  data() {
    return {
      // 默认为false 当单击事件后变为true 就会显示弹窗
      addDialogVisible: false, //添加弹窗
      editVisible: false,  //修改弹窗
      deleteVisible: false, //删除弹窗

      //添加框
      registerForm: {
        number: '',
        name: '',
        sex: '',
        address: '',
        startTime: '',
        familySize: '',
        familyIncome: '',
        annualIncome: '',
        incomeSource: '',
        poorType: '',
      },
      //修改框
      editForm: {
        id: '',
        number: '',
        name: '',
        sex: '',
        address: '',
        startTime: '',
        familySize: '',
        familyIncome: '',
        incomeSource: '',
        poorType: '',

      },
      tableData: [],  //用于存储查询到的用户信息，一开始默认为空
      tempData: [],
      username: '',
      index: -1,   //选择当前项
      pageSize: 9, //一张页面展示多少数据
      currentPage: 1, //当前页
      nowDate: new Date(),// 获取当前日期

      //校验规则
      rules: {
        number: [
          { required: true, message: '请输入学号', trigger: 'blur' }
        ],
        name: [
          { required: true, message: '请输入姓名', trigger: 'blur' }
        ],
        sex: [
          { required: true, message: '请选择性别', trigger: 'blur' }
        ],
        address: [
          { required: true, message: '请输入住址', trigger: 'blur' }
        ],
        startTime: [
          { required: true, message: '请选择申请日期', trigger: 'blur' }
        ],
        familySize: [
          { required: true, message: '请输入家庭人口数', trigger: 'blur' }
        ],
        familyIncome: [
          { required: true, message: '请输入家庭收入情况', trigger: 'blur' }
        ],
        annualIncome: [
          { required: true, message: '请输入人均年收入', trigger: 'blur' }
        ],
        incomeSource: [
          { required: true, message: '请输入收入来源', trigger: 'blur' }
        ],
        poorType: [
          { required: true, message: '请输入贫困类型', trigger: 'blur' }
        ],
      },
    };
  },
  // 创建页面的时候执行
  created() {
    this.username = localStorage.getItem('userName');
    this.getData();

  },

  methods: {
    // 查询学生
    // getData(){
    //     this.tempData = [];
    //     this.tableData = []; //一开始清空tableData 防止之前有残留数据
    //     getAllPoorStudent().then((res) =>{
    //         this.tempData = res;
    //         this.tableData = res;
    //         this.currentPage = 1;
    //     })
    // },

    //查询学生 根据登录用户的username
    getData() {
      this.tempData = [];
      this.tableData = []; //一开始清空tableData 防止之前有残留数据
      // this.username = localStorage.getItem('userName');
      // 拿道username
      let params = new URLSearchParams();
      params.append('username', this.username);
      getPoorStudentByUsername(params)
        .then((res) => {
          this.tempData = res;
          this.tableData = res;
          this.currentPage = 1;
        })
        .catch((error) => {
          console.error(error);
        });

    },

    // 获取当前页
    handleCurrentChange(val) {
      this.currentPage = val;
    },
    // 弹出添加用户信息页面
    handleAdd() {
      this.addDialogVisible = true
      let params = new URLSearchParams();
      params.append('username', localStorage.getItem('userName'));
      getStudentUser(params)
        .then((res) => {
          this.registerForm = {
            name: res.name,
            number: res.number,
            sex: res.sex,
            startTime: this.nowDate,
          }
        });
    },
    // 申请贫困学生
    insertSave() {
      this.$refs['registerForm'].validate(valid => {
        if (valid) {
          let d = this.registerForm.startTime;
          let datetime = d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate();

          //接收保存往后台传递的参数,
          let params = new URLSearchParams();
          params.append('username', this.username);
          params.append('number', this.registerForm.number);
          params.append('name', this.registerForm.name);
          params.append('sex', this.registerForm.sex);
          params.append('address', this.registerForm.address);
          params.append('startTime', datetime);
          params.append('familySize', this.registerForm.familySize);
          params.append('familyIncome', this.registerForm.familyIncome);
          params.append('annualIncome', this.registerForm.annualIncome);
          params.append('incomeSource', this.registerForm.incomeSource);
          params.append('poorType', this.registerForm.poorType);
          addPoorStudent(params)
            .then((res) => {
              if (res.code == 1) {
                this.getData();
                this.message("添加成功！", "success");
                this.addDialogVisible = false;
              } else {
                this.message("添加失败!", "error");
              }
            })
            .catch(err => {
              console.log(err);
            });
          this.centerDialogVisible = false;
        }
      })
    },
    // 删除信息
    deleteRow() {
      deletePoorStudent(this.index)
        .then((res) => {
          if (res) {
            this.getData();
            this.message("删除成功！", "success");
          } else {
            this.message("删除失败!", "error");
          }
        })
      this.deleteVisible = false;
    },
    // 弹出编辑用户信息页面
    handleEdit(row) {
      this.editVisible = true;
      this.editForm = {
        id: row.id,
        number: row.number,
        name: row.name,
        sex: row.sex,
        address: row.address,
        startTime: row.startTime,
        familySize: row.familySize,
        familyIncome: row.familyIncome,
        annualIncome: row.annualIncome,
        incomeSource: row.incomeSource,
        poorType: row.poorType,
      }
    },
    // 编辑保存
    editSave() {
      this.$refs['editForm'].validate(valid => {
        if (valid) {
          let d = new Date(this.editForm.birth);
          let datetime = d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate();
          //接收保存往后台传递的参数,
          let params = new URLSearchParams();
          params.append('id', this.editForm.id);
          params.append('number', this.editForm.number);
          params.append('name', this.editForm.name);
          params.append('sex', this.editForm.sex);
          params.append('address', this.editForm.address);
          params.append('startTime', datetime);
          params.append('familySize', this.editForm.familySize);
          params.append('familyIncome', this.editForm.familyIncome);
          params.append('annualIncome', this.editForm.annualIncome);
          params.append('incomeSource', this.editForm.incomeSource);
          params.append('poorType', this.editForm.poorType);

          updatePoorStudent(params)
            .then((res) => {
              if (res.code == 1) {
                this.getData();
                this.message("修改成功！", "success");
              } else {
                this.message("修改失败!", "error");
              }
            })
            .catch(err => {
              console.log(err);
            });
          this.editVisible = false;
        }
      })
    },
  }
};
</script>

<style scoped>
.student-img {
  border-radius: 5px;
  width: 100%;
  height: 80px;
  margin-bottom: 5px;
  overflow: hidden;
}

.handle-box {
  margin-bottom: 10px;
}

.handle-input {
  float: right;
  width: 300px;
  display: inline-block;
}

.pageination {
  margin-top: 10px;
  display: flex;
  justify-content: center;
}</style>
