<template>
  <div class="table">
    <!-- 功能区域 -->
    <div class="container">
      <div class="handle-box">
        <!-- 添加 -->
        <el-button type="primary" size="small" @click="handleAdd">
          申请奖学金
        </el-button>
      </div>
    </div>
    <!-- 申请奖学金-弹窗 -->
    <el-dialog title="申请奖学金" :visible.sync="addDialogVisible" width="450px" center>
      <el-form :model="registerForm" ref="registerForm" label-width="80px" :rules="rules">
        <el-form-item prop="number" label="学号" size="mini">
          <el-input v-model="registerForm.number" placeholder="学号" disabled></el-input>
        </el-form-item>
        <el-form-item prop="name" label="姓名" size="mini">
          <el-input v-model="registerForm.name" placeholder="姓名" disabled></el-input>
        </el-form-item>
        <el-form-item prop="typeId" label="奖学金类型" size="mini">
          <el-select v-model="registerForm.typeId" placeholder="请选择">
            <el-option v-for="item in TypeData" :key="item.id" :label="item.type" :value="item.id"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item prop="address" label="家庭住址" size="mini">
          <el-input v-model="registerForm.address" placeholder="家庭住址" type="textarea"></el-input>
        </el-form-item>
        <el-form-item prop="className" label="所属学院" size="mini">
          <el-select v-model="registerForm.className" placeholder="请选择" disabled>
            <el-option label="数工学院" value="1" key="1"></el-option>
            <el-option label="人文学院" value="2"></el-option>
            <el-option label="计算机学院" value="3"></el-option>
            <el-option label="经贸学院" value="4"></el-option>
            <el-option label="艺术学院" value="5"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item prop="applyTime" label="申请日期" size="mini">
          <el-date-picker v-model="registerForm.applyTime" placeholder="选择日期" type="date"
            style="width:100%" disabled></el-date-picker>
        </el-form-item>
      </el-form>
      <span slot="footer">
        <el-button @click="insertSave" size="mini">确定</el-button>
        <el-button @click="addDialogVisible = false" size="mini">取消</el-button>
      </span>
    </el-dialog>

    <!-- 删除奖学金-弹窗 -->
    <el-dialog title="删除奖学金信息" :visible.sync="deleteVisible" width="300px" center>
      <div style="text-align:center">删除不可恢复，是否确认删除</div>
      <span slot="footer">
        <el-button @click="deleteRow" size="mini">确定</el-button>
        <el-button @click="deleteVisible = false" size="mini">取消</el-button>
      </span>
    </el-dialog>

    <!-- 修改奖学金信息-弹窗 -->
    <el-dialog title="修改奖学金信息" :visible.sync="editVisible" width="450px" center>
      <el-form :model="editForm" ref="editForm" label-width="80px" :rules="rules">
        <el-form-item prop="number" label="学号" size="mini">
          <el-input v-model="editForm.number" placeholder="学号" disabled></el-input>
        </el-form-item>
        <el-form-item prop="name" label="姓名" size="mini">
          <el-input v-model="editForm.name" placeholder="姓名" disabled></el-input>
        </el-form-item>
        <el-form-item prop="type" label="奖学金类型" size="mini">
          <el-select v-model="editForm.typeId" placeholder="请选择">
            <el-option v-for="item in TypeData" :key="item.id" :label="item.type" :value="item.id"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item prop="address" label="家庭住址" size="mini">
          <el-input v-model="editForm.address" placeholder="家庭住址" type="textarea"></el-input>
        </el-form-item>
        <el-form-item prop="className" label="所属学院" size="mini">
          <el-select v-model="editForm.className" placeholder="请选择" disabled>
            <el-option label="数工学院" value="1" key="1"></el-option>
            <el-option label="人文学院" value="2"></el-option>
            <el-option label="计算机学院" value="3"></el-option>
            <el-option label="经贸学院" value="4"></el-option>
            <el-option label="艺术学院" value="5"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item prop="applyTime" label="申请日期" size="mini">
          <el-date-picker v-model="editForm.applyTime" placeholder="选择日期" type="date" style="width:100%"></el-date-picker>
        </el-form-item>
      </el-form>
      <span slot="footer">
        <el-button @click="editSave" size="mini">确定</el-button>
        <el-button @click="editVisible = false" size="mini">取消</el-button>
      </span>
    </el-dialog>

    <!-- 查询奖学金-表格 -->
    <el-table size="small" border style="width:100%" height="510px" :data="tableData"
      @selection-change="handleSelectionChange">
      <el-table-column label="学号" prop="number" width="120" align="center"></el-table-column>
      <el-table-column label="学生姓名" prop="name" width="120" align="center"></el-table-column>
      <el-table-column label="学院" width="200" align="center">
        <template slot-scope="scope">
          {{ getClassName(scope.row.className) }}
        </template>
      </el-table-column>
      <el-table-column label="奖学金类别" width="120" align="center">
        <template slot-scope="scope">
          {{ scope.row.type }}
        </template>
      </el-table-column>
      <el-table-column label="家庭地址" align="center">
        <template slot-scope="scope">
          <p style="height:120px; overflow:hidden; line-height: 120px;">{{ scope.row.address }}</p>
        </template>
      </el-table-column>
      <el-table-column label="申请开始日期" width="120" align="center">
        <template slot-scope="scope">
          {{ attachBirth(scope.row.applyTime) }}
        </template>
      </el-table-column>
      <el-table-column label="辅导员审核" width="120" align="center">
        <template slot-scope="scope">
          {{ getCheck(scope.row.teacherCheck) }}
        </template>
      </el-table-column>
      <el-table-column label="辅导员意见" align="center" width="120">
        <template slot-scope="scope">
          <p style="height:100px; overflow:hidden;line-height:100px">{{ scope.row.teacherOpinion }}</p>
        </template>
      </el-table-column>
      <el-table-column label="教务处审核" width="120" align="center">
        <template slot-scope="scope">
          {{ getCheck(scope.row.officeCheck) }}
        </template>
      </el-table-column>
      <el-table-column label="教务处意见" prop="officeOpinion" width="120" align="center">
        <template slot-scope="scope">
          <p style="height:100px; overflow:hidden;line-height:100px">{{ scope.row.officeOpinion }}</p>
        </template>
      </el-table-column>
      <el-table-column label="操作" align="center" width="180px" fixed="right">
        <!-- width:180px -->
        <template slot-scope="scope">
          <el-button type="button" @click="handleEdit(scope.row)" size="small">编辑</el-button>
          <el-button type="danger" @click="handleDelete(scope.row.id)" size="small">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <!-- 分页 -->
    <div class="pageination">
      <el-pagination background layout="total,prev,pager,next" :total="tableData.length" :current-page="currentPage"
        :page-size="pageSize" @current-change="handleCurrentChange">
      </el-pagination>
    </div>
  </div>
</template>

<script>
import { mixin } from "@/mixins/index";
import {
  getAllJiangXueJinApply, getJiangXueJinApplyByUsername, addJiangXueJinApply,
  deleteJiangXueJinApply, updateJiangXueJinApply, getJxjData, getStudentUser
} from "@/api/index"
export default {
  mixins: [mixin],
  data() {
    return {
      // 默认为false 当单击事件后变为true 就会显示弹窗
      addDialogVisible: false, //添加弹窗
      editVisible: false,  //修改弹窗
      deleteVisible: false, //删除弹窗

      //添加框
      registerForm: {
        number: '',
        name: '',
        address: '',
        className: '',
        applyTime: '',
        typeId: '',
      },
      //修改框
      editForm: {
        id: '',
        number: '',
        name: '',
        address: '',
        className: '',
        applyTime: '',
        typeId: '',

      },
      //奖学金类型options
      TypeData: [],
      value: '',

      tableData: [],  //用于存储查询到的用户信息，一开始默认为空
      tempData: [],
      username: '',
      index: -1,   //选择当前项
      pageSize: 3, //一张页面展示多少数据
      currentPage: 1, //当前页
      nowDate: new Date(),// 获取当前日期
      //校验规则
      rules: {
        number: [
          { required: true, message: '请输入学号', trigger: 'blur' }
        ],
        name: [
          { required: true, message: '请输入姓名', trigger: 'blur' }
        ],
        typeId: [
          { required: true, message: '请选择申请的奖学金', trigger: 'blur' }
        ],
        level: [
          { required: true, message: '请输入奖学金类别', trigger: 'blur' }
        ],
        className: [
          { required: true, message: '请输入学院', trigger: 'blur' }
        ],
        applyTime: [
          { required: true, message: '请输入申请日期', trigger: 'blur'}
        ]
      },
    };
  },
  // 创建页面的时候执行
  created() {
    this.username = localStorage.getItem('userName');
    this.getData();
    this.getTypeData();
  },
  methods: {
    getData() {
      this.tempData = [];
      this.tableData = []; //一开始清空tableData 防止之前有残留数据
      // 拿道username
      let params = new URLSearchParams();
      params.append('username', this.username);
      // console.log("aaa:"+params.get('username'));
      getJiangXueJinApplyByUsername(params)
        .then((res) => {
          this.tempData = res;
          this.tableData = res;
          this.currentPage = 1;
        })
        .catch((error) => {
          console.error(error);
        });

    },
    // 获取当前页
    handleCurrentChange(val) {
      this.currentPage = val;
    },
    // 奖学金类型查询
    getTypeData() {
      this.TypeData = [];
      getJxjData().then((res) => {
        this.TypeData = res
      })
    },

    // 弹出添加用户信息页面
    handleAdd() {
      this.addDialogVisible = true
      let params = new URLSearchParams();
      params.append('username', localStorage.getItem('userName'));
      getStudentUser(params)
        .then((res) => {
          this.registerForm = {
            name: res.name,
            number: res.number,
            className: res.className,
            applyTime: this.nowDate,
          }
        });
    },


    // 添加奖学金
    insertSave() {
      this.$refs['registerForm'].validate(valid => {
        if (valid) {
          // 申请奖学金日期
          let s = this.registerForm.applyTime;
          let apply = s.getFullYear() + '-' + (s.getMonth() + 1) + '-' + s.getDate();

          //接收保存往后台传递的参数,
          let params = new URLSearchParams();
          params.append('username', this.username);
          params.append('number', this.registerForm.number);
          params.append('name', this.registerForm.name);
          // params.append('jxjLevel',this.registerForm.jxjLevel);
          params.append('jxjLevel', this.registerForm.typeId)
          params.append('address', this.registerForm.address);
          params.append('className', this.registerForm.className);
          params.append('applyTime', apply);

          addJiangXueJinApply(params)
            .then((res) => {
              if (res.code == 1) {
                this.getData();
                this.message("添加成功！", "success");
                this.addDialogVisible = false;
              } else {
                this.message("添加失败!", "error");
              }
            })
            .catch(err => {
              console.log(err);
            });
          this.addDialogVisible = false;
        }
      })
    },

    // 删除信息
    deleteRow() {
      deleteJiangXueJinApply(this.index)
        .then((res) => {
          if (res) {
            this.getData();
            this.message("删除成功！", "success");
          } else {
            this.message("删除失败!", "error");
          }
        })
      this.deleteVisible = false;
    },

    // 弹出编辑用户信息页面
    handleEdit(row) {
      this.editVisible = true
      this.editForm = {
        id: row.id,
        number: row.number,
        name: row.name,
        typeId: row.jxjLevel,
        type: row.type,
        address: row.address,
        className: row.className,
        applyTime: row.applyTime,
      }
      // this.editForm.typeId = row.type
    },

    // 编辑保存
    editSave() {
      this.$refs['editForm'].validate(valid => {
        if (valid) {
          // 申请奖学金日期
          let s = new Date(this.editForm.applyTime);
          let apply = s.getFullYear() + '-' + (s.getMonth() + 1) + '-' + s.getDate();
          //接收保存往后台传递的参数,
          let params = new URLSearchParams();
          params.append('id', this.editForm.id);
          params.append('number', this.editForm.number);
          params.append('name', this.editForm.name);
          params.append('jxjLevel', this.editForm.typeId);
          params.append('address', this.editForm.address);
          params.append('className', this.editForm.className);
          params.append('applyTime', apply);

          updateJiangXueJinApply(params)
            .then((res) => {
              if (res.code == 1) {
                this.getData();
                this.message("修改成功！", "success");
              } else {
                this.message("修改失败!", "error");
              }
            })
            .catch(err => {
              console.log(err);
            });
          this.editVisible = false;
        }
      })
    },

  }
};
</script>

<style scoped>
.student-img {
  border-radius: 5px;
  width: 100%;
  height: 80px;
  margin-bottom: 5px;
  overflow: hidden;

}

.handle-box {
  margin-bottom: 10px;
}

.handle-input {
  float: right;
  width: 300px;
  display: inline-block;
}

.pageination {
  margin-top: 10px;
  display: flex;
  justify-content: center;
}
</style>
