<template>
    <div class="container">
        <el-card style="width:600px">
            <el-form :model="showForm" ref="showForm" label-width="80px" :rules="rules">
                <div style="text-align: center; margin:10px 0;">
                    <el-upload
                    class="avatar-uploader"
                    :action="uploadUrl(showForm.id)"
                    :on-success= "handleAvatorSuccess">
                        <img v-if="showForm.photo" :src="getUrl(showForm.photo)" class="avatar">
                        <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                    </el-upload>
                </div>
                <el-form-item label="角色">
                    <el-select v-model="showForm.role" disabled>
                      <el-option label="管理员" value="0"></el-option>
                      <el-option label="学生" value="3"></el-option>
                      <el-option label="辅导员" value="2"></el-option>
                      <el-option label="教务处" value="1"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item prop="number" label="学号" size="mini">
                    <el-input v-model="showForm.number" placeholder="学号" disabled></el-input>
                </el-form-item>
                <el-form-item prop="username" label="用户名" size="mini">
                    <el-input v-model="showForm.username" placeholder="用户名" disabled></el-input>
                </el-form-item>
                <el-form-item prop="name" label="学生姓名" size="mini">
                    <el-input v-model="showForm.name" placeholder="学生姓名"></el-input>
                </el-form-item>
                <el-form-item prop="sex" label="性别" size="mini" >
                        <input type="radio" name="sex" value="1" v-model="showForm.sex" disabled/>&nbsp;男&nbsp;&nbsp;
                        <input type="radio" name="sex" value="2" v-model="showForm.sex" disabled/>&nbsp;女
                </el-form-item>
                <el-form-item prop="className" label="所属学院" size="mini">
                    <el-select v-model="showForm.className" placeholder="请选择">
                        <el-option label="数工学院" value="1" key="1"></el-option>
                        <el-option label="人文学院" value="2"></el-option>
                        <el-option label="计算机学院" value="3"></el-option>
                        <el-option label="经贸学院" value="4"></el-option>
                        <el-option label="艺术学院" value="5"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item prop="birth" label="生日" size="mini" >
                    <el-date-picker v-model="showForm.birth" placeholder="选择日期" type="date" style="width:100%"></el-date-picker>
                </el-form-item>
                <el-form-item prop="nationality" label="民族" size="mini">
                    <el-input v-model="showForm.nationality" placeholder="民族"></el-input>
                </el-form-item>
                <el-form-item prop="politicalStatus" label="政治面貌" size="mini">
                    <el-input v-model="showForm.politicalStatus" placeholder="政治面貌"></el-input>
                </el-form-item>
                <el-form-item prop="nativePlace" label="籍贯" size="mini">
                    <el-input v-model="showForm.nativePlace" placeholder="籍贯"></el-input>
                </el-form-item>
                <el-form-item prop="address" label="家庭住址" size="mini">
                    <el-input v-model="showForm.address" placeholder="家庭住址"></el-input>
                </el-form-item>
                <el-form-item prop="postcard" label="邮政编码" size="mini">
                    <el-input v-model="showForm.postcard" placeholder="邮政编码"></el-input>
                </el-form-item>
                <el-form-item prop="familyPhone" label="家庭电话" size="mini">
                    <el-input v-model="showForm.familyPhone" placeholder="家庭电话"></el-input>
                </el-form-item>
                <el-form-item prop="mobilePhone" label="个人电话" size="mini">
                    <el-input v-model="showForm.mobilePhone" placeholder="个人电话"></el-input>
                </el-form-item>
            </el-form>
            <div class="footer">
                <el-button type="primary" size="small"  @click="editUser" >修改信息</el-button>
                <el-button type="primary" size="small"  @click="editDialogVisible = true" >修改密码</el-button>
            </div>
        </el-card>
        
        <!-- 修改密码弹窗 -->
        <el-dialog title="修改密码" :visible.sync="editDialogVisible" width="450px" center>
            <el-form :model="editForm" ref="editForm" label-width="80px" :rules="rules">
                <el-form-item prop="password" label="密码" size="mini">
                    <el-input v-model="editForm.password" placeholder="请输入密码" type="password"></el-input>
                </el-form-item>
                <el-form-item prop="passwordAgain" label="确认密码" size="mini">
                    <el-input v-model="editForm.passwordAgain" placeholder="请再次输入密码" type="password"></el-input>
                </el-form-item>
            </el-form>
        <span slot="footer">
          <el-button  @click="editSave" size="mini">确定</el-button>
          <el-button  @click="editDialogVisible = false" size="mini">取消</el-button>
        </span>
        </el-dialog>
        
    </div>
</template>

<script>
    import { mixin } from "@/mixins/index";
    import {getStudentUser,updateStudentPassword,updateStudentByMine} from "@/api/index.js"
    export default {
        mixins: [mixin],
        data() {
            return{
                editDialogVisible:false,//修改弹窗
                //修改信息框
                showForm:{   
                    id:'',
                    role: '',
                    username: '',
                    number:'',
                    name:'',
                    sex:'',
                    className:'',
                    birth:'',
                    nationality:'',
                    politicalStatus:'',
                    nativePlace:'',
                    address:'',
                    postcard:'',
                    familyPhone:'',
                    mobilePhone:'',
                    
                },
                // 修改密码框
                editForm:{
                    id:'',
                    password:'',
                    passwordAgain:''
                },
                //校验规则
                rules:{
                    name:[
                        {required: true,message:'请输入姓名',trigger:'blur'}
                    ],
                    className:[
                        {required: true,message:'请输入学院',trigger:'blur'}
                    ],
                    mobilePhone:[
                        {required: true,message:'请输入联系电话',trigger:'blur'}
                    ],
                    password:[
                        {required: true,message:'请输入密码',trigger:'blur'}
                    ],
                    passwordAgain:[
                        {required: true, message:'请输入再次输入密码', trigger: 'blur'}
                    ],
                    
                },
            };
            
        },
        // 创建页面的时候执行
        created(){
            if(!localStorage.getItem('userName') || localStorage.getItem('role') != '3'){
                this.$router.push("/");
                this.message("请您先登录","warning");
            }else{
                this.getData();
            }
            
        },
        methods: {
            //查询
            getData(){
                let params = new URLSearchParams();
                params.append('username',localStorage.getItem('userName'));
                getStudentUser(params)
                .then((res) =>{
                    this.showForm = res;
                });
            },
            // 修改密码
            editSave(){
                if(this.editForm.password != this.editForm.passwordAgain){
                    this.message("两次密码输入不一致！","warning");
                    return;
                }else{
                    this.$refs['editForm'].validate(valid =>{
                        if(valid){
                            //接收保存往后台传递的参数,
                            let params = new URLSearchParams();
                            params.append('id',this.showForm.id);
                            params.append('password',this.editForm.password);
                            params.append('passwordAgain',this.editForm.passwordAgain);
                            updateStudentPassword(params)
                            .then((res) =>{
                                if(res.code == 1){
                                    this.getData();
                                    this.editDialogVisible = false;
                                    this.message("修改成功,请重新登录！","success");
                                    this.$router.push("/");
                                }else{
                                    this.message("修改失败!","error");
                                }
                            })
                            .catch(err =>{
                                console.log(err);
                            });
                            this.editVisible = false;
                        }
                    })
                    }
            },
            // 修改信息
            editUser(){
                this.$refs['showForm'].validate(valid =>{
                    if(valid){
                        let d = new Date(this.showForm.birth);
                        let datetime = d.getFullYear() + '-' + (d.getMonth()+1) + '-' + d.getDate();
                        //接收保存往后台传递的参数,
                        let params = new URLSearchParams();
                        params.append('id',this.showForm.id);
                        params.append('username',this.showForm.username);
                        params.append('number',this.showForm.number);
                        params.append('name',this.showForm.name);
                        params.append('sex',this.showForm.sex);
                        params.append('className',this.showForm.className);
                        params.append('birth',datetime);
                        params.append('nationality',this.showForm.nationality);
                        params.append('politicalStatus',this.showForm.politicalStatus);
                        params.append('nativePlace',this.showForm.nativePlace);
                        params.append('address',this.showForm.address);
                        params.append('postcard',this.showForm.postcard);
                        params.append('familyPhone',this.showForm.familyPhone);
                        params.append('mobilePhone',this.showForm.mobilePhone);

                        updateStudentByMine(params)
                        .then((res) =>{
                            if(res.code == 1){
                                this.getData();
                                this.message("修改成功！","success");
                            }else{
                                this.message("修改失败!","error");
                            }
                        })
                        .catch(err =>{
                            console.log(err);
                        });
                        this.editVisible = false;
                    }
                })
            },
            // 更新照片
            uploadUrl(id){
                return `${this.$store.state.HOST}/student/updateStudentPic?id=${id}`
            },
        }
    }
</script>

<style scoped>

    .footer{
        margin: auto;
        text-align: center;
        margin-top: 20px;
    }
    .avatar-uploader .el-upload {
        border: 1px dashed #d9d9d9;
        border-radius: 6px;
        cursor: pointer;
        position: relative;
        overflow: hidden;
        
    }
    .avatar-uploader .el-upload:hover {
        border-color: #409EFF;
    }
    .avatar-uploader-icon {
        font-size: 28px;
        color: #8c939d;
        width: 178px;
        height: 178px;
        line-height: 178px;
        text-align: center;
    }
    .avatar {
        width: 178px;
        height: 178px;
        display: block;
    }
</style>