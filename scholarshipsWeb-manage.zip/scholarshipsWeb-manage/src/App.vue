<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<script>
export default ({
  data(){
    return {
      // 所属学院 option value lable 转换
      
    }
  }
})
</script>


<style>
*{
  margin: 0;
  padding: 0;
}
  #app{
    height: 100vh;

  }
</style>
