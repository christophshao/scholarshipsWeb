import Vue from 'vue'
import App from './App'
import VueRouter from 'vue-router'

import store from './store/index'
import router from './router'

import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
import VCharts from 'v-charts'

import './assets/css/index.css'
import './assets/css/main.css'


Vue.use(VueRouter);
Vue.use(router);
Vue.use(ElementUI,{size:"small"});
Vue.use(VCharts);
Vue.config.productionTip = false;

new Vue({
  el: '#app',
  router,
  store,
  components: { App },
  template: '<App/>',
  render: h => h(App)
})
