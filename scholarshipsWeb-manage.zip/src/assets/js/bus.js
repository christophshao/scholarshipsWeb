import Vue from 'vue'

// 使用Event Bus
const bus = new Vue()

export default bus