<template>
    <div class="sidebar">
         <!-- 这里的router 对应了下面的index 用来导向页面的 -->
            <el-menu
                class="sidebar-el-menu"
                :default-active="onRoutes"
                :collapse="collapse"
                background-color="#334256"
                text-color="#ffffff"
                active-text-color="#20a0ff"
                router=""
                width="300px">

                <template v-for="item in items">
                    <el-menu-item :index="item.index" :key="item.index">
                        <i :class="item.icon"></i>
                        {{item.title}}
                    </el-menu-item>
                </template>
            </el-menu>
    </div>
</template>



<script>
import bus from "@/assets/js/bus"
export default 
{
    data(){
        return{
            collapse: false,
            items:[
                // {
                //     icon:'el-icon-s-home',
                //     index:'Info',
                //     title:'系统首页',
                // },
                {
                    icon:'el-icon-user-solid',
                    index:'Mine',
                    title:'个人中心',
                },
                {
                    icon:'el-icon-document',
                    index:'PoorStudent',
                    title:'贫困生申请管理',
                },
                {
                    icon:'el-icon-document',
                    index:'ZhuXueJinApply',
                    title:'助学金申请管理',
                },
                {
                    icon:'el-icon-document',
                    index:'JiangXueJinApply',
                    title:'奖学金申请管理',
                },

            ],
            
        }
    },
    computed:{
        onRoutes(){
            // 登录后 设置路径为默认的是系统首页
            return this.$route.path.replace('/','');
        }
    },
    created(){
        // 通过Bus 进行组件间的通信，来折叠侧边栏=》就是改变 collapse的值
        bus.$on('collapse',msg =>{
            // 收到msg后会改变collapse的属性
            this.collapse = msg
        })
    }
}
</script>

<style scoped>
    .sidebar{
        display:block;
        position: absolute;
        left: 0;
        top: 70px;
        bottom: 0;
        background: #333;
        overflow-y: scroll;
    }

    .sidebar::-webkit-scrollbar{
        width: 0;
    }

    .sidebar-el-menu:not(.el-menu--collapse){
        width: 200px;
    }
    .sidebar >ul{
        height: 100%;
    }
    .el-menu{
        border-right: none;
    }

</style>
