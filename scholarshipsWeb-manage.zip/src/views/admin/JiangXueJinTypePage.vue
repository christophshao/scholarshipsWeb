<template>
    <div class="table">
        <!-- 功能区域 -->
        <div class="container">
            <div class="handle-box">
                <!-- 批量删除 -->
                <el-button type="danger" size="small" @click="deleteAll">
                    批量删除
                </el-button>
                <!-- 添加 -->
                <el-button type="primary" size="small" @click="addDialogVisible = true">
                    添加奖学金
                </el-button>
                <!-- 查询 -->
                <el-input v-model="select_word" placeholder="请输入奖学金名称..." class="handle-input" size="small">
                </el-input>
            </div>
        </div>
        <!-- 添加-弹窗 -->
        <el-dialog title="添加" :visible.sync="addDialogVisible" width="450px" center >
        <el-form :model="registerForm" ref="registerForm" label-width="80px" :rules="rules">
            <el-form-item prop="type" label="名称" size="mini">
                <el-input v-model="registerForm.type" placeholder="名称"></el-input>
            </el-form-item>
        </el-form>
        <span slot="footer">
            <el-button  @click="insertSave" size="mini">确定</el-button>
            <el-button @click="addDialogVisible = false" size="mini">取消</el-button>
        </span>
        </el-dialog>

        <!-- 删除-弹窗 -->
        <el-dialog title="删除" :visible.sync="deleteVisible" width="300px" center>
            <div style="text-align:center">删除不可恢复，是否确认删除</div>
            <span slot="footer">
                <el-button  @click="deleteRow" size="mini">确定</el-button>
                <el-button  @click="deleteVisible = false" size="mini">取消</el-button>
            </span>
        </el-dialog>

        <!-- 修改信息-弹窗 -->
        <el-dialog title="修改信息" :visible.sync="editVisible" width="450px" center>
            <el-form :model="editForm" ref="editForm" label-width="80px" :rules="rules">
                <el-form-item prop="type" label="名称" size="mini">
                    <el-input v-model="editForm.type" placeholder="名称"></el-input>
                </el-form-item>
            </el-form>
            <span slot="footer">
                <el-button  @click="editSave" size="mini">确定</el-button>
                <el-button  @click="editVisible = false" size="mini">取消</el-button>
            </span>
        </el-dialog>

        <!-- 查询表格 -->
        <el-table size="mini" border style="width:100%" height="510px" :data="data" @selection-change="handleSelectionChange">
            <el-table-column label="多选" type="selection" width="50" center></el-table-column>
            <el-table-column label="索引" prop="id" width="200" align="center"></el-table-column>
            <el-table-column label="奖学金名称" prop="type"  align="center"></el-table-column>
            <el-table-column label="操作" width="200" align="center">
                <template slot-scope="scope">
                    <el-button type="button" @click="handleEdit(scope.row)" size="small">编辑</el-button>
                    <el-button type="danger" @click="handleDelete(scope.row.id)" size="small">删除</el-button>
                </template>
            </el-table-column>
            
        </el-table>

        <!-- 分页 -->
        <div class="pageination">
            <el-pagination background layout="total,prev,pager,next" 
                :total="tableData.length" :current-page="currentPage" :page-size="pageSize" 
                @current-change="handleCurrentChange">
            </el-pagination>
        </div>

    </div>
</template>

<script>
import { mixin } from "@/mixins/index";
import {getAllJiangXueJinType,addJiangXueJinType,
        updateJiangXueJinType,deleteJiangXueJinType} from "@/api/index"

export default {
  mixins: [mixin],
    data() {
        return {
            // 默认为false 当单击事件后变为true 就会显示弹窗
            addDialogVisible: false, //添加弹窗
            editVisible:false,  //修改弹窗
            deleteVisible:false, //删除弹窗

            //添加框
            registerForm: {
                type:'xx奖学金',
            },
            //修改框
            editForm:{   
                id:'',
                type:'',
                   
            },
            tableData: [],  //用于存储查询到的用户信息，一开始默认为空
            tempData: [],
            select_word: '',
            index: -1,   //选择当前项
            multipleSelection:[],   //确定多选项数量
            pageSize:10, //一张页面展示多少数据
            currentPage: 1, //当前页

           //校验规则
            rules:{
                type:[
                    {required: true, message:'请输入奖学金名称', trigger: 'blur'}
                ],
            },
        };
    },
    // 计算当前搜索结果表中的数据
    computed:{
        data(){
            return this.tableData.slice((this.currentPage - 1)*this.pageSize,this.currentPage * this.pageSize);
        }
    },
    // 搜索框发生变化的时候，table中的内容同步变化
    watch:{
        select_word: function(){
        if(this.select_word == ''){
            this.tableData = this.tempData;
        }else{
            this.tableData = [];
            for(let item of this.tempData){
            if(item.type.includes(this.select_word)){
                this.tableData.push(item);
            }
            }
        }
        }
    },
    // 创建页面的时候执行
    created(){
        this.getData();
    },
    methods:{
        //查询
        getData(){
            this.tempData = [];
            this.tableData = []; //一开始清空tableData 防止之前有残留数据
            getAllJiangXueJinType().then((res) =>{
                this.tempData = res;
                this.tableData = res;
                this.currentPage = 1;
            })
        },
        // 获取当前页
        handleCurrentChange(val){
            this.currentPage = val;
        },
        // 添加
        insertSave(){
        this.$refs['registerForm'].validate(valid =>{
            if(valid){

                //接收保存往后台传递的参数,
                let params = new URLSearchParams();
                params.append('type',this.registerForm.type);
                addJiangXueJinType(params)
                .then((res) =>{
                if(res.code == 1){
                    this.getData();
                    this.message("添加成功！","success");
                    this.addDialogVisible = false;
                }else{
                    this.message("添加失败!","error");
                }
                })
                .catch(err =>{
                console.log(err);
                });
                this.centerDialogVisible = false;
            }
        })

        
        },
        // 删除信息
        deleteRow(){
            deleteJiangXueJinType(this.index)
            .then((res) =>{
            if(res){
                this.getData();
                this.message("删除成功！","success");
            }else{
                this.message("删除失败!","error");
            }
        })
        this.deleteVisible = false;
        },
        // 弹出编辑用户信息页面
        handleEdit(row){
        this.editVisible = true;
        this.editForm ={
            id: row.id,
            type: row.type,
        }
        },
          // 编辑保存
        editSave(){
            this.$refs['editForm'].validate(valid =>{
                if(valid){
                    //接收保存往后台传递的参数,
                    let params = new URLSearchParams();
                    params.append('id',this.editForm.id);
                    params.append('type',this.editForm.type);
                    updateJiangXueJinType(params)
                    .then((res) =>{
                        if(res.code == 1){
                            this.getData();
                            this.message("修改成功！","success");
                        }else{
                            this.message("修改失败!","error");
                        }
                    })
                    .catch(err =>{
                        console.log(err);
                    });
                    this.editVisible = false;
                }
            })
        },
      
    }
}
</script>


<style scoped>
    .handle-box{
      margin-bottom: 10px;
    }
    .handle-input{
      float: right;
      width: 300px;
      display: inline-block;
    }
    .pageination{
        margin-top: 10px;
        display: flex;
        justify-content: center;
    }
</style>
