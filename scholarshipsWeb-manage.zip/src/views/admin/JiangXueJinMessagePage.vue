<template>
    <div class="table">
      <!-- 功能区域 -->
      <div class="container">
        <div class="handle-box">
          <!-- 批量删除 -->
          <el-button type="danger" size="small" @click="deleteAll">
              批量删除
          </el-button>
          <!-- 添加 -->
          <el-button type="primary" size="small" @click="addDialogVisible = true">
              添加奖学金
          </el-button>
          <!-- 查询 -->
          <el-input v-model="select_word" 
              placeholder="请输入奖学金名..." class="handle-input" size="small">
          </el-input>
        </div>
      </div>
      <!-- 添加奖学金信息-弹窗 -->
      <el-dialog title="添加奖学金信息" :visible.sync="addDialogVisible" width="450px" center >
        <el-form :model="registerForm" ref="registerForm" label-width="80px" :rules="rules">
          <el-form-item prop="number" label="奖学金编号" size="mini">
              <el-input v-model="registerForm.number" placeholder="奖学金编号"></el-input>
          </el-form-item>
          <el-form-item prop="name" label="奖学金名称" size="mini">
            <el-input v-model="registerForm.name" placeholder="奖学金名称"></el-input>
          </el-form-item>
          <el-form-item prop="level" label="奖学金类型" size="mini">
            <el-select v-model="registerForm.level" placeholder="请选择">
              <el-option label="一等奖学金" value="1" key="1"></el-option>
              <el-option label="二等奖学金" value="2"></el-option>
              <el-option label="三等奖学金" value="3"></el-option>
              <el-option label="省政府奖学金" value="4"></el-option>
              <el-option label="国家奖学金" value="5"></el-option>
              <el-option label="校长奖学金" value="6"></el-option>
              <!-- <el-option-group v-for="" :key="">
                <el-option :label="" :value=""></el-option>
              </el-option-group> -->
            </el-select>
          </el-form-item>
          <el-form-item prop="startTime" label="申请开始日期" size="mini">
            <el-date-picker v-model="registerForm.startTime" placeholder="选择日期" type="date" style="width:100%"></el-date-picker>
          </el-form-item>
          <el-form-item prop="deadline" label="申请截止日期" size="mini">
            <el-date-picker v-model="registerForm.deadline" placeholder="选择日期" type="date" style="width:100%"></el-date-picker>
          </el-form-item>
          <el-form-item prop="introduce" label="奖学金简介" size="mini">
            <el-input v-model="registerForm.introduce" placeholder="奖学金简介" type="textarea"></el-input>
          </el-form-item>
          
        </el-form>
        <span slot="footer">
          <el-button  @click="insertSave" size="mini">确定</el-button>
          <el-button @click="addDialogVisible = false" size="mini">取消</el-button>
        </span>
      </el-dialog>

      <!-- 删除奖学金-弹窗 -->
      <el-dialog title="删除奖学金信息" :visible.sync="deleteVisible" width="300px" center>
        <div style="text-align:center">删除不可恢复，是否确认删除</div>
        <span slot="footer">
          <el-button  @click="deleteRow" size="mini">确定</el-button>
          <el-button  @click="deleteVisible = false" size="mini">取消</el-button>
        </span>
      </el-dialog>

      <!-- 修改奖学金信息-弹窗 -->
      <el-dialog title="修改奖学金信息" :visible.sync="editVisible" width="450px" center>
        <el-form :model="editForm" ref="editForm" label-width="80px" :rules="rules">
          <el-form-item prop="number" label="奖学金编号" size="mini">
              <el-input v-model="editForm.number" placeholder="奖学金编号"></el-input>
          </el-form-item>
          <el-form-item prop="name" label="奖学金名称" size="mini">
            <el-input v-model="editForm.name" placeholder="奖学金名称"></el-input>
          </el-form-item>
          <el-form-item prop="level" label="奖学金类型" size="mini">
            <el-select v-model="editForm.level" placeholder="请选择">
              <el-option label="一等奖学金" value="1" key="1"></el-option>
              <el-option label="二等奖学金" value="2"></el-option>
              <el-option label="三等奖学金" value="3"></el-option>
              <el-option label="省政府奖学金" value="4"></el-option>
              <el-option label="国家奖学金" value="5"></el-option>
              <el-option label="校长奖学金" value="6"></el-option>
              <!-- <el-option-group v-for="" :key="">
                <el-option :label="" :value=""></el-option>
              </el-option-group> -->
            </el-select>
          </el-form-item>
           <el-form-item prop="startTime" label="申请开始日期" size="mini">
            <el-date-picker v-model="editForm.startTime" placeholder="选择日期" type="date" style="width:100%"></el-date-picker>
          </el-form-item>
          <el-form-item prop="deadline" label="申请截止日期" size="mini">
            <el-date-picker v-model="editForm.deadline" placeholder="选择日期" type="date" style="width:100%"></el-date-picker>
          </el-form-item>
          <el-form-item prop="introduce" label="奖学金简介" size="mini">
            <el-input v-model="editForm.introduce" placeholder="奖学金简介" type="textarea"></el-input>
          </el-form-item>
        </el-form>
        <span slot="footer">
          <el-button  @click="editSave" size="mini">确定</el-button>
          <el-button  @click="editVisible = false" size="mini">取消</el-button>
        </span>
      </el-dialog>

      <!-- 查询奖学金-表格 -->
      <el-table size="small" border style="width:100%" height="510px" :data="data" @selection-change="handleSelectionChange">
          <el-table-column label="多选" type="selection" width="50" center></el-table-column>
          <el-table-column label="奖学金编号" prop="number" width="120" align="center"></el-table-column>
          <el-table-column label="奖学金照片" width="120" align="center">
              <template slot-scope="scope">
                  <div class="student-img">
                      <img :src="getUrl(scope.row.photo)" width="100%"/>
                  </div>
                  <!-- 更新图片 -->
                  <el-upload :action="uploadUrl(scope.row.id)" :on-success="handleAvatorSuccess">
                      <el-button size="mini">更新照片</el-button>
                  </el-upload>
              </template>
          </el-table-column>
          <el-table-column label="奖学金名称" prop="name" width="120" align="center"></el-table-column>
          <el-table-column label="奖学金类别" width="120" align="center">
            <template slot-scope="scope">
                {{getJiangXueJin(scope.row.level)}}
            </template> 
          </el-table-column>
          <el-table-column label="申请开始日期" width="120" align="center">
            <template slot-scope="scope">
                {{attachBirth(scope.row.startTime)}}
            </template>
          </el-table-column>
          <el-table-column label="申请截至日期" width="120" align="center">
            <template slot-scope="scope">
                {{attachBirth(scope.row.deadline)}}
            </template>
          </el-table-column>
          <el-table-column label="发布日期" width="120" align="center">
            <template slot-scope="scope">
                {{attachBirth(scope.row.createTime)}}
            </template>
          </el-table-column>
          <el-table-column label="奖学金简介" align="center">
           <template slot-scope="scope">
              <p style="height:120px; overflow:hidden; line-height: 120px;">{{scope.row.introduce}}</p>
           </template>
         </el-table-column>

          <el-table-column label="操作" align="center">
              <!-- width:180px -->
              <template slot-scope="scope">
                  <el-button type="button" @click="handleEdit(scope.row)" size="small">编辑</el-button>
                  <el-button type="danger" @click="handleDelete(scope.row.id)" size="small">删除</el-button>
              </template>
          </el-table-column>
      </el-table>

      <!-- 分页 -->
      <div class="pageination">
        <el-pagination background layout="total,prev,pager,next" 
        :total="tableData.length" :current-page="currentPage" :page-size="pageSize" 
        @current-change="handleCurrentChange">
        </el-pagination>
      </div>

    </div>


</template>

<script>
import { mixin } from "@/mixins/index";
import {getAllJiangXueJin,addJiangXueJin,updateJiangXueJin,deleteJiangXueJin} from "@/api/index"
export default {
  mixins: [mixin],
    data() {
        return {
            // 默认为false 当单击事件后变为true 就会显示弹窗
            addDialogVisible: false, //添加弹窗
            editVisible:false,  //修改弹窗
            deleteVisible:false, //删除弹窗

            //添加框
            registerForm: {
                number:'1',
                name:'1',
                level:'1',
                startTime:'1',
                deadline:'1',
                introduce:'1',
            },
            //修改框
            editForm:{   
                id:'',
                number:'',
                name:'',
                level:'',
                startTime:'',
                deadline:'',
                introduce:'',
                   
            },
            tableData: [],  //用于存储查询到的用户信息，一开始默认为空
            tempData: [],
            select_word: '',
            index: -1,   //选择当前项
            multipleSelection:[],   //确定多选项数量
            pageSize: 3, //一张页面展示多少数据
            currentPage: 1, //当前页

           //校验规则
            rules:{
                number:[
                    {required: true, message:'请输入奖学金编号', trigger: 'blur'}
                ],
                name:[
                    {required: true,message:'请输入奖学金名称',trigger:'blur'}
                ],
                level:[
                    {required: true,message:'请输入奖学金类别',trigger:'blur'}
                ],
            },
        };
    },
    // 计算当前搜索结果表中的数据
    computed:{
        data(){
            return this.tableData.slice((this.currentPage - 1)*this.pageSize,this.currentPage * this.pageSize);
        }
    },
    
    // 搜索框发生变化的时候，table中的内容同步变化
    watch:{
        select_word: function(){
        if(this.select_word == ''){
            this.tableData = this.tempData;
        }else{
            this.tableData = [];
            for(let item of this.tempData){
            if(item.name.includes(this.select_word)){
                this.tableData.push(item);
            }
            }
        }
        }
    },
    // 创建页面的时候执行
    created(){
        this.getData();
    },
    methods:{
        //查询
        getData(){
            this.tempData = [];
            this.tableData = []; //一开始清空tableData 防止之前有残留数据
            getAllJiangXueJin().then((res) =>{
                this.tempData = res;
                this.tableData = res;
                this.currentPage = 1;
            })
        },
        // 获取当前页
        handleCurrentChange(val){
            this.currentPage = val;
        },
        // 添加奖学金
        insertSave(){
        this.$refs['registerForm'].validate(valid =>{
            if(valid){
                // 奖学金申请开始日期
                let s = this.registerForm.startTime;
                let start = s.getFullYear() + '-' + (s.getMonth()+1) + '-' + s.getDate();
                // 申请截至日期
                let d = this.registerForm.deadline;
                let dead = d.getFullYear() + '-' + (d.getMonth()+1) + '-' + d.getDate();
            
                //接收保存往后台传递的参数,
                let params = new URLSearchParams();
                params.append('number',this.registerForm.number);
                params.append('name',this.registerForm.name);
                params.append('level',this.registerForm.level);
                params.append('startTime',start);
                params.append('deadline',dead);
                params.append('photo','img/jiangxuejinPic/default.png');
                params.append('introduce',this.registerForm.introduce);
            
                addJiangXueJin(params)
                .then((res) =>{
                if(res.code == 1){
                    this.getData();
                    this.message("添加成功！","success");
                    this.addDialogVisible = false;
                }else{
                    this.message("添加失败!","error");
                }
                })
                .catch(err =>{
                console.log(err);
                });
                this.centerDialogVisible = false;
            }
        })

        
        },
        // 删除信息
        deleteRow(){
            deleteJiangXueJin(this.index)
            .then((res) =>{
            if(res){
                this.getData();
                this.message("删除成功！","success");
            }else{
                this.message("删除失败!","error");
            }
        })
        this.deleteVisible = false;
        },
        // 弹出编辑用户信息页面
        handleEdit(row){
        this.editVisible = true;
        this.editForm ={
            id: row.id,
            number: row.number,
            name: row.name,
            level: row.level,
            startTime: row.startTime,
            deadline: row.deadline,
            introduce: row.introduce,
        }
        },
          // 编辑保存
        editSave(){
            this.$refs['editForm'].validate(valid =>{
                if(valid){
                    //申请开始日期
                    let s = new Date(this.editForm.startTime);
                    let start = s.getFullYear() + '-' + (s.getMonth()+1) + '-' + s.getDate();
                    // 申请截至日期
                    let d = new Date(this.editForm.deadline);
                    let dead = d.getFullYear() + '-' + (d.getMonth()+1) + '-' + d.getDate();
                    //接收保存往后台传递的参数,
                    let params = new URLSearchParams();
                    params.append('id',this.editForm.id);
                    params.append('number',this.editForm.number);
                    params.append('name',this.editForm.name);
                    params.append('level',this.editForm.level);
                    params.append('startTime',start);
                    params.append('deadline',dead);
                    params.append('introduce',this.editForm.introduce);

                    updateJiangXueJin(params)
                    .then((res) =>{
                        if(res.code == 1){
                            this.getData();
                            this.message("修改成功！","success");
                        }else{
                            this.message("修改失败!","error");
                        }
                    })
                    .catch(err =>{
                        console.log(err);
                    });
                    this.editVisible = false;
                }
            })
        },
        // 更新奖学金照片
        uploadUrl(id){
            return `${this.$store.state.HOST}/jiangxuejin/updateJiangXueJinPic?id=${id}`
        },
      
  }
};
</script>

<style scoped>
    .student-img{
      border-radius: 5px;
      width: 100%;
      height: 80px;
      margin-bottom: 5px;
      overflow:hidden;
      
    }
    .handle-box{
      margin-bottom: 10px;
    }
    .handle-input{
      float: right;
      width: 300px;
      display: inline-block;
    }
    .pageination{
        margin-top: 10px;
        display: flex;
        justify-content: center;
    }
</style>
