<template>
    <div class="table">
      <!-- 功能区域 -->
      <div class="container">
        <div class="handle-box">
          <!-- 查询 -->
          <el-input v-model="select_word"
              placeholder="请输入学生姓名..." class="handle-input" size="small">
          </el-input>
        </div>
      </div>

      <!-- 审批助学金信息-弹窗 -->
      <el-dialog title="审批助学金信息" :visible.sync="editVisible" width="450px" center>
        <el-form :model="editForm" ref="editForm" label-width="80px" :rules="rules">
            <el-form-item prop="number" label="学号" size="mini">
                <el-input v-model="editForm.number" placeholder="学号" disabled="disabled"></el-input>
            </el-form-item>
            <el-form-item prop="name" label="姓名" size="mini">
                <el-input v-model="editForm.name" placeholder="姓名" disabled="disabled"></el-input>
            </el-form-item>
            <el-form-item prop="zxjLevel" label="助学金类型" size="mini">
                <el-select v-model="editForm.zxjLevel" placeholder="请选择" disabled="disabled">
                    <el-option label="一等助学金" value="1" key="1"></el-option>
                    <el-option label="二等助学金" value="2"></el-option>
                    <el-option label="国家励志奖学金" value="3"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item prop="address" label="家庭住址" size="mini">
                <el-input v-model="editForm.address" placeholder="家庭住址" type="textarea" disabled="disabled"></el-input>
            </el-form-item>
            <el-form-item prop="className" label="班级" size="mini">
                <el-input v-model="editForm.className" placeholder="家庭住址" type="textarea" disabled="disabled"></el-input>
            </el-form-item>
            <el-form-item prop="applyTime" label="申请日期" size="mini">
                <el-date-picker v-model="editForm.applyTime" placeholder="选择日期" type="date" style="width:100%" disabled="disabled"></el-date-picker>
            </el-form-item>
            <el-form-item prop="teacherCheck" label="是否同意" size="mini">
                <el-select v-model="editForm.teacherCheck" placeholder="请选择" disabled="disabled">
                <el-option label="通过" value="1" key="1"></el-option>
                <el-option label="未通过" value="0"></el-option>
                <el-option label="未审核" value="-1"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item prop="teacherOpinion" label="辅导员意见" size="mini">
                <el-input v-model="editForm.teacherOpinion" placeholder="辅导员意见" type="textarea" disabled="disabled"></el-input>
            </el-form-item>
            <!-- 教务处要编辑的 -->
            <el-form-item prop="officeCheck" label="是否同意" size="mini">
              <el-select v-model="editForm.officeCheck" placeholder="请选择">
                <el-option label="通过" value="1" key="1"></el-option>
                <el-option label="未通过" value="0"></el-option>
                <el-option label="未审核" value="-1"></el-option>
              </el-select>
            </el-form-item>
            <el-form-item prop="officeOpinion" label="教务处意见" size="mini">
              <el-input v-model="editForm.officeOpinion" placeholder="教务处意见" type="textarea"></el-input>
            </el-form-item>       
        </el-form>

        <span slot="footer">
          <el-button  @click="editSave" size="mini">同意</el-button>
          <el-button  @click="editVisible = false" size="mini">取消</el-button>
        </span>
      </el-dialog>

     <!-- 查询助学金-表格 -->
      <el-table size="small" border style="width:100%" height="510px" :data="data" @selection-change="handleSelectionChange">
          <el-table-column label="学号" prop="number" width="120" align="center"></el-table-column>
          <el-table-column label="学生姓名" prop="name" width="120" align="center"></el-table-column>
          <el-table-column label="班级" prop="className" width="120" align="center"></el-table-column>
          <el-table-column label="助学金类别" width="120" align="center">
            <template slot-scope="scope">
                {{getZhuXueJin(scope.row.zxjLevel)}}
            </template>
          </el-table-column>
          <el-table-column label="家庭地址" align="center">
           <template slot-scope="scope">
              <p style="height:120px; overflow:hidden; line-height: 120px;">{{scope.row.address}}</p>
           </template>
          </el-table-column>
          <el-table-column label="申请开始日期" width="120" align="center">
            <template slot-scope="scope">
                {{attachBirth(scope.row.applyTime)}}
            </template>
          </el-table-column>
          <el-table-column label="辅导员审核" width="120" align="center">
            <template slot-scope="scope">
              {{getCheck(scope.row.teacherCheck)}}
            </template>
          </el-table-column>
          <el-table-column label="辅导员意见" align="center" width="120">
           <template slot-scope="scope">
              <p style="height:100px; overflow:hidden;line-height:100px">{{scope.row.teacherOpinion}}</p>
           </template>
          </el-table-column>
          <!-- 教务处审核 -->
          <el-table-column label="教务处审核" width="120" align="center">
            <template slot-scope="scope">
              {{getCheck(scope.row.officeCheck)}}
            </template>   
          </el-table-column> 
          <el-table-column label="教务处意见" prop="officeOpinion" width="120" align="center">
            <template slot-scope="scope">
              <p style="height:100px; overflow:hidden;line-height:100px">{{scope.row.officeOpinion}}</p>
           </template>
          </el-table-column>
          <el-table-column label="操作" align="center" width="180px">
              <template slot-scope="scope">
                  <el-button type="primary" @click="handleEdit(scope.row)" size="small">详情信息</el-button>
              </template>
          </el-table-column>
      </el-table>
      <!-- 分页 -->
      <div class="pageination">
        <el-pagination background layout="total,prev,pager,next" 
        :total="tableData.length" :current-page="currentPage" :page-size="pageSize" 
        @current-change="handleCurrentChange">
        </el-pagination>
      </div>
    </div>
</template>

<script>
import { mixin } from "@/mixins/index";
import {selectZhuXueJinApplyByTeacherPass,updateZhuXueJinApplyForOffice} from "@/api/index"
export default {
  mixins: [mixin],
    data() {
        return {
            // 默认为false 当单击事件后变为true 就会显示弹窗
            editVisible:false,  //修改弹窗
            //审核框
            editForm:{   
                id:'',
                number:'',
                name:'',
                zxjLevel:'',
                address:'',
                className:'',
                applyTime:'',
                teacherCheck:'',
                teacherOpinion:'',

                officeCheck:'',
                officeOpinion:'',
                   
            },
            tableData: [],  //用于存储查询到的用户信息，一开始默认为空
            tempData: [],
            select_word: '',
            index: -1,   //选择当前项
            multipleSelection:[],   //确定多选项数量
            pageSize: 4, //一张页面展示多少数据
            currentPage: 1, //当前页

           //校验规则
            rules:{
                officeCheck:[
                    {required: true, message:'请输入是否同意', trigger: 'blur'}
                ],
            },
        };
    },
    // 计算当前搜索结果表中的数据
    computed:{
        data(){
            return this.tableData.slice((this.currentPage - 1)*this.pageSize,this.currentPage * this.pageSize);
        },
    },
    
    // 搜索框发生变化的时候，table中的内容同步变化
    watch:{
        select_word: function(){
        if(this.select_word == ''){
            this.tableData = this.tempData;
        }else{
            this.tableData = [];
            for(let item of this.tempData){
            if(item.name.includes(this.select_word)){
                this.tableData.push(item);
            }
            }
        }
        }
    },
    // 创建页面的时候执行
    created(){
        this.getData();
    },
    methods:{
        // 查询学生申请助学金
        getData(){
            this.tempData = [];
            this.tableData = []; //一开始清空tableData 防止之前有残留数据
            selectZhuXueJinApplyByTeacherPass().then((res) =>{
                this.tempData = res;
                this.tableData = res;
                this.currentPage = 1;
            })
        },
        // 获取当前页
        handleCurrentChange(val){
            this.currentPage = val;
        },
        // 弹出编辑用户信息页面
        handleEdit(row){
            this.editVisible = true;
            this.editForm ={
                id: row.id,
                number: row.number,
                name: row.name,
                zxjLevel: row.zxjLevel,
                address: row.address,
                className: row.className,
                applyTime: row.applyTime,
                teacherCheck: row.teacherCheck,
                teacherOpinion:row.teacherOpinion,

                officeCheck: row.officeCheck,
                officeOpinion: row.officeOpinion,
            }
        },
          // 编辑保存
        editSave(){
            this.$refs['editForm'].validate(valid =>{
                if(valid){
                    //接收保存往后台传递的参数,
                    let params = new URLSearchParams();
                    params.append('id',this.editForm.id);
                    params.append('officeCheck',this.editForm.officeCheck);
                    params.append('officeOpinion',this.editForm.officeOpinion);

                    updateZhuXueJinApplyForOffice(params)
                    .then((res) =>{
                        if(res.code == 1){
                            this.getData();
                            this.message("提交成功！","success");
                        }else{
                            this.message("提交失败!","error");
                        }
                    })
                    .catch(err =>{
                        console.log(err);
                    });
                    this.editVisible = false;
                }
            })
        },
  }
};
</script>

<style scoped>
    .handle-box{
      margin-bottom: 10px;
    }
    .handle-input{
      width: 400px;
      display: inline-block;
    }
    .pageination{
        margin-top: 10px;
        display: flex;
        justify-content: center;
    }
</style>
