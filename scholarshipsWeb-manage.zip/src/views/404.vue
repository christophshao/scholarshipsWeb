<template>
  <div>
    <h3>{{ msg }}</h3>
  </div>
</template>
<style scoped>
</style>
<script>
export default {
  data() {
    return {
      msg: "您的网页走丢了...",
    };
  },
};
</script>
